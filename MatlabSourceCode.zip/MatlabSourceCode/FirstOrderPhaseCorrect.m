function RCS = FirstOrderPhaseCorrect(CS, PhaseDegSpread, PhaseSpreadDirection);
%PhaseDegSpread is the total spread of phase in degrees across the spectral
%width
nCS = size(CS,1);
PhaseDegInc = PhaseDegSpread/(nCS-1);
PhaseDeg = zeros(nCS,1);
for i = 1:nCS
    if PhaseSpreadDirection == 0
        PhaseDeg(i) = (PhaseDegSpread/2.0) - ((i-1)*PhaseDegInc);
    end
    if PhaseSpreadDirection == 1
        PhaseDeg(i) = -(PhaseDegSpread/2.0) + ((i-1)*PhaseDegInc);
    end
end

ReS = real(CS);
ImS = imag(CS);
CosPhaseDeg = cosd(PhaseDeg);
SinPhaseDeg = sind(PhaseDeg);

A = times(CosPhaseDeg, ReS);
B = times(SinPhaseDeg, ImS);
C = times(SinPhaseDeg, ReS);
D = times(CosPhaseDeg, ImS);
ReS = A - B;
ImS = C + D;
RCS = complex(ReS,ImS);
end