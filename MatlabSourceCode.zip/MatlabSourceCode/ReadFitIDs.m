function FitIDs = ReadFitIDs(FN)

ExptIDs = ReadFluxModels(FN, 'ExptID', 0);
nExpts = size(ExptIDs, 2);

fileID = fopen(FN, 'r');
A = 'A';
N = 1;
Lines = {};
while ischar(A)
      A = fgetl(fileID);
      if ischar(A)
          B = split(A, ',');
          nB = size(B, 1);
          for j = 1:nB
              Lines(N, j) = B(j);
          end
          N = N + 1;
      end
end
fclose(fileID);

NLines = size(Lines, 1);
NCols = size(Lines, 2);

for i = 1:NLines
    Line = Lines(i, :);
    T = char(Line(2));
    nT = size(T, 2);
    if nT >= 1
        A = char(Line(1,1));
        B = char(Line(1,2));
        C = {[A, ' ', B]};
        Line(1,1) = C;
        Lines(i, :) = Line;
    end
end

Params = Lines(:, 1);
M = 1;
for j = 3:NCols
    Col = Lines(:,j);
    ExptID = Col(1,1);
    nRows = size(Col,1);
    N = 1;
    A = {};
    for i = 2:nRows
        T = char(Col(i));
        T = strsplit(T, ':');
        nT = size(T, 2);
        if nT >= 2
            U = char(T(1,1));
            if strcmp(U, 'Fit')
                V = Params(i, 1);
                A(N, 1) = V;
                N = N + 1;
            end
        end
    end
    R.ExptID = ExptID;
    R.XIDs = transpose(A);
    FitIDs(M,1) = R;
    M = M + 1;
end

% for i = 1, nExpts
%     T = FitIDs(i, 1);
%     U = T.ExptID
%     v = T.XIDs
% end




end

