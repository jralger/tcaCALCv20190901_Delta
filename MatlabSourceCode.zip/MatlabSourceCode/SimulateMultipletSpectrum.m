function Multiplet = SimulateMultipletSpectrum(Multiplet, ...
                          ScannerFreqMHz, SampleTimesSec, ...
                          CenterPPM, ImagSign)
ZF = 0; 
DoConj = 0;

Multiplet.ScannerFreqMHz = num2str(ScannerFreqMHz);
Multiplet.CenterPPM = num2str(CenterPPM);
Multiplet.SampleTimesSec = SampleTimesSec;        
Signals = Multiplet.Signals;
nSignals = size(Signals, 2);
for i = 1:nSignals
    Signal = Signals(i);
    T = BuildFIDOneSignal(Signal, ScannerFreqMHz, SampleTimesSec, ...
                          CenterPPM);
    if i == 1
        FID = T;
    end
    if i > 1
        FID = FID + T;
    end
end   
RFID.SampleTimesSec = SampleTimesSec;
RFID.TimeDomainDataRaw = FID;
RFID.ScannerFreqMHz = ScannerFreqMHz;
RFID.CenterPPM = CenterPPM;

if strcmp(ImagSign, '-')
    DoConj = 1;
end
Multiplet.ImagSign = ImagSign;
NormSpectrum = Recon1D(RFID, ZF, DoConj);
FD = NormSpectrum.FreqDomainData;
ReFD = real(FD);
SumReFD = sum(ReFD);
FD = FD/SumReFD;
NormSpectrum.FreqDomainData = FD;
Multiplet.NormSpectrum = NormSpectrum;
Conc = Multiplet.Conc;
CWS = NormSpectrum;
CWS.TimeDomainDataRaw = CWS.TimeDomainDataRaw*Conc;
CWS.FreqDomainData = CWS.FreqDomainData*Conc;
Multiplet.ConcWtdSpectrum = CWS;
end

