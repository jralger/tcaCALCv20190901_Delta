function handles = AddMultiplet(handles, Multiplet);
if ~isfield(handles, 'Multiplets')
   Multiplets = [Multiplet];
else
   Multiplets = handles.Multiplets;
   nM = size(Multiplets,1);
   ID = Multiplet.ID;
   Replaced = 0;
   for i=1:nM
       TestMultiplet = Multiplets(i);
       TestID = TestMultiplet.ID;
       if strmatch(ID, TestID, 'exact')
          Multiplets(i) = Multiplet;
          Replaced = 1;
       end
   end
   if Replaced == 0       
      Multiplets = cat(1, Multiplets, Multiplet);
   end
end
handles.Multiplets = Multiplets;
end

