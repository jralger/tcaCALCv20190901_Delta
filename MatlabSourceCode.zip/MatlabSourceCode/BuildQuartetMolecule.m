function [handles, Molecule] = BuildQuartetMolecule(handles, Quartet, ...
                                    LabelPattern, EstFreqsPPM, EstJAHz, ...
                                    LIdx, JCIdxLow, JCIdxHigh);
% Reassignment of EstJAHz seems circular. At some point need to determine
% if it is really necessary. for now do not want to screw up working
% software

EstJAHz(LIdx, JCIdxLow) = Quartet.JHz(1);
EstJAHz(JCIdxLow, LIdx) = EstJAHz(LIdx, JCIdxLow);
EstJAHz(LIdx, JCIdxHigh) = Quartet.JHz(2);
EstJAHz(JCIdxHigh, LIdx) = EstJAHz(LIdx, JCIdxHigh);

Spectrum = handles.Spectrum;
SF = Spectrum.ScannerFreqMHz;
SampleTimesSec = Spectrum.SampleTimesSec;
JAPPM = EstJAHz/SF;
EstFreqsPPM(LIdx) = Quartet.CenterFreqPPM;
CenterPPM = Spectrum.CenterPPM;
GlobalR2 = handles.GlobalR2;
DefaultMolConc = handles.DefaultMolConc;
Molecule = BuildIsotopMolecule(LabelPattern, EstFreqsPPM, ...
                      JAPPM, DefaultMolConc, GlobalR2, SF, ...
                      SampleTimesSec, CenterPPM);
Molecule.FreqsPPM(LIdx) = Quartet.CenterFreqPPM;
Molecule.ID = Quartet.ID;
Molecule.PlotCenters = Quartet.CenterFreqPPM;
handles = AddMolecule(handles, Molecule);
end

