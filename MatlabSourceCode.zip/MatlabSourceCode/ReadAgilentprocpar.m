function RA = ReadAgilentprocpar(FN)
RA.FN = FN;
fileID = fopen(FN,'r');
while ~feof(fileID)
      A = fgetl(fileID);
      B = strsplit(A);
      B = B(1);
      B = char(B);
      if strmatch(B, 'sfrq', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.SF = D;
      end
      if strmatch(B, 'time_complete', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.TimeComplete = D;
      end
      if strmatch(B, 'sw', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.SW = D;
      end
      if strmatch(B, 'username', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.UserName = D;
      end
      if strmatch(B, 'at', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.AT = D;
      end
      if strmatch(B, 'delta', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.Delta = D;
      end
      if strmatch(B, 'dfrq', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.DFrq = D;
      end
      if strmatch(B, 'filter', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.Filter = D;
      end
      if strmatch(B, 'gain', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.Gain = D;
      end
      if strmatch(B, 'lb1', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.LB1 = D;
      end
     if strmatch(B, 'np', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.NTPS = D;
     end
     if strmatch(B, 'operator_', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.Operator = D;
     end
     if strmatch(B, 'pad', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.Pad = D;
     end
     if strmatch(B, 'parversion', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.Parversion = D;
     end
     if strmatch(B, 'reffrq1', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.RefFreq1 = D;
     end
     if strmatch(B, 'reffrq', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.RefFreq = D;
     end
     if strmatch(B, 'rof2', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.ROF2 = D;
     end
     if strmatch(B, 'rof1', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.ROF1 = D;
     end
     if strmatch(B, 'rp', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.RP = D;
     end
     if strmatch(B, 'th', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.TH = D;
     end
     if strmatch(B, 'tn', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.TN = D;
     end
     if strmatch(B, 'tlt', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.TLT = D;
     end
     if strmatch(B, 'tpwr', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.TPWR = D;
     end
     if strmatch(B, 'tof', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.TOF = D;
     end
     if strmatch(B, 'vf', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.VF = D;
     end
     if strmatch(B, 'wf', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.WF = D;
     end
     if strmatch(B, 'wp', 'exact')
          C = fgetl(fileID);
          D = strsplit(C);
          D = D(1,2);
          D = char(D);
          RA.WP = D;
     end
end
fclose(fileID);
end

