function [V, LB, UB] = ReadLabelledSubstrate(FN, ID, LabelPattern, nExpts)
% NOTE Not the same as tcaSIM

V = zeros(1, nExpts);
LB = zeros(1,nExpts);
UB = zeros(1,nExpts);

V(1, :) = -1.0;
LB(1, :) = -1.0;
UB(1, :) = -1.0;


fileID = fopen(FN, 'r');
A = 'A';
while ischar(A)
      A = fgetl(fileID);
      if ischar(A)
          B = strsplit(A, ',');
          nB = size(B, 2);
          if strcmp(B(1), ID)
              if strcmp(B(2), LabelPattern)
                 fclose(fileID);
                 T = B(3:nB);
                 for i = 1:nExpts
                     U = char(T(1, i));
                     W = strsplit(U, ':');
                     nW = size(W, 2);
                     if nW == 1
                         Z = W;
                     end
                     if nW >= 2
                         Z = W(2);
                     end
                     Z = char(Z);
                     V(1, i) = str2double(Z);  
                     if nW >= 3
                         L = W(3);
                         L = char(L);
                         LB(1, i) = str2double(L);
                     end
                     if nW >= 4
                         U = W(4);
                         U = char(U);
                         UB(1, i) = str2double(U);
                     end
                     
%                      dummy = 1;
                 end
                 return
              end
          end
      end
end          
fclose(fileID);
end


