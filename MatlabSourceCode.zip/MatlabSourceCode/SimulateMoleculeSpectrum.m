function Molecule = SimulateMoleculeSpectrum(Molecule, ScannerFreqMHz, ...
                    SampleTimesSec, CenterPPM, ImagSign)
ZF = 0; 
Molecule.ScannerFreqMHz = num2str(ScannerFreqMHz);
Molecule.CenterPPM = num2str(CenterPPM);
Molecule.SampleTimesSec = SampleTimesSec;        
Signals = Molecule.Signals;
nSignals = size(Signals, 2);
for i=1:nSignals
    Signal = Signals(i);
    T = BuildFIDOneSignal(Signal, ScannerFreqMHz, SampleTimesSec, CenterPPM);
    if i == 1
        FID = T;
    end
    if i > 1
        FID = FID + T;
    end
end   
RFID.SampleTimesSec = SampleTimesSec;
RFID.TimeDomainDataRaw = FID;
RFID.ScannerFreqMHz = ScannerFreqMHz;
RFID.CenterPPM = CenterPPM;
DoConj = 0;
if strmatch(ImagSign, '-')
    DoConj = 1;
end
Molecule.ImagSign = ImagSign;
NormSpectrum = Recon1D(RFID, ZF, DoConj);
Molecule.NormSpectrum = NormSpectrum;
Conc = Molecule.Conc;
ConcWtdSpectrum = NormSpectrum;
ConcWtdSpectrum.TimeDomainDataRaw = ConcWtdSpectrum.TimeDomainDataRaw*Conc;
ConcWtdSpectrum.FreqDomainData = ConcWtdSpectrum.FreqDomainData*Conc;
Molecule.ConcWtdSpectrum = ConcWtdSpectrum;
end

