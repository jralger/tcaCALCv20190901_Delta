function V = EstimateTwoCarbonNaturalAbundance()
[oo, xo, ox, xx] = DefineTwoCarbonLabelIndices();
V = zeros(1,4);
V(1, oo) = 1.0;
end

