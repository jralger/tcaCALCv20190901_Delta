function [handles, A] = ReadUpdateAllFiveCarbonIsotopomers(handles)

[ooooo, xoooo, oxooo, xxooo, ...
 ooxoo, xoxoo, oxxoo, xxxoo, ...
 oooxo, xooxo, oxoxo, xxoxo, ...
 ooxxo, xoxxo, oxxxo, xxxxo, ...
 oooox, xooox, oxoox, xxoox, ...
 ooxox, xoxox, oxxox, xxxox, ...
 oooxx, xooxx, oxoxx, xxoxx, ...
 ooxxx, xoxxx, oxxxx, xxxxx] = DefineFiveCarbonLabelIndices();

A = zeros(1,32);

A(1, xoooo) = str2double(handles.XOOOO.String);
A(1, oxooo) = str2double(handles.OXOOO.String);
A(1, xxooo) = str2double(handles.XXOOO.String);

A(1, ooxoo) = str2double(handles.OOXOO.String);
A(1, xoxoo) = str2double(handles.XOXOO.String);
A(1, oxxoo) = str2double(handles.OXXOO.String);
A(1, xxxoo) = str2double(handles.XXXOO.String);

A(1, oooxo) = str2double(handles.OOOXO.String);
A(1, xooxo) = str2double(handles.XOOXO.String);
A(1, oxoxo) = str2double(handles.OXOXO.String);
A(1, xxoxo) = str2double(handles.XXOXO.String);

A(1, ooxxo) = str2double(handles.OOXXO.String);
A(1, xoxxo) = str2double(handles.XOXXO.String);
A(1, oxxxo) = str2double(handles.OXXXO.String);
A(1, xxxxo) = str2double(handles.XXXXO.String);

A(1, oooox) = str2double(handles.OOOOX.String);
A(1, xooox) = str2double(handles.XOOOX.String);
A(1, oxoox) = str2double(handles.OXOOX.String);
A(1, xxoox) = str2double(handles.XXOOX.String);

A(1, ooxox) = str2double(handles.OOXOX.String);
A(1, xoxox) = str2double(handles.XOXOX.String);
A(1, oxxox) = str2double(handles.OXXOX.String);
A(1, xxxox) = str2double(handles.XXXOX.String);

A(1, oooxx) = str2double(handles.OOOXX.String);
A(1, xooxx) = str2double(handles.XOOXX.String);
A(1, oxoxx) = str2double(handles.OXOXX.String);
A(1, xxoxx) = str2double(handles.XXOXX.String);

A(1, ooxxx) = str2double(handles.OOXXX.String);
A(1, xoxxx) = str2double(handles.XOXXX.String);
A(1, oxxxx) = str2double(handles.OXXXX.String);
A(1, xxxxx) = str2double(handles.XXXXX.String);

A = UpdateUnLabelledIsotopomer(A);

if A(1, ooooo) < 0
    A = zeros(1, 32);
    A = UpdateUnLabelledIsotopomer(A);
end

handles.OOOOO.String = sprintf('%4.2f', A(1, ooooo));
handles.XOOOO.String = sprintf('%4.2f', A(1, xoooo));
handles.OXOOO.String = sprintf('%4.2f', A(1, oxooo));
handles.XXOOO.String = sprintf('%4.2f', A(1, xxooo));

handles.OOXOO.String = sprintf('%4.2f', A(1, ooxoo));
handles.XOXOO.String = sprintf('%4.2f', A(1, xoxoo));
handles.OXXOO.String = sprintf('%4.2f', A(1, oxxoo));
handles.XXXOO.String = sprintf('%4.2f', A(1, xxxoo));

handles.OOOXO.String = sprintf('%4.2f', A(1, oooxo));
handles.XOOXO.String = sprintf('%4.2f', A(1, xooxo));
handles.OXOXO.String = sprintf('%4.2f', A(1, oxoxo));
handles.XXOXO.String = sprintf('%4.2f', A(1, xxoxo));

handles.OOXXO.String = sprintf('%4.2f', A(1, ooxxo));
handles.XOXXO.String = sprintf('%4.2f', A(1, xoxxo));
handles.OXXXO.String = sprintf('%4.2f', A(1, oxxxo));
handles.XXXXO.String = sprintf('%4.2f', A(1, xxxxo));

handles.OOOOX.String = sprintf('%4.2f', A(1, oooox));
handles.XOOOX.String = sprintf('%4.2f', A(1, xooox));
handles.OXOOX.String = sprintf('%4.2f', A(1, oxoox));
handles.XXOOX.String = sprintf('%4.2f', A(1, xxoox));

handles.OOXOX.String = sprintf('%4.2f', A(1, ooxox));
handles.XOXOX.String = sprintf('%4.2f', A(1, xoxox));
handles.OXXOX.String = sprintf('%4.2f', A(1, oxxox));
handles.XXXOX.String = sprintf('%4.2f', A(1, xxxox));

handles.OOOXX.String = sprintf('%4.2f', A(1, oooxx));
handles.XOOXX.String = sprintf('%4.2f', A(1, xooxx));
handles.OXOXX.String = sprintf('%4.2f', A(1, oxoxx));
handles.XXOXX.String = sprintf('%4.2f', A(1, xxoxx));

handles.OOXXX.String = sprintf('%4.2f', A(1, ooxxx));
handles.XOXXX.String = sprintf('%4.2f', A(1, xoxxx));
handles.OXXXX.String = sprintf('%4.2f', A(1, oxxxx));
handles.XXXXX.String = sprintf('%4.2f', A(1, xxxxx));

end

