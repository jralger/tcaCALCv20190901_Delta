function [Isotops, VersionID] = ...
                    SimulateIsotopomers(...
                           nTCAturns, ...
                           GK, PDH, PK, ROF, RSM, TPI, Ypc, Ys, ...
                           EaKG2aKG, ECit2Cit, EOAA2OAA, ....
                           ICO2, IFAs, IGlc, IGlyc, ILac, ISuccYs, ...
                           UseExactNaturalAbundance)
ACS = 0.5;
VersionID = '20180831A';

% Whether to mix CO2 produced by various reactions (Default = 0 (No))
% reserve this for future experimentation
% default = No means that labelled CO2 produced by any reaction is lost
MixCO2Labels = 0;

% input is defined 
% by UseExactNaturalAbundance.
% The natural abundance of 13C is defined by Define13CNaturalAbundance()
NaturalAbundance = Define13CNaturalAbundance();

% Inputs 
% nTCAturns: Number of TCA Cycle turns to simulate

% Input rate parameters
% each of these is a (1,1) float
% Alphabetical order in the pass list to avoid errors
% CS: Citrate Synthetase (defaults to 1.0)
% GK: Glycerol Kinase
% GNR: GlucoNeogenesis Rate
% GOP: - not used
% GUR: Glucose Utilization Rate - not used
% PDH: Pyruvate Dehydrogenase
% PK: Pyrvate Kinase
% ROF: Randomization of Fumarate
% RSM: Randomization of Succinate
% TPI: Triose Phosphate Isomerase
% Ypc: Pyruvate Carboxylase
% Ys: Anaplerosis from Succinate
% UseExactNaturalAbundance: whether to use simple or exact natural abundance 

% Input Isotopomers
% each of these is float(1,nIsotopomers)
% where nIsotopomers is the total number of possible isotopomers
% eg IGlc = float(1, 64)
% Alphabetical order in the pass list to avoid errors
% ICO2: Bicarbonate  input
% IFAs: Fatty Acids  input
% IGlc: Glucose  input - Not Used
% IGlyc: Glycerol  input
% ILac: Lactate  input
% ISuccYs: 4 carbon anaplerotic input


% Outputs
% not all intermediates passed back to calling program in this version
% each of these is float(nTCAturns, nIsotopomers)
% eg aKG = float(35, 32)
% Alphabetical order in the pass list to avoid errors
% % % % AcA: AcetylCoA
% % % % aKG: alphaKetoGlutarate
% % % % Ala: Alanine
% % % % Cit: Citrate
% % % % CO2: Bicarbonate
% % % % DHAP: DyhydroxyAcetonePhosphate
% % % % ECit: Exchanging Citrate
% % % % EaKG: Exchanging alphaKetoGlutarate
% % % % EOAA: Exchanging Oxaloacetate 
% % % % FAs: Fatty Acids
% % % % Glc: Glucose
% % % % Glyc: Glycerol
% % % % G3P: Glycerol-3-Phosphate
% % % % G6P: Glucose-6-Phosphate
% % % % Lac: Lactate
% % % % OAA: Oxaloacetate
% % % % PEP: PhosphoEnolPyruvate
% % % % Pyr: Pyruvate
% % % % Succ: Succinate
% % % % SuccYs: 4 carbon anaplerotic ;

% begin calculations here
CO2 = zeros(nTCAturns, 2);
CO2(1, :) =  ICO2;

FAs = zeros(nTCAturns, 4);
FAs(1, :) =  IFAs;

% Glc = zeros(nTCAturns, 64);
% Glc(1, :) =  IGlc;

% Glyc = zeros(nTCAturns, 8);
% Glyc(1, :) =  IGlyc;

Glyc = zeros(nTCAturns, 8);
Glyc(1, :) =  IGlyc;

Lac = zeros(nTCAturns, 8);
Lac(1, :) =  ILac;

SuccYs = zeros(nTCAturns, 16);
SuccYs(1, :) =  ISuccYs;

% Mass balance expressions (used to compute various other rates)
% dPEP/dt = PEPCK + GK - GNR - PK = 0
% dPyr/dt = PK + LDH - YPC - PDH = 0
% dAcA/dt = ACoAS + PDH - CS = 0
% dSucc/dt = Ys + CS - Ys - CS = 0  (trivial)
% dOAA/dt = Ys + CS + YPC - PEPCK - CS = 0
% dG3P/dt = PEPCK + GUR - GNR - PK
% dPEP/dt = PEPCK + GUR - GNR - PK

% Citrate synthetase default to 1.0
CS = 1.0;

% dOAA/dt = Ys + Ypc - PEPCK = 0
PEPCK = Ys + Ypc;

% dPyr/dt = PK + LDH - YPC - PDH = 0
LDH = Ypc + PDH - PK;
if LDH < 0 
    txt = 'LDH is less than 0. PK is larger than Ypc + PDH.';
%     P = imread('tcaSim20180831A.png');
%     h = msgbox(txt, 'Error', 'error', 'custom', P);
%     h = uiwait(msgbox(txt, 'Error'));
%     uiwait(msgbox('Operation Completed','Success','modal'));
    uiwait(msgbox(txt,'Error','modal'));
    quit;
end

% dAcA/dt = ACS + PDH - CS = 0
ACS = CS - PDH;

% dPEP/dt = PEPCK + GK - GNR - PK = 0
% GNR = PEPCK + GK - PK;
GNR = Ys + Ypc + GK - PK;

% Default until glyoxylate pathway incorporated
ICDH = CS;

% Define/initialize intermediate pools
AcA = zeros(nTCAturns, 4);
OAA = zeros(nTCAturns, 16);
EOAA = zeros(nTCAturns, 16);
Cit = zeros(nTCAturns, 64);
ECit = zeros(nTCAturns, 64);
aKG = zeros(nTCAturns, 32);
EaKG = zeros(nTCAturns, 32);
Succ = zeros(nTCAturns, 16);
Pyr = zeros(nTCAturns, 8);
PEP = zeros(nTCAturns, 8);
DHAP = zeros(nTCAturns, 8);
G6P = zeros(nTCAturns, 64);
Ala = zeros(nTCAturns, 8);
GA3P = zeros(nTCAturns, 8);
Glc = zeros(nTCAturns, 64);
bHB = zeros(nTCAturns, 16);

% Sets initial intermediates to natural abundance
% the lines given below set the initial enrichment for each of molecules to
% natural abundance (always the first isotopomer eg Glc(oooooo)
AcA(1, :) = EstimateTwoCarbonNaturalAbundance();
OAA(1, :) = EstimateFourCarbonNaturalAbundance();
EOAA(1, :) = EstimateFourCarbonNaturalAbundance();
Cit(1, :) = EstimateSixCarbonNaturalAbundance();
ECit(1, :) = EstimateSixCarbonNaturalAbundance();
aKG(1, :) = EstimateFiveCarbonNaturalAbundance();
EaKG(1, :) = EstimateFiveCarbonNaturalAbundance();
Succ(1, :) = EstimateFourCarbonNaturalAbundance();
Pyr(1, :) = EstimateThreeCarbonNaturalAbundance();
PEP(1, :) = EstimateThreeCarbonNaturalAbundance();
DHAP(1, :) = EstimateThreeCarbonNaturalAbundance();
G6P(1, :) = EstimateSixCarbonNaturalAbundance();
Ala(1, :) = EstimateThreeCarbonNaturalAbundance();
GA3P(1, :) = EstimateThreeCarbonNaturalAbundance();

if UseExactNaturalAbundance == 1
    NaturalAbundance = Define13CNaturalAbundance();
    AcA(1, :) = BuildTwoCarbonNaturalAbundance(NaturalAbundance);
    OAA(1, :) = BuildFourCarbonNaturalAbundance(NaturalAbundance);
    EOAA(1, :) = BuildFourCarbonNaturalAbundance(NaturalAbundance);
    Cit(1, :) = BuildSixCarbonNaturalAbundance(NaturalAbundance);
    ECit(1, :) = BuildSixCarbonNaturalAbundance(NaturalAbundance);
    aKG(1, :) = BuildFiveCarbonNaturalAbundance(NaturalAbundance);
    EaKG(1, :) = BuildFiveCarbonNaturalAbundance(NaturalAbundance);
    Succ(1, :) = BuildFourCarbonNaturalAbundance(NaturalAbundance);
    Pyr(1, :) = BuildThreeCarbonNaturalAbundance(NaturalAbundance);
    PEP(1, :) = BuildThreeCarbonNaturalAbundance(NaturalAbundance);
    DHAP(1, :) = BuildThreeCarbonNaturalAbundance(NaturalAbundance);
    G6P(1, :) = BuildSixCarbonNaturalAbundance(NaturalAbundance);
    Ala(1, :) = BuildThreeCarbonNaturalAbundance(NaturalAbundance);
    GA3P(1, :) = BuildThreeCarbonNaturalAbundance(NaturalAbundance);
end

%Preallocate arrays for speed
CO2_PDH = CO2;
Pyr_PK = Pyr;
Pyr_LDH = Pyr;

m = 1;
while m <= nTCAturns
    if (PK+LDH) ~= 0 
        Pyr_PK(m, :) = PEP(m, :);
        Pyr_LDH(m, :) = Lac(m, :);
        Pyr = CombineThreeLabelPools(Pyr_PK, Pyr_LDH, Pyr, m, ...
                                      PK/(PK+LDH), LDH/(PK+LDH));
    end
    Ala(m, :) = Pyr(m, :);
    CO2_PDH(m, :) = CO2(m, :);
    if (ACS+PDH) ~= 0
        AcA_ACS= AcetylCoASynthetase(FAs, AcA, m);         
        [AcA_PDH, CO2_PDH] = PyruvateDehydrogenase(Pyr, AcA, CO2, m);
        AcA = CombineThreeLabelPools(AcA_ACS, AcA_PDH, AcA, m, ...
                                      ACS/(ACS+PDH), PDH/(ACS+PDH));
        bHB = Ketogenesis(AcA, bHB, m);
    end
    Cit = CitrateSynthetase(OAA, AcA, Cit, m);
    [Cit, ECit] = ExchangeLabelsTwoPools(Cit, ECit, m, ECit2Cit);
    [aKG, CO2_ICDH] = IsoCitrateDehydrogenase(Cit, aKG, CO2, m);
    [aKG, EaKG] = ExchangeLabelsTwoPools(aKG, EaKG, m, EaKG2aKG);
    [CO2_aKGD, Succ] = aKetoGlutarateDehydrogenase(aKG, Succ, CO2, m);
    Succ = CombineTwoLabelPools(SuccYs, Succ, m, Ys/(ICDH+Ys));
    Succ = RandomizeSuccinate(Succ, m, RSM);
    OAA(m, :) = Succ(m, :);
    OAA_PC = PyruvateCarboxylase(Pyr, CO2, OAA, m);
    OAA_PC = RandomizeFumarate(OAA_PC, m, ROF);
    OAA = CombineTwoLabelPools(OAA_PC, OAA, m, Ypc/(Ys+CS+Ypc));
    [OAA, EOAA] = ExchangeLabelsTwoPools(OAA, EOAA, m, EOAA2OAA);
    [CO2_PEPCK, PEP_PEPCK] = PhosphoEnolPyruvateCarboxyKinase(OAA, PEP, CO2, m);
    if PEPCK ~= 0
        PEP(m, :) = PEP_PEPCK(m, :);
    end
    if PEPCK == 0
        PEP(m, :) = Pyr(m, :);
    end
    GA3P(m ,:) = PEP(m, :);
%     DHAP_GK(m, :) = Glyc(m, :);
%     DHAP = CombineTwoLabelPools(DHAP_GK, DHAP, m, GK/(Ys + Ypc + GK));
%     %need to check on logic of Glyc labelling  19 Aug 2018
    DHAP(m, :) = Glyc(m, :);     
    [DHAP, GA3P] = TriosePhosphateIsomerase(DHAP, GA3P, m, TPI);
    G6P = Gluconeogenesis(DHAP, GA3P, G6P, m);
    Glc(m,:) = G6P(m, :);
    
    if MixCO2Labels == 1
        RT = PDH + ICDH + ICDH + PEPCK;
        CO2 = CombineFiveLabelPools(CO2_PDH, ...
                     CO2_ICDH, ...
                     CO2_aKGD, ...
                     CO2_PEPCK, ...
                     CO2, ...
                     m, ...
                     PDH/RT, ...
                     ICDH/RT, ...
                     ICDH/RT, ...
                     PEPCK/RT);
    end
%     GA3P(m, :) = PEP(m, :);

    if m ~= nTCAturns
        FAs(m+1, :) = FAs(m, :);
        AcA(m+1, :) = AcA(m, :);
        OAA(m+1, :) = OAA(m, :);
        EOAA(m+1, :) = EOAA(m, :);
        SuccYs(m+1, :) = SuccYs(m, :);
        Succ(m+1, :) = Succ(m, :);
        Lac(m+1, :) = Lac(m, :);
        Pyr(m+1, :) = Pyr(m, :);
        CO2(m+1, :) = CO2(m, :);
        aKG(m+1, :) = aKG(m, :);
        EaKG(m+1, :) = EaKG(m, :);
        Ala(m+1, :) = Ala(m, :);
        Cit(m+1, :) = Cit(m, :);
        ECit(m+1, :) = ECit(m, :);
        GA3P(m+1, :) = GA3P(m, :);
        PEP(m+1, :) = PEP(m, :);
        Glyc(m+1, :) = Glyc(m, :);
    end
    m = m + 1;
end
nTurnsCompleted = m - 1;


Isotops.Pyr = Pyr; 
Isotops.Ala = Ala;
Isotops.CO2_PDH = CO2_PDH;
Isotops.AcA = AcA;
Isotops.Cit = Cit;
Isotops.ECit = ECit;
Isotops.CO2_ICDH = CO2_ICDH;
Isotops.aKG = aKG;
Isotops.EaKG = EaKG;
Isotops.CO2_aKGD = CO2_aKGD;
Isotops.Succ = Succ;
Isotops.OAA = OAA; 
Isotops.EOAA = EOAA;
Isotops.CO2_PEPCK = CO2_PEPCK;
Isotops.PEP = PEP;
Isotops.DHAP = DHAP;
Isotops.GA3P = GA3P;
Isotops.G6P = G6P;
Isotops.Glc = Glc;
Isotops.CO2 = CO2;
Isotops.Lac = Lac;
Isotops.SuccYs = SuccYs;
Isotops.Glyc = Glyc;
Isotops.bHB = bHB;
end

