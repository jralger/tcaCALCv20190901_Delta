function RMolecules = ScaleMultipletFits(Molecules);

%finds the unique multiplet IDs
nMs = size(Molecules,1);
MIDs = cell(nMs,1);
m = 1;
for i = 1:nMs
    Molecule = Molecules(i);
    ID = Molecule.ID;
    T = strsplit(ID); 
    T = [char(T(1)), ' ', char(T(2))];
    n = size(T,2);
    if i == 1
        MIDs(m, 1) = {T};
        m = m + 1;
    end
    if strncmp(T, MIDs, n) == 0
        MIDs(m, 1) = {T};
        m = m + 1;
    end  
end
m = m - 1;
MIDs = MIDs(1:m, 1);


% finds the total best fit conc and total best fit integral for each
% multiplet
nMIDs = size(MIDs, 1);
TotConcs = zeros(nMIDs, 1);
TotIntegrals = zeros(nMIDs, 1);
for i = 1:nMIDs
    MID = char(MIDs(i));
    T = 0.0;
    U = 0.0;
    for j = 1:nMs
        Molecule = Molecules(j);
        CWS = Molecule.ConcWtdSpectrum;
        CS = CWS.FreqDomainData;
        RS = real(CS);
        ID = Molecule.ID;
        ID = strsplit(ID); 
        ID = [char(ID(1)), ' ', char(ID(2))];
        if strcmp(MID, ID)
            T = T + Molecule.Conc;
            U = U + sum(RS);
        end
    end
    TotConcs(i) = T;
    TotIntegrals(i) = U;
end

%creates Molecules array that will be returned
for i = 1:nMs
    Molecule = Molecules(i, 1);
    Molecule.FractionalConc = 0.0;
    Molecule.FractionalIntegral = 0.0;
    RMolecules(i,1) = Molecule;
end

%calculates fractional intensity and integral for each molecule
for i = 1:nMs
    Molecule = RMolecules(i);
    CWS = Molecule.ConcWtdSpectrum;
    CS = CWS.FreqDomainData;
    RS = real(CS);
    ID = Molecule.ID;
    ID = strsplit(ID); 
    ID = [char(ID(1)), ' ', char(ID(2))];
    for j = 1:nMIDs
        MID = char(MIDs(j));    
        if strcmp(MID, ID)
           FractionalConc = 0.0;
           if TotConcs(j) > 0
               FractionalConc = Molecule.Conc/TotConcs(j);
           end
           FractionalIntegral = 0.0;
           if TotIntegrals(j) > 0
              FractionalIntegral = sum(RS)/TotIntegrals(j);
           end
           Molecule.FractionalConc = FractionalConc;
           Molecule.FractionalIntegral = FractionalIntegral;
           RMolecules(i,1) = Molecule;
        end
    end
end
end

