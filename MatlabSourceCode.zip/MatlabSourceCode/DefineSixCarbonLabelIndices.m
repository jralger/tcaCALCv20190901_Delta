function [oooooo, xooooo, oxoooo, xxoooo, ...
          ooxooo, xoxooo, oxxooo, xxxooo, ...
          oooxoo, xooxoo, oxoxoo, xxoxoo, ...
          ooxxoo, xoxxoo, oxxxoo, xxxxoo, ...
          ooooxo, xoooxo, oxooxo, xxooxo, ...
          ooxoxo, xoxoxo, oxxoxo, xxxoxo, ...
          oooxxo, xooxxo, oxoxxo, xxoxxo, ...
          ooxxxo, xoxxxo, oxxxxo, xxxxxo, ...
          ooooox, xoooox, oxooox, xxooox, ...
          ooxoox, xoxoox, oxxoox, xxxoox, ...
          oooxox, xooxox, oxoxox, xxoxox, ...
          ooxxox, xoxxox, oxxxox, xxxxox, ...
          ooooxx, xoooxx, oxooxx, xxooxx, ...
          ooxoxx, xoxoxx, oxxoxx, xxxoxx, ...
          oooxxx, xooxxx, oxoxxx, xxoxxx, ...
          ooxxxx, xoxxxx, oxxxxx, xxxxxx] ...
                                            = DefineSixCarbonLabelIndices()

% This function defines the label indices for a six carbon molecule
% using notation developed by Craig Malloy 
% o means C12 and x means C13
% eg xxxooo means a six carbon moelcule labelled with C13 at carbons 1 and
% 2 and 3
% there are no inputs
% returns the numerical values of indices for all possible isotopomers                                      
                                        
                                        
oooooo = 1;   
xooooo = 2;
oxoooo = 3;
xxoooo = 4;

ooxooo = 5;
xoxooo = 6;
oxxooo = 7;
xxxooo = 8;
      
oooxoo = 9;
xooxoo = 10;
oxoxoo = 11;
xxoxoo = 12;
      
ooxxoo = 13;
xoxxoo = 14;
oxxxoo = 15;
xxxxoo = 16;
      
ooooxo = 17;
xoooxo = 18;
oxooxo = 19;
xxooxo = 20;

ooxoxo = 21;
xoxoxo = 22;
oxxoxo = 23;
xxxoxo = 24;

oooxxo = 25;
xooxxo = 26;
oxoxxo = 27;
xxoxxo = 28;

ooxxxo = 29;
xoxxxo = 30;
oxxxxo = 31;
xxxxxo = 32;

ooooox = 33;   
xoooox = 34;
oxooox = 35;
xxooox = 36;

ooxoox = 37;
xoxoox = 38;
oxxoox = 39;
xxxoox = 40;
      
oooxox = 41;
xooxox = 42;
oxoxox = 43;
xxoxox = 44;
      
ooxxox = 45;
xoxxox = 46;
oxxxox = 47;
xxxxox = 48;
      
ooooxx = 49;
xoooxx = 50;
oxooxx = 51;
xxooxx = 52;

ooxoxx = 53;
xoxoxx = 54;
oxxoxx = 55;
xxxoxx = 56;

oooxxx = 57;
xooxxx = 58;
oxoxxx = 59;
xxoxxx = 60;

ooxxxx = 61;
xoxxxx = 62;
oxxxxx = 63;
xxxxxx = 64;      

end

