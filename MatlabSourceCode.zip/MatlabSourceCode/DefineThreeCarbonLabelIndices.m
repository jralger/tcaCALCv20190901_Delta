function [ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                                            DefineThreeCarbonLabelIndices()

% This function defines the label indices for a three carbon molecule
% using notation developed by Craig Malloy 
% o means C12 and x means C13
% eg xox means a three carbon moelcule labelled with C13 at carbons 1 and 3
% there are no inputs
% returns the numerical values of indices for all possible isotopomers                                           
                                        
ooo = 1;
xoo = 2;
oxo = 3;
xxo = 4;

oox = 5;
xox = 6;
oxx = 7;
xxx = 8;
end

