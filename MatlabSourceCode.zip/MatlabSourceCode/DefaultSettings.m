function varargout = DefaultSettings(varargin)
% Last Modified by GUIDE v2.5 20-May-2020 14:11:27

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DefaultSettings_OpeningFcn, ...
                   'gui_OutputFcn',  @DefaultSettings_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before DefaultSettings is made visible.
function DefaultSettings_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
MMs = varargin{1,1};
handles.MetabolicModels = MMs;
handles.InitialMetabolicModels = MMs;
CMM = MMs(1,1);
handles.CurrentMetabolicModel = CMM;
handles = SetDisplayParams(handles, CMM);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes DefaultSettings wait for user response (see UIRESUME)
uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = DefaultSettings_OutputFcn(hObject, eventdata, handles) 
varargout = {handles.MetabolicModels};
close(handles.figure1);


function EditExptID_Callback(hObject, eventdata, handles)
TID = get(hObject,'String');
CMM = handles.CurrentMetabolicModel;
MMs = handles.MetabolicModels;
nMMs = size(MMs, 2);
for i = 1:nMMs
    MM = MMs(1,i);
    ModelIDs(1,i) = {MM.ExptID};
end
idx = strcmp(ModelIDs, TID);
if any(idx)
    CMM = MMs(1, idx);
    handles.CurrentMetabolicModel = CMM;
end
handles = SetDisplayParams(handles, CMM);
guidata(hObject, handles);
    

function EditExptID_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function EditnTurns_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanTwo(V);
handles = EditRespond(handles, V, 'EditnTurns',  'nTurns');
handles.EditnTurns.String = sprintf('%d', V);
guidata(hObject, handles);


function EditnTurns_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditPDH0_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
V = FixGreaterThanOne(V);
handles = EditRespond(handles, V, 'EditPDH0',  'PDH');
guidata(hObject, handles);

function EditPDH0_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditYPC0_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditYPC0', 'YPC');
guidata(hObject, handles);


function EditYPC0_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditPK0_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditPK0', 'PK');
guidata(hObject, handles);


function EditPK0_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function EditYs0_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditYs0', 'Ys');
guidata(hObject, handles);


function EditYs0_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditYGln0_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditYGln0', 'YGln');
guidata(hObject, handles);


function EditYGln0_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditGK0_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditGK0', 'GK');
guidata(hObject, handles);


function EditGK0_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditTPI0_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
V = FixGreaterThanOne(V);
handles = EditRespond(handles, V, 'EditTPI0', 'TPI');
guidata(hObject, handles);


function EditTPI0_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditROF0_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
V = FixGreaterThanOne(V);
handles = EditRespond(handles, V, 'EditROF0', 'ROF');
guidata(hObject, handles);


function EditROF0_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditRSM0_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
V = FixGreaterThanOne(V);
handles = EditRespond(handles, V, 'EditRSM0', 'RSM');
guidata(hObject, handles);


function EditRSM0_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditEOAA0_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditEOAA0', 'EOAA');
guidata(hObject, handles);


function EditEOAA0_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditECit0_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditECit0', 'ECit');
guidata(hObject, handles);


function EditECit0_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditEaKG0_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditEaKG0', 'EaKG');
guidata(hObject, handles);


function EditEaKG0_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function CBExactNA_Callback(hObject, eventdata, handles)
V = get(hObject,'Value');
CMM = handles.CurrentMetabolicModel;

C13NA = V*Define13CNaturalAbundance();
SuccYs = BuildFourCarbonNaturalAbundance(C13NA);
Lac = BuildThreeCarbonNaturalAbundance(C13NA);
Glyc = BuildThreeCarbonNaturalAbundance(C13NA);
FA = BuildTwoCarbonNaturalAbundance(C13NA);
CO2 = BuildOneCarbonNaturalAbundance(C13NA);
Gln = BuildFiveCarbonNaturalAbundance(C13NA);

CMM.ExactNaturalAbundance = V;
CMM.SuccYs = SuccYs;
CMM.Lac = Lac;
CMM.Glyc = Glyc;
CMM.FA = FA;
CMM.CO2 = CO2;
CMM.Gln = Gln;
handles.CurrentMetabolicModel = CMM;
handles = InsertMetabolicModel(handles, CMM);
Q = handles.CBChangeAllModels.Value;
if Q
    MMs = handles.MetabolicModels;
    nMMs = size(MMs, 2);
    for i = 1:nMMs
        MM = MMs(1, i);
        MM.ExactNaturalAbundance = V;
        MM.SuccYs = SuccYs;
        MM.Lac = Lac;
        MM.Glyc = Glyc;
        MM.FA = FA;
        MM.CO2 = CO2;
        MM.Gln = Gln;
        NMMs(1,i) = MM;
    end
    handles.MetabolicModels = NMMs;
end
guidata(hObject, handles);


function CBFitPDH_Callback(hObject, eventdata, handles)
V = get(hObject,'Value');
XID = 'PDH';
handles = RespondFitCheck(handles, V, XID);
guidata(hObject, handles);


function CBFitYPC_Callback(hObject, eventdata, handles)
V = get(hObject,'Value');
XID = 'YPC';
handles = RespondFitCheck(handles, V, XID);
guidata(hObject, handles);


function CBFitPK_Callback(hObject, eventdata, handles)
V = get(hObject,'Value');
XID = 'PK';
handles = RespondFitCheck(handles, V, XID);
guidata(hObject, handles);


function CBFitYs_Callback(hObject, eventdata, handles)
V = get(hObject,'Value');
XID = 'Ys';
handles = RespondFitCheck(handles, V, XID);
guidata(hObject, handles);


function CBFitYGln_Callback(hObject, eventdata, handles)
V = get(hObject,'Value');
XID = 'YGln';
handles = RespondFitCheck(handles, V, XID);
guidata(hObject, handles);


function CBFitGK_Callback(hObject, eventdata, handles)
V = get(hObject,'Value');
XID = 'GK';
handles = RespondFitCheck(handles, V, XID);
guidata(hObject, handles);


function CBFitTPI_Callback(hObject, eventdata, handles)
V = get(hObject,'Value');
XID = 'TPI';
handles = RespondFitCheck(handles, V, XID);
guidata(hObject, handles);


function CBFitROF_Callback(hObject, eventdata, handles)
V = get(hObject,'Value');
XID = 'ROF';
handles = RespondFitCheck(handles, V, XID);
guidata(hObject, handles);


function CBFitRSM_Callback(hObject, eventdata, handles)
V = get(hObject,'Value');
XID = 'RSM';
handles = RespondFitCheck(handles, V, XID);
guidata(hObject, handles);


function CBFitEOAA_Callback(hObject, eventdata, handles)
V = get(hObject,'Value');
XID = 'EOAA';
handles = RespondFitCheck(handles, V, XID);
guidata(hObject, handles);


function CBFitECit_Callback(hObject, eventdata, handles)
V = get(hObject,'Value');
XID = 'ECit';
handles = RespondFitCheck(handles, V, XID);
guidata(hObject, handles);


function CBFitEaKG_Callback(hObject, eventdata, handles)
V = get(hObject,'Value');
XID = 'EaKG';
handles = RespondFitCheck(handles, V, XID);
guidata(hObject, handles);


function EditPDHLB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
V = FixGreaterThanOne(V);
handles = EditRespond(handles, V, 'EditPDHLB', 'PDHLB');
guidata(hObject, handles);


function EditPDHLB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditYPCLB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditYPCLB', 'YPCLB');
guidata(hObject, handles);


function EditYPCLB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditPKLB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditPKLB', 'PKLB');
guidata(hObject, handles);


function EditPKLB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditYsLB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditYsLB', 'YsLB');
guidata(hObject, handles);


function EditYsLB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditYGlnLB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditYGlnLB', 'YGlnLB');
guidata(hObject, handles);


function EditYGlnLB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditGKLB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditGKLB', 'GKLB');
guidata(hObject, handles);


function EditGKLB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditTPILB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
V = FixGreaterThanOne(V);
handles = EditRespond(handles, V, 'EditTPILB', 'TPILB');
guidata(hObject, handles);


function EditTPILB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditROFLB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
V = FixGreaterThanOne(V);
handles = EditRespond(handles, V, 'EditROFLB', 'ROFLB');
guidata(hObject, handles);


function EditROFLB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditRSMLB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
V = FixGreaterThanOne(V);
handles = EditRespond(handles, V, 'EditRSMLB', 'RSMLB');
guidata(hObject, handles);


function EditRSMLB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditEOAALB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditEOAALB', 'EOAALB');
guidata(hObject, handles);


function EditEOAALB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditECitLB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditECitLB', 'ECitLB');
guidata(hObject, handles);


function EditECitLB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditEaKGLB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditEaKGLB', 'EaKGLB');
guidata(hObject, handles);


function EditEaKGLB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function CBFitnTurns_Callback(hObject, eventdata, handles)
V = get(hObject,'Value');
XID = 'nTurns';
handles = RespondFitCheck(handles, V, XID);
guidata(hObject, handles);


function EditnTurnsLB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanTwo(V);
handles = EditRespond(handles, V, 'EditnTurnsLB', 'nTurnsLB');
guidata(hObject, handles);


function EditnTurnsLB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditPDHUB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditPDHUB', 'PDHUB');
guidata(hObject, handles);


function EditPDHUB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditYPCUB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditYPCUB', 'YPCUB');
guidata(hObject, handles);


function EditYPCUB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditPKUB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditPKUB', 'PKUB');
guidata(hObject, handles);


function EditPKUB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditYsUB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditYsUB', 'YsUB');
guidata(hObject, handles);


function EditYsUB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditYGlnUB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditYGlnUB', 'YGlnUB');
guidata(hObject, handles);


function EditYGlnUB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditGKUB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditGKUB', 'GKUB');
guidata(hObject, handles);


function EditGKUB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditTPIUB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
V = FixGreaterThanOne(V);
handles = EditRespond(handles, V, 'EditTPIUB', 'TPIUB');
guidata(hObject, handles);


function EditTPIUB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditROFUB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
V = FixGreaterThanOne(V);
handles = EditRespond(handles, V, 'EditROFUB', 'ROFUB');
guidata(hObject, handles);


function EditROFUB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditRSMUB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
V = FixGreaterThanOne(V);
handles = EditRespond(handles, V, 'EditEOAAUB', 'EOAAUB');
guidata(hObject, handles);


function EditRSMUB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditEOAAUB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditEOAAUB', 'EOAAUB');
guidata(hObject, handles);


function EditEOAAUB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditECitUB_Callback(hObject, eventdata, handles);
V = str2double(get(hObject,'String'));
V = FixLessThanZero(V);
handles = EditRespond(handles, V, 'EditECitUB', 'ECitUB');
guidata(hObject, handles);


function EditECitUB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditEaKGUB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixNegative(V);
handles = EditRespond(handles, V, 'EditEaKGUB', 'EaKGUB');
guidata(hObject, handles);


function EditEaKGUB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditnTurnsUB_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixLessThanTwo(V);
handles = EditRespond(handles, V, 'EditnTurnsUB', 'nTurnsUB');
handles.nTurnsUB.String = sprintf('%d', V);
guidata(hObject, handles);


function EditnTurnsUB_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditXtol_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixNegative(V);
handles = EditRespond(handles, V, 'EditXtol', 'XTol');
handles.EditXtol.String = sprintf('%5.2e', V);
guidata(hObject, handles);

function EditXtol_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditFtol_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixNegative(V);
handles = EditRespond(handles, V, 'EditFtol', 'FTol');
handles.EditFtol.String = sprintf('%5.2e', V);
guidata(hObject, handles);


function EditFtol_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditnIter_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixNegative(V);
V = FixLessThanOne(V);
V = round(V);
handles = EditRespond(handles, V, 'EditnIter', 'nIter');
handles.EditnIter.String = sprintf('%d', V);
guidata(hObject, handles);

function EditnIter_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EditnFEvs_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
V = FixNegative(V);
V = FixLessThanOne(V);
V = round(V);
handles = EditRespond(handles, V, 'EditnFEvs', 'nFEvs');
handles.EditnFEvs.String = sprintf('%d', V);
guidata(hObject, handles);


function EditnFEvs_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function CBMaxResid_Callback(hObject, eventdata, handles)
handles = SetXform(handles);
guidata(hObject, handles);


function CBXForm_Callback(hObject, eventdata, handles)
handles = SetXform(handles);
guidata(hObject, handles);


% --- Executes on button press in PBNextModel.
function PBNextModel_Callback(hObject, eventdata, handles)
CMM = handles.CurrentMetabolicModel;
CID = CMM.ExptID;
MMs = handles.MetabolicModels;
nMMs = size(MMs,2);
for i = 1:nMMs
    MM = MMs(1,i);
    MID = MM.ExptID;
    if strcmp(CID, MID)
        idx = i + 1;
    end
end
if idx > nMMs
    idx = 1;
end
CMM = MMs(1, idx);
handles.CurrentMetabolicModel = CMM;
handles = SetDisplayParams(handles, CMM);
guidata(hObject, handles);



% --- Executes on button press in PBPrevModel.
function PBPrevModel_Callback(hObject, eventdata, handles)
CMM = handles.CurrentMetabolicModel;
CID = CMM.ExptID;
MMs = handles.MetabolicModels;
nMMs = size(MMs,2);
for i = 1:nMMs
    MM = MMs(1,i);
    MID = MM.ExptID;
    if strcmp(CID, MID)
        idx = i - 1;
    end
end
if idx == 0
    idx = nMMs;
end
CMM = MMs(1, idx);
handles.CurrentMetabolicModel = CMM;
handles = SetDisplayParams(handles, CMM);
guidata(hObject, handles);


% --- Executes on button press in CBChangeAllModels.
function CBChangeAllModels_Callback(hObject, eventdata, handles)
guidata(hObject, handles);


% --- Executes on button press in PBRevert.
function PBRevert_Callback(hObject, eventdata, handles)
MMs = handles.InitialMetabolicModels;
handles.MetabolicModels = MMs;
CMM = MMs(1, 1);
handles.CurrentMetabolicModel = CMM;
handles = SetDisplayParams(handles, CMM);
guidata(hObject, handles);


function PBClose_Callback(hObject, eventdata, handles)
uiresume(handles.figure1);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%% Helper functions begin here %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function handles = SetXform(handles)
VXF = handles.CBXForm.Value;
VMR = handles.CBMaxResid.Value;
CMM = handles.CurrentMetabolicModel;
if VXF == 1 && VMR == 1
        CMM.UseXform = 2;
end
if VXF == 0 && VMR == 1
        CMM.UseXform = 0;
end
if VXF == 1 && VMR == 0
        CMM.UseXform = 1;
end
handles.CurrentMetabolicModel = CMM;
handles = InsertMetabolicModel(handles, CMM);


function R = FixNegative(V)
R = V;
if V < 0
    R = 0;
end


function R = FixLessThanZero(V)
R = V;
if V < 0.0
    R = 0.0;
end


function R = FixLessThanOne(V)
R = V;
if V < 1.0
    R = 1;
end

function R = FixLessThanTwo(V)
R = V;
if V < 2.0
    R = 2;
end


function R = FixGreaterThanOne(V)
R = V;
if V > 1.0
    R = 1.0;
end


function handles = SetParams(handles, V, FS, P1, P2)
handles.(P1).String = sprintf(FS, V);
MMs = handles.MMs;
nMMs = size(MMs, 2);
for i = 1:nMMs
    MM = MMs(1,i);
    MM.(P2) = V;
    MMs(1,i) = MM;
end
handles.MMs = MMs;


function handles = RespondFitCheck(handles, V, XID)
CMM = handles.CurrentMetabolicModel;
PUB = ['Edit', XID, 'UB'];
PLB = ['Edit', XID, 'LB'];
XIDs = CMM.XIDs;
if V == 1
    handles.(PLB).Visible = 'on';
    handles.(PUB).Visible = 'on';
    XIDs = [XIDs, {XID}];  
else
    handles.(PLB).Visible = 'off';
    handles.(PUB).Visible = 'off';
    XIDs = XIDs(~strcmp(XIDs, XID));
end
CMM.XIDs = XIDs;
handles.CurrentMetabolicModel = CMM;
handles = InsertMetabolicModel(handles, CMM);


function handles = EditRespond(handles, V, P1, P2)
handles.(P1).String = sprintf('%5.2f', V);
CMM = handles.CurrentMetabolicModel;
CMM.(P2) = V;
handles.CurrentMetabolicModel = CMM;
handles = InsertMetabolicModel(handles, CMM);
Q = handles.CBChangeAllModels.Value;
if Q
    MMs = handles.MetabolicModels;
    nMMs = size(MMs, 2);
    for i = 1:nMMs
        MM = MMs(1, i);
        MM.(P2) = V;
        NMMs(1,i) = MM;
    end
    handles.MetabolicModels = NMMs;
end
        





% function DumpHandlesValues(handles, P)
% disp(['handles.MMs.',P]);
% MMs = handles.MMs;
% nMMs = size(MMs, 2);
% for i = 1:nMMs
%     MM = MMs(1,i);
%     disp(num2str(MM.(P)));
% end
% disp(' ');
% disp(' ');
% % dummy = 1;


function ShowModelParams(handles, ModelID)
MMs = handles.MMs;
nMMs = size(MMs,2);
for i = 1:nMMs
    MM = MMs(1, i);
    EID = MM.ExptID;
    if strcmp(EID, ModelID)
        Z = MM;
    end
end


function handles = SetDisplayParams(handles, MM)
handles.EditExptID.String = MM.ExptID;
handles.CurrentMetabolicModel = MM;
PA = {'PDH', ...
      'YPC', ...
      'PK', ...
      'Ys', ...
      'YGln', ...
      'GK', ...
      'TPI', ...
      'ROF', ...
      'RSM', ...
      'EOAA', ...
      'ECit', ...
      'EaKG', ...
      'nTurns'};

VALB = {'EditPDHLB', ...
      'EditYPCLB', ...
      'EditPKLB', ...
      'EditYsLB', ...
      'EditYGlnLB', ...
      'EditGKLB', ...
      'EditTPILB', ...
      'EditROFLB', ...
      'EditRSMLB', ...
      'EditEOAALB', ...
      'EditECitLB', ...
      'EditEaKGLB', ...
      'EditnTurnsLB'};

nVA = size(VALB, 2);
for i = 1:nVA
    V = char(VALB(1,i));
    P = [char(PA(1,i)), 'LB'];
    handles.(V).String = sprintf('%5.2f', MM.(P));
    if strcmp(V, 'EditnTurnsLB')
        handles.(V).String = sprintf('%d', MM.(P));
    end
    handles.(V).Visible = 'off';
end

VAUB = {'EditPDHUB', ...
      'EditYPCUB', ...
      'EditPKUB', ...
      'EditYsUB', ...
      'EditYGlnUB', ...
      'EditGKUB', ...
      'EditTPIUB', ...
      'EditROFUB', ...
      'EditRSMUB', ...
      'EditEOAAUB', ...
      'EditECitUB', ...
      'EditEaKGUB', ...
      'EditnTurnsUB'};

nVA = size(VAUB, 2);
for i = 1:nVA
    V = char(VAUB(1,i));
    P = [char(PA(1,i)), 'UB'];
    handles.(V).String = sprintf('%5.2f', MM.(P));
    if strcmp(V, 'EditnTurnsUB')
        handles.(V).String = sprintf('%d', MM.(P));
    end
    handles.(V).Visible = 'off';
end

 nPA = size(PA, 2);
 for i = 1:nPA
     P = char(PA(1,i));
     P1 = ['Edit', P, '0'];
     if strcmp(P, 'nTurns')
         P1 = ['Edit', P];
     end
     handles.(P1).String = sprintf('%5.2f', MM.(P));
     if strcmp(P, 'nTurns')
         handles.(P1).String = sprintf('%d', MM.(P));
     end
 end
         
XIDs = MM.XIDs;

for i = 1:nPA
    P = char(PA(1,i));
    CB = ['CBFit', P];
    handles.(CB).Value = 0;
    if any(strcmp(XIDs, P))
%         CB = ['CBFit', P];
        handles.(CB).Value = 1;
        LB1 = ['Edit',P,'LB'];
        handles.(LB1).Visible = 'on';
        LB2 = [P,'LB'];
        handles.(LB1).String = sprintf('%5.2f', MM.(LB2));
        if strcmp(P, 'nTurns')
            handles.(LB1).String = sprintf('%d', MM.(LB2));
        end
        UB1 = ['Edit',P,'UB'];
        handles.(UB1).Visible = 'on';
        UB2 = [P,'UB'];
        handles.(UB1).String = sprintf('%5.2f', MM.(UB2));
        if strcmp(P, 'nTurns')
            handles.(UB1).String = sprintf('%d', MM.(UB2));
        end
        
    end
end

handles.CBExactNA.Value = MM.ExactNaturalAbundance;

handles.EditXtol.String = sprintf('%5.2e', MM.XTol);
handles.EditFtol.String = sprintf('%5.2e', MM.FTol);
handles.EditnIter.String = sprintf('%d', MM.nIter);
handles.EditnFEvs.String = sprintf('%d', MM.nFEvs);

if MM.UseXform == 0
    handles.CBMaxResid.Value = 1;
    handles.CBXForm.Value = 0;
end
if MM.UseXform == 1
    handles.CBMaxResid.Value = 0;
    handles.CBXForm.Value = 1;
end
if MM.UseXform == 2
    handles.CBMaxResid.Value = 1;
    handles.CBXForm.Value = 1;
end


function handles = InsertMetabolicModel(handles, CMM)
MMs = handles.MetabolicModels;
nMMs = size(MMs, 2);
CID = CMM.ExptID;
for i = 1:nMMs
    MM = MMs(1,i);
    MID = MM.ExptID;
    if strcmp(MID, CID)
        MM = CMM;
    end
    NMMs(1,i) = MM;
end
handles.MetabolicModels = NMMs;
    
