function RMolecule = OptimizeMoleculeJAPPM(Molecule, Spectrum, ...
                       TestJAPPMRange, TestJAPPMInc, ...
                       RCalcPPMRange)

% not used see OptimizeJAPPMOnOneMolecule.m                   
                   
nTests = round(TestJAPPMRange/TestJAPPMInc);
StartValue = -TestJAPPMRange/2.0;
ValueInc = TestJAPPMInc;
TestValues = zeros(nTests, 1);
for i = 1:nTests
    TestValues(i) = StartValue + ((i-1)*ValueInc);
end
JIncs = TestValues;

FreqsPPM = Molecule.FreqsPPM;
JAPPM = Molecule.JAPPM;
LabelPattern = Molecule.LabelPattern;
Signals = Molecule.Signals;
Signal = Signals(1);
ShapeParams = Signal.ShapeParams;
GlobalR2 = ShapeParams(1);
sf = str2num(Molecule.ScannerFreqMHz);
CenterPPM = str2num(Molecule.CenterPPM);
SampleTimesSec = Molecule.SampleTimesSec;
CenterPPM = str2num(Molecule.CenterPPM);
MolConc = Molecule.Conc;

BestTestMolecule = BuildIsotopMolecule(LabelPattern, FreqsPPM, ...
                       JAPPM, MolConc, GlobalR2, sf, SampleTimesSec, CenterPPM);
BestR = GetResidual(BestTestMolecule, Spectrum, RCalcPPMRange);

nJs = size(JAPPM, 1);
nTestJs = size(JIncs,1);

for i = 1:nJs
    for j = 1:nJs
        if i < j && LabelPattern(i) == '1' && LabelPattern(j) == '1'
            JPPM = JAPPM(i,j);
            TestJs = JPPM + JIncs;
            MinTestJs = min(TestJs);
            if MinTestJs < 0.0
                TestJs = TestJs - MinTestJs;
            end
            for k = 1:nTestJs
                TestJAPPM = JAPPM;
                TestJAPPM(i,j) = JAPPM(i,j) + TestJs(k);
                TestJAPPM(j,i) = TestJAPPM(i,j);
                TestMolecule = BuildIsotopMolecule(LabelPattern, ...
                                  FreqsPPM, TestJAPPM, MolConc, ...
                                  GlobalR2, sf, SampleTimesSec, CenterPPM);    
                R = GetResidual(TestMolecule, Spectrum, RCalcPPMRange);
                if R < BestR
                   BestTestMolecule = TestMolecule;
                   BestR = R;
                end
            end
        end
        
    end
end
RMolecule = BestTestMolecule;
RMolecule.PlotCenters = RMolecule.FreqsPPM;
end

