function varargout = InputTwoCarbonIsotopomers(varargin)
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @InputTwoCarbonIsotopomers_OpeningFcn, ...
                   'gui_OutputFcn',  @InputTwoCarbonIsotopomers_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

function hObject = CheckFixNegatives(hObject)
         V = str2double(get(hObject,'String'));
         if V < 0
             hObject.String = ['0.00'];
         end
         
function hObject = CheckFixGTOne(hObject)
         V = str2double(get(hObject,'String'));
         if V > 1.0
             hObject.String = ['1.00'];
         end

function [handles, A] = DoCallBack(hObject, handles)
    hObject = CheckFixGTOne(hObject);
    hObject = CheckFixNegatives(hObject);
    [handles, A] = ReadUpdateAllTwoCarbonIsotopomers(handles);
    guidata(hObject, handles);         
         
         
function InputTwoCarbonIsotopomers_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
MolID = char(varargin(2));
A = cell2mat(varargin(3));
Z = handles.MoleculeID;
Z.String = MolID;
handles.MoleculeID = Z;
[oo, xo, ox, xx] = DefineTwoCarbonLabelIndices();

handles.OO.String = sprintf('%4.2f',A(1, oo));
handles.XO.String = sprintf('%4.2f',A(1, xo));
handles.OX.String = sprintf('%4.2f',A(1, ox));
handles.XX.String = sprintf('%4.2f',A(1, xx));

A = ReadUpdateAllTwoCarbonIsotopomers(handles);
guidata(hObject, handles);
uiwait(handles.figure1);

function varargout = InputTwoCarbonIsotopomers_OutputFcn(hObject, eventdata, handles)
[handles, A] = ReadUpdateAllTwoCarbonIsotopomers(handles);
varargout{1} = A;
close();

function pushbutton1_Callback(hObject, eventdata, handles)
A = ReadUpdateAllTwoCarbonIsotopomers(handles);
uiresume;

function OO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function XO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function OX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function XX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function OO_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function XO_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function OX_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function XX_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);
