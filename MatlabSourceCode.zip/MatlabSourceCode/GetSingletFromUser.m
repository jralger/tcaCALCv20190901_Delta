function Singlet = GetSingletFromUser(handles, SingletID, EstPPM, DisplayWidth)
Spectrum = handles.Spectrum;
ax1 = handles.axes1;
fig = handles.figure1;
UsersFreqPPM = GetSingletFreqFromUser(handles, Spectrum, ax1, fig, EstPPM, DisplayWidth, SingletID);
handles.axes1 = ax1;
Singlet.ID = SingletID;
Singlet.JHz = 0.0;
Singlet.CenterFreqPPM = UsersFreqPPM;
handles = AddMultiplet(handles, Singlet);
end

