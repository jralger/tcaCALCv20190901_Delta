function R = GetResidualOverPPMRange(Molecule, Spectrum, PPMLow, PPMHigh);
R = 0;
ModelSpectrum = Molecule.ConcWtdSpectrum;
ModelPPMTable = ModelSpectrum.PPMTable;
ModelFDD = ModelSpectrum.FreqDomainData;
PPMTable = Spectrum.PPMTable;
FDD = Spectrum.FreqDomainData;

%assume PPMTables are the same -- but this will come up in the future
TModelFDD = ModelFDD(ModelPPMTable > PPMLow & ModelPPMTable < PPMHigh);
TFDD = FDD(PPMTable > PPMLow & PPMTable < PPMHigh);
D = TFDD - TModelFDD;
A = real(D);
B = imag(D);
A = times(A,A);
B = times(B,B);
A = sum(A);
B = sum(B);
R = A + B;
end

