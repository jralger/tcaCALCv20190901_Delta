function [handles, Singlet] = SetPPMRefToSinglet(handles, Singlet, RefFreqPPM)
D = Singlet.CenterFreqPPM - RefFreqPPM;
Spectrum = handles.Spectrum;
PPMTable = Spectrum.PPMTable;
PPMTable = PPMTable - D;
Singlet.CenterFreqPPM = RefFreqPPM;
CenterPPM = mean(PPMTable);
Spectrum.PPMTable = PPMTable;
Spectrum.CenterPPM = CenterPPM;
handles.Spectrum = Spectrum;
handles.RefSet = 1;
% handles.SingletDisplayPPMWidth = 2.0;
end

