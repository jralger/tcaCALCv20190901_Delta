function Singlet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2)


GlobalPhaseDeg = 0.0;
GlobalImagSign = '+';
GlobalSignalShape = 'Lorentz';
GlobalShapeParams = [GlobalR2, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0];
GlobalSignalAmplitude = 1.0;
DefaultConc = 1.0;  
DefaultRelConc = 0.0;

Singlet.ID = ID;
Signal.FreqPPM = FreqPPM;
Signal.Amplitude = GlobalSignalAmplitude;
Signal.PhaseDeg = GlobalPhaseDeg;
Signal.Shape = GlobalSignalShape;
Signal.ShapeParams = GlobalShapeParams;
Signal.ImagSign = GlobalImagSign;

Singlet.Signals = Signal;
Singlet.JPPM = 0.0;
Singlet.Conc = DefaultConc;
Singlet.RelConc = DefaultRelConc;
Singlet.FreqPPM = FreqPPM;

ScannerFreqMHz = Spectrum.ScannerFreqMHz;
SampleTimesSec = Spectrum.SampleTimesSec;
CenterPPM = Spectrum.CenterPPM;
Singlet = SimulateMultipletSpectrum(Singlet, ScannerFreqMHz, ...
                    SampleTimesSec, CenterPPM, GlobalImagSign);    
end

