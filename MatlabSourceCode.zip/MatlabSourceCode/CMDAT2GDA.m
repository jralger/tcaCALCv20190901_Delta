function GDA = CMDAT2GDA(CMDAT, FN, StudyID)
LIDs = {'GLU', 'GLC', 'ASP', 'BUT', 'ALA'};
GDIDs = {'Glu', 'Glc', 'Asp', 'bHB', 'Ala'};

CMDAT = DumpNullReads(CMDAT);

GD.FN = FN;
GD.StudyID = StudyID;
GD.Value = 0;

nLIDs = size(LIDs, 2);
M = 1;

FA = fieldnames(CMDAT);
nFA = size(FA, 1);
N = 1;
for i = 1:nFA
    F = char(FA(i,1));
    for j = 1:nLIDs
        L = char(LIDs(1,j));
        if contains(F, L)
            TFA(1, N) = {F};
            N = N + 1;
        end
    end
   
end
FA = TFA;
nFA = size(FA, 2);

N = 1;
FEA = {};
for i = 1:nFA
    F = char(FA(1, i));
    if contains(F, 'F')
        FEA(1, N) = {F};
        N = N + 1;
    end
end
nFEA = size(FEA, 2);

if N > 1
    M = 1;
    for i = 1:nFEA
        GD.Type = 'Fractional Enrichment';
        F = char(FEA(1,i));
        T = F(1:3);
        GD.MolID = char(GDIDs(1, strcmp(T, LIDs)));
        T = F(4);
        GD.MeasID = ['C', T];
        GD.Value = CMDAT.(F);
        GDA(1, M) = GD;
        M = M + 1;
    end
end
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% Needs testing for Isotopologues
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
N = 1;
for i = 1:nFA
    F = char(FA(1, i));
    if contains(F, 'm+')
        IA(1, N) = {F};
        N = N + 1;
    end
end
if N > 1
    nIA = size(IA, 2);
    for i = 1:nIA
        GD.Type = 'MS Isotopologue';
        F = char(IA(1,i));
        T = F(1:3);
        GD.MolID = char(GDIDs(1, strcmp(T, LIDs)));
        GD.MeasID = F(4:6);
        GD.Value = CMDAT.(F);
        GDA(1, M) = GD;
        M = M + 1;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% Needs coding for Isotopomers
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%       



N = 1;
for i = 1:nFA
    F = char(FA(1, i));
    if contains(F, 'S')
        MA(1, N) = {F};
        N = N + 1;
    end
    if contains(F, 'D')
        MA(1, N) = {F};
        N = N + 1;
    end
    if contains(F, 'Q')
        MA(1, N) = {F};
        N = N + 1;
    end
    if contains(F, 'T')
        MA(1, N) = {F};
        N = N + 1;
    end
end
if N > 1
    nMA = size(MA, 2);
    for i = 1:nMA
        F = char(MA(1,i));
        GD.Type = '13C NMR Multiplet';
        T = F(1:3);
        GD.MolID = char(GDIDs(1, strcmp(T, LIDs)));
        nF = size(F,2);
        T = F(1, 4);
        U = F(1, 5:nF);
        GD.MeasID = ['C', T, ' ', U];
        GD.Value = CMDAT.(F);
        GDA(1, M) = GD;
        M = M + 1;
    end
end

% nGDA = size(GDA, 2);
% for i = 1:nGDA
%     GD = GDA(1, i);
%     T = [GD.StudyID, ' ', GD.Type, ' ', GD.MolID, ' ', GD.MeasID, ' ', GD.Value];
%     disp(T)
% end
    
end

function NCMDAT = DumpNullReads(CMDAT)
FA = fieldnames(CMDAT);
nFA = size(FA, 1);
N = 1;
for i = 1:nFA
    F = char(FA(i,1));
    Q = CMDAT.(F);
    if Q ~= -1
        NCMDAT.(F) = CMDAT.(F);
    end
end
end

