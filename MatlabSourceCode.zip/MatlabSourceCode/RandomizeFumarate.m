function OAA_ROF = RandomizeFumarate(OAA_PC, m, R)
% R = 0: no scrambling
% R = 1: complete scrambling
% Only applied to OAA arriving via Pyruvate Carboxylase

[oooo, xooo, oxoo, xxoo, ooxo, xoxo, oxxo, xxxo, ...
 ooox, xoox, oxox, xxox, ooxx, xoxx , oxxx, xxxx] = ... 
                                           DefineFourCarbonLabelIndices();

OAA_ROF = OAA_PC;
if R > 1.0
    R = 1.0;
end

if R < 0.0
    R = 0.0;
end

A = 1.0 - (0.5*R);               
B = 1 - A;

OAA_ROF(m, oooo) = (A*OAA_PC(m, oooo)) + (B*OAA_PC(m, oooo));
OAA_ROF(m, xooo) = (A*OAA_PC(m, xooo)) + (B*OAA_PC(m, ooox));
OAA_ROF(m, oxoo) = (A*OAA_PC(m, oxoo)) + (B*OAA_PC(m, ooxo));
OAA_ROF(m, xxoo) = (A*OAA_PC(m, xxoo)) + (B*OAA_PC(m, ooxx));

OAA_ROF(m, ooxo) = (A*OAA_PC(m, ooxo)) + (B*OAA_PC(m, oxoo));
OAA_ROF(m, xoxo) = (A*OAA_PC(m, xoxo)) + (B*OAA_PC(m, oxox));
OAA_ROF(m, oxxo) = (A*OAA_PC(m, oxxo)) + (B*OAA_PC(m, oxxo));
OAA_ROF(m, xxxo) = (A*OAA_PC(m, xxxo)) + (B*OAA_PC(m, oxxx));

OAA_ROF(m, ooox) = (A*OAA_PC(m, ooox)) + (B*OAA_PC(m, xooo));
OAA_ROF(m, xoox) = (A*OAA_PC(m, xoox)) + (B*OAA_PC(m, xoox));
OAA_ROF(m, oxox) = (A*OAA_PC(m, oxox)) + (B*OAA_PC(m, xoxo));
OAA_ROF(m, xxox) = (A*OAA_PC(m, xxox)) + (B*OAA_PC(m, xoxx));

OAA_ROF(m, ooxx) = (A*OAA_PC(m, ooxx)) + (B*OAA_PC(m, xxoo));
OAA_ROF(m, xoxx) = (A*OAA_PC(m, xoxx)) + (B*OAA_PC(m, xxox));
OAA_ROF(m, oxxx) = (A*OAA_PC(m, oxxx)) + (B*OAA_PC(m, xxxo));
OAA_ROF(m, xxxx) = (A*OAA_PC(m, xxxx)) + (B*OAA_PC(m, xxxx));

end

