function PPMTable = CalculatePPMTableFromSampleTimes(SampleTimesSec, ScannerFreqMHz, CenterPPM)
npts = size(SampleTimesSec, 1);
dt = SampleTimesSec(2) - SampleTimesSec(1);
NP = 2.0*dt;
NF = 1.0/NP;
NF = NF/ScannerFreqMHz;
delta = 2.0*NF/(npts-1);
PPMTable = zeros(npts, 1);
for i = 1:npts
    PPMTable(i) = i*delta;
end
PPMTable = flip(PPMTable);
PPMTable = PPMTable - NF;
PPMTable = PPMTable + CenterPPM;
end


