function [V, VLB, VUB] = GetStartParameterValues(A)
nA = size(A, 2);
V = zeros(1, nA);
VLB = zeros(1, nA);
VUB = zeros(1, nA);
for i = 1:nA
    T = char(A(i));
    T = strsplit(T, ':');
    nT = size(T, 2);
    if nT == 1
        V(1, i) = str2double(char(T));
    end
    if nT >= 2
        V(1, i) = str2double(char(T(1, 2)));
    end
    if nT >= 3
        VLB(1, i) = str2double(char(T(1, 3)));
    end
    if nT >= 4
        VUB(1, i) = str2double(char(T(1, 4)));
    end
end
if ~all(isfinite(V))
    V = zeros(1, nA);
    VLB = zeros(1, nA);
    VUB = zeros(1, nA);
end


