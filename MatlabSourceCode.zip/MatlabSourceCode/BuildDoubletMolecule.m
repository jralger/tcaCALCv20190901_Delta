function [handles, Molecule] = BuildDoubletMolecule(handles, Doublet, LabelPattern, EstFreqsPPM, EstJAHz, LIdx, JCIdx)
nC = size(LabelPattern, 2);
EstJAHz = zeros(nC);
EstJAHz(JCIdx,LIdx) = Doublet.JHz;
EstJAHz(LIdx, JCIdx) = EstJAHz(JCIdx,LIdx);
Spectrum = handles.Spectrum;
SF = Spectrum.ScannerFreqMHz;
SampleTimesSec = Spectrum.SampleTimesSec;
JAPPM = EstJAHz/SF;
EstFreqsPPM(LIdx) = Doublet.CenterFreqPPM;
CenterPPM = Spectrum.CenterPPM;
GlobalR2 = handles.GlobalR2;
DefaultMolConc = handles.DefaultMolConc;
Molecule = BuildIsotopMolecule(LabelPattern, EstFreqsPPM, ...
                      JAPPM, DefaultMolConc, GlobalR2, SF, ...
                      SampleTimesSec, CenterPPM);
Molecule.FreqsPPM(LIdx) = Doublet.CenterFreqPPM;
Molecule.ID = Doublet.ID;
Molecule.PlotCenters = Doublet.CenterFreqPPM;
handles = AddMolecule(handles, Molecule);
end

