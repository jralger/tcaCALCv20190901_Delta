function RFID = ReadAgilentFID(FN, at, sf, CenterPPM, PPMOffset)

fileID = fopen(FN,'r', 'b');
FIDH = fread(fileID, [15,1], 'uint32');
FID = fread(fileID, [FIDH(3), 1], 'float32');
fclose(fileID);
FID = riri2complex(FID);
FID = FID(:,1);
szFID = size(FID, 1);
dt = at/(szFID-1.0);

SampleTimesSec = zeros(szFID,1);
for i = 0:szFID-1
    SampleTimesSec(i+1) = dt*i;
end

RFID.TimeDomainDataRaw = FID;
RFID.SampleTimesSec = SampleTimesSec;
RFID.ScannerFreqMHz = sf;
CenterPPM = CenterPPM + PPMOffset;
RFID.CenterPPM = CenterPPM;


end

