function R = SetDefaultChemicalShifts()
%Sets default values of chemical shifts
% updated chem shift and J info for Lac (all carbons) and Glu
% (all carbons) done 14 Aug 2017 (average of 6 high quality Agilent
% spectra after full hand picking and full fitting
% J values taken from doublets (not quartets)
% estimated values are values for the multiplets singlets (center
% line)
LacEstFreqsPPM = [183.2359, 69.21218, 20.80];
AlaEstFreqsPPM = [176.5575, 51.255, 16.8675]; % Needs opt 19 Aug 2018
GluEstFreqsPPM = [175.2332, 55.37002, 27.6665, 34.20288, 181.9921];
AspEstFreqsPPM = [174.729, 52.93012, 37.25453, 178.3118];
bHBEstFreqsPPM = [180.8, 47.45, 66.7, 22.8]; % Needs opt 14 Aug 2017
GlcEstFreqsPPM = [96.71, 74.91, 76.71, 70.41, 76.51, 61.51]; % beta Glucose Needs opt 19 Aug 2018
MAGEstFreqsPPM = [106.22, 86.47, 75.86, 83.33, 70.78, 65.03]; % From Gaurav 8/30/2018

R.LacEstFreqsPPM = LacEstFreqsPPM;
R.AlaEstFreqsPPM = AlaEstFreqsPPM;
R.GluEstFreqsPPM = GluEstFreqsPPM;
R.AspEstFreqsPPM = AspEstFreqsPPM;
R.bHBEstFreqsPPM = bHBEstFreqsPPM;
R.GlcEstFreqsPPM = GlcEstFreqsPPM;
R.MAGEstFreqsPPM = MAGEstFreqsPPM;


end

