function V = BuildOneCarbonNaturalAbundance(A)
[o, x] = DefineOneCarbonLabelIndices();

V = zeros(1,2);

V(1, x) = A;

T = sum(V(1, :));
V(1, o) = 1.0 - T;

end

