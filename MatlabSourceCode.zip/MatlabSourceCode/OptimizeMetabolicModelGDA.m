function [OptMM] = OptimizeMetabolicModelGDA(MetabolicModel)
% This optimizer will work with the 'Generic Data Array' (GDA) which includes
% isotopmers, 13C NMR multiplets, isotopologues, or fractional enrichments
% Calls a few existing functions that build various parammeters from
% isotopomers
% Removed vestigial comments and unused code from earlier versions
% initial design 12 Dec 2019

% Updated for tcaCALC_v20190901_Delta Sept 11, 2022 J.R. Alger
% In Aug 2022 I received reports of errors that occurred when two substrate
% isotopomers of the same molecule were being fit. For instance when Lac
% oxo and Lac oox when both substrates and were unknown and were being fit.
% In this situation the search routine would lead to situations in which 
% the results reported sum of of the fitted substrates is greater than one
% eg Lac oox + Lac oxo > 1.
% This version handles this problem in the same way that the problem of LDH
% < 0 is handled. It gives such instances a large error value so the search
% routine will prefer to go elsewhere.



MM = MetabolicModel;

MM.AlaMultiplets = BuildAlaDefaultMultiplets();
MM.AspMultiplets = BuildAspDefaultMultiplets();
MM.GlcMultiplets = BuildGlcDefaultMultiplets();
MM.GluMultiplets = BuildGluDefaultMultiplets();
MM.MAGMultiplets = BuildMAGDefaultMultiplets();
MM.bHBMultiplets = BuildbHBDefaultMultiplets();

GDA = MM.GDA;
nGDA = size(GDA, 2);
NegLDHEV = nGDA + 1;
MM.NegLDHEV = NegLDHEV;

MM.DisplayProgress = 0;

Glc = zeros(64,1);
Glc = UpdateNoLabelIsotopomer(Glc);
MM.Glc = Glc;

% initialize the BestGDA and the EV in case no fitting gets done
% due to substrate error
% verified that this is needed in case of error in substrate entry
UGDA = UpdateGDA(MM);
MM.BestGDA = UGDA;
EV = GetGDAError(MM.GDA, UGDA);
EV = EV.^2;
EV = sum(EV);
EV = sqrt(EV);
MM.BestEV = EV;

FTol = MM.FTol;
XTol = MM.XTol;
nIter = MM.nIter;
nFEvs = MM.nFEvs;
DisplayProgress = MM.DisplayProgress;

[X0, XS, XLB, XSLB, XUB, XSUB, XIDs]  = DefineParams4Fit(MM);
MM.XS = XS;
MM.XSLB = XSLB;
MM.XSUB = XSUB;

[Isotops, VersionID] = ...
                    SimulateIsotopomers(MM.nTurns, ...
                    MM.GK, MM.PDH, MM.PK, MM.ROF, MM.RSM, MM.TPI, MM.YPC, MM.Ys, ...
                    MM.EaKG, MM.ECit, MM.EOAA, ...
                    MM.CO2, MM.FA, MM.Glc, MM.Glyc, MM.Lac, MM.SuccYs, ...
                    MM.ExactNaturalAbundance);
MM.tcaSIMID = VersionID;
         
options = optimset('TolFun', FTol, 'TolX', XTol, 'MaxIter', nIter, ...
           'MaxFunEvals', nFEvs);
if DisplayProgress
    options = optimset('TolFun', FTol, 'TolX', XTol, 'MaxIter', nIter, ...
           'MaxFunEvals', nFEvs, ...
           'PlotFcns',{@tcaCALCoptimplotx,@optimplotfval}, ...
           'FunValCheck', 'on');
end
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% Embedded error function  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            function EV = EvaluateMetabolicModelGDA(X)
%             UseGluC4toC3 = 0; 

% Updated for tcaCALC_v20190901_Delta Sept 11, 2022 J.R. Alger
% In Aug 2022 I received reports of errors that occurred when two substrate
% isotopomers of the same molecule were being fit. For instance when Lac
% oxo and Lac oox when both substrates and were unknown and were being fit.
% In this situation the search routine would lead to situations in which 
% the results reported sum of of the fitted substrates is greater than one
% eg Lac oox + Lac oxo > 1.
% This version handles this problem in the same way that the problem of LDH
% < 0 is handled. It gives such instances a large error value so the search
% routine will prefer to go elsewhere.

            % tcaCALC_v20190901_Delta: This updates the metabolic model 
            % (MM) based on the version on the 'X' values created by the
            % search routine. 
            
            MM = UpdateMetabolicModel(MM, X, XIDs);
            
            % This routine checks if any of the substrate isotopomers have 
            % become illegal. It checks if the sum of the isotopomers for 
            % any substrate have become greater that one or if any one
            % substrate isotopomer of any type has become less than zero.
            % the behavior of UpdateMetabolicModel is such that it always
            % forces the sum of all substrate isotopomers to be 1. It does
            % this by summing all the enriched isotopmers and subtracting
            % the sum from the nonenriched isotopmer eg
            % S = Lac xoo + Lac xxo + Lac oxo + Lac oox + 
            %     Lac xox + Lac oxx + Lac xxx
            % Lac ooo = 1 - S
            % For this reason excess substrate isotopomer situations cause
            % the unenriched substrate isotopomer to become less than zero
            R = Check4IllegalSubstrates(MM);
            if R == 1
                % if the search has created illegal substrates then set the
                % error result to a high number (the same as used when LDH
                % < 0)
                EV = NegLDHEV;
                UGDA = MM.GDA; % unclear that this is needed
            end
            
            if R == 0
                LDH = MM.YPC + MM.PDH - MM.PK;
    %             disp(['LDH: ', num2str(LDH), '  YPC: ', num2str(MM.YPC), ...
    %                 '  PDH: ', num2str(MM.PDH), '   PK: ', num2str(MM.PK), ...
    %                 '  Ys:      ', num2str(MM.Ys)]);
                if LDH < 0
                    EV = NegLDHEV;
                    UGDA = MM.GDA; % unclear that this is needed
                end
                if LDH >= 0
                    UGDA = UpdateGDA(MM);
                    MM.BestGDA = UGDA;
                    EV = GetGDAError(MM.GDA, UGDA);
    %                 T = num2str(EV);
    %                 disp(['EV: ' , T]);
                    EV = EV.^2;
                    EV = sum(EV);
%                     T = num2str(EV);
    %                 disp(['...................EV: ' , T]);
                    MM.BestEV = EV;
                end
            end
            end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% End embedded error function  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[X, BestEV, exitflag, output] = fminsearchbnd(@EvaluateMetabolicModelGDA, ...
                                 X0, XLB, XUB, options);
                             
OptMM = MM;
OptMM.exitflag = exitflag;
OptMM.output = output;
nIter = output.iterations;
OptMM.nIter = nIter;
nSims = output.funcCount;
OptMM.nSims = nSims;
OptMM.BestX = X;
OptMM.XLBs = XLB;
OptMM.XUBs = XUB;
OptMM.X0 = X0;

nX = size(X, 2);
DOF = nGDA - nX;
OptMM.DOF = DOF;

OptMM = GetLnLikelihoodGDA(OptMM);
OptMM = GetAICGDA(OptMM);

OptMM = GetCovarGDA(OptMM);
A = OptMM.Covar;
nA = size(A, 2);
XSTDCovar = zeros(1,nA);
for i =1:nA
    XSTDCovar(1,i) = sqrt(A(i,i));
end
OptMM.XSTDCovar = XSTDCovar;

QEV = GetGDAError(OptMM.BestGDA, OptMM.GDA);
if any(QEV)
    [h,p] = adtest(QEV, 'Alpha',0.01,'MCTol',0.01);
else
    h = -1;
    p = -1;
end
OptMM.ADh = h;
OptMM.ADp = p;
OptMM.KSh = 0;
OptMM.KSp = 1;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% End main optimizer function  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% Helper functions follow  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% Check4IllegalSubstrates: Checks if any substrates have become 
%%%%%%%%% illegal  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function R = Check4IllegalSubstrates(MM)

% This routine checks if any of the substrate isotopomers have 
% become illegal. It checks if the sum of the isotopomers for 
% any substrate have become greater that one or if any one
% substrate isotopomer of any type has become less than zero.
% the behavior of UpdateMetabolicModel is such that it always
% forces the sum of all substrate isotopomers to be 1. It does
% this by summing all the enriched isotopmers and subtracting
% the sum from the nonenriched isotopmer eg
% S = Lac xoo + Lac xxo + Lac oxo + Lac oox + 
%     Lac xox + Lac oxx + Lac xxx
% Lac ooo = 1 - S
% For this reason excess substrate isotopomer situations cause
% the unenriched substrate isotopomer to become less than zero
R = 0;

T = MM.SuccYs;
if any(T < 0.0)
    R = 1;
end
S = sum(T);
if S > 1.0000001  %needed for error in precision
    R = 1;
end

T = MM.Lac;
if any(T < 0.0)
    R = 1;
end
S = sum(T);
if S > 1.0000001
    R = 1;
end

T = MM.Glyc;
if any(T < 0.0)
    R = 1;
end
S = sum(T);
if S > 1.0000001
    R = 1;
end

T = MM.FA;
if any(T < 0.0)
    R = 1;
end
S = sum(T);
if S > 1.0000001
    R = 1;
end

T = MM.CO2;
if any(T < 0.0)
    R = 1;
end
S = sum(T);
if S > 1.0000001
    R = 1;
end

T = MM.Gln;
if any(T < 0.0)
    R = 1;
end
S = sum(T);
if S > 1.0000001
    R = 1;
end


end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% GetCovarGDA:  Builds Covariance estimates  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function MM = GetCovarGDA(MM)
dinc = 0.01;
nXIDs = size(MM.XIDs, 2);
GDA0 = MM.BestGDA;
PD = zeros(nXIDs, nXIDs);
for i = 1:nXIDs
    X1 = MM.BestX;
    X1(i) = MM.BestX(i) + dinc;
    MM1 = UpdateMetabolicModel(MM, X1, MM.XIDs);
    LDH = MM1.YPC + MM1.PDH - MM1.PK;
    if LDH < 0
        GDA1 = MM.BestGDA;
    end
    if LDH >= 0
        GDA1 = UpdateGDA(MM1);
    end
    V = GetGDAError(GDA1, GDA0);
    V = V/dinc;
    V = V.^2;
    V = sum(V);
    V = sqrt(V);
    PDi = V;
    for j = 1:nXIDs
        X1 = MM.BestX;
        X1(j) = MM.BestX(j) + dinc;
        MM1 = UpdateMetabolicModel(MM, X1, MM.XIDs);
        LDH = MM1.YPC + MM1.PDH - MM1.PK;
        if LDH < 0
            GDA1 = MM.BestGDA;
        end
        if LDH >= 0
            GDA1 = UpdateGDA(MM1);
        end
        V = GetGDAError(GDA1, GDA0);
        V = V/dinc;
        V = V.^2;
        V = sum(V);
        PDj = sqrt(V);
        PD(i,j) = PDi*PDj;
    end
end

Covar = 1.0\PD;
Covar = (MM.BestEV/MM.DOF)*Covar;
MM.Covar = Covar;

Rho = zeros(nXIDs, nXIDs);
for i = 1:nXIDs
    for j = 1:nXIDs
        Rho(i,j) = Covar(i,j)/(Covar(i,i)*Covar(j,j));
    end
end
MM.Rho = Rho;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% End GetCovarGDA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% Plot Function Used only for debugging
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function stop = tcaCALCoptimplotx(x,optimValues,state,varargin)
% OPTIMPLOTX Plot current point at each iteration.
%   Copyright 2006-2010 The MathWorks, Inc.
%   Made changes for this particular optimizatiom
stop = false;

k = 1;
nx = size(x, 1);
for i = 1:nx
    xtrans(i) = (sin(x(k))+1)/2;
    xtrans(i) = xtrans(i)*(XUB(i) - XLB(i)) + XLB(i);
    xtrans(i) = max(XLB(i),min(XUB(i),xtrans(i)));
    k = k + 1;
end
x = xtrans;
switch state
    case 'iter'
        x = x(:);
        xLength = length(x);
        xlabelText = getString(message('MATLAB:optimfun:funfun:optimplots:LabelNumberOfVariables',sprintf('%g',xLength)));

        if length(x) > 100
            x = x(1:100);
            xlabelText = {xlabelText,getString(message('MATLAB:optimfun:funfun:optimplots:LabelShowingOnlyFirst100Variables'))};
        end

        if optimValues.iteration == 0
            plotx = bar(x);
            xticklabels(XIDs);
            title('Fitted Params','interp','none');

            Q = MA(1, 1);
            xlabelText = [MM.ExptID, '  ', Q.SpectrumID, '  ', xlabelText];
            xlabel(xlabelText,'interp','none');
            set(plotx,'edgecolor','none');
            set(gca,'xlim',[0,1 + xLength]);
            set(plotx,'Tag','optimplotx');
        else
            plotx = findobj(get(gca,'Children'),'Tag','optimplotx');
            set(plotx,'Ydata',x);
        end
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% End Plot Function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% UpdateGDA:  Updates GDA from Metabolic Model 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function RGDA = UpdateGDA(MM)
[Isotops, VersionID] = ...
                    SimulateIsotopomers(MM.nTurns, ...
                    MM.GK, MM.PDH, MM.PK, MM.ROF, MM.RSM, MM.TPI, MM.YPC, MM.Ys, ...
                    MM.EaKG, MM.ECit, MM.EOAA, ...
                    MM.CO2, MM.FA, MM.Glc, MM.Glyc, MM.Lac, MM.SuccYs, ...
                    MM.ExactNaturalAbundance);

LegalMolIDs = {'Ala', 'Asp', 'Glc', 'Glu', 'MAG', 'bHB'};
nLegalMols = size(LegalMolIDs, 2);
GDA = MM.GDA;
nGDA = size(GDA, 2);
N = 1;
for k = 1:nGDA
    GD = GDA(1,k);
    MolID = GD.MolID;
    MolIDs = split(MolID, ':');
    nMolIDs = size(MolIDs, 2);
    for j = 1:nMolIDs
        MolID = char(MolIDs(j));
        UsersMolIDs(1,N) = {MolID};
        N = N + 1;
    end
end
clear MolIDs;
clear MolID;
UsersMolIDs = unique(UsersMolIDs);       
nUsersMolIDs = size(UsersMolIDs, 2);
N = 1;
for k = 1:nUsersMolIDs
    UsersMolID = UsersMolIDs(1,k);
    Q = strcmp(LegalMolIDs, UsersMolID);
    if any(Q)
        MolIDs(1,N) = UsersMolID;
        N = N + 1;
    end
end

GD = GDA(1,1);
N = 1;
nMolIDs = size(MolIDs, 2);
clear UGDA;
% UGDA are the uptated parameters
% more parameters are calculated than might actually be needed because of
% the stucture of exisiting software
% for instance all multiplets for a particualr molecule are calculated
% because these routines existed at the time of this writing even if the
% user has not requested all multiplets. For this reason execution might be
% speeded somewhat by calculating only the needed parameters. This was not
% done because of time/effort to put many comditionals into the existing
% functions
% There is some optimization because calculations are done only for
% Molecules and types that are needed.
for k = 1:nMolIDs
    MolID = char(MolIDs(1, k));

    Isotopomers = GetIsotopomerArray(Isotops, MolID);
    Isotopomers = Isotopomers(MM.nTurns, :);
    nIsotopomers = size(Isotopomers, 2);
    
    Types = cell(1, nGDA);
    Types(1, :) = {'Null'};
    for i = 1:nGDA
        GD = GDA(1,i);
        Q = strcmp(MolID, GD.MolID);
        if Q
            Types(1,i) = {GD.Type};
        end
    end
    Types = unique(Types);
    Types = Types(~strcmp(Types, 'Null'));
      
    Type = 'Isotopomer';
    if any(strcmp(Type, Types))
        XOs = BuildIsotopomerIDs(nIsotopomers);
        for i = 1:nIsotopomers
            GD.Type = Type;
            GD.MolID = MolID;
            GD.MeasID = char(XOs(1,i));
            GD.Value = Isotopomers(1,i);
            UGDA(1,N) = GD;
            N = N + 1;
        end
    end

    Type = '13C NMR Multiplet';
    if any(strcmp(Type, Types))
        MA = GetMAfromMM(MM, MolID);
        MA = SimulateMolSpectra(MolID, MA, Isotopomers);
        nMA = size(MA, 2);
        for i = 1:nMA
            M = MA(1,i);
            GD.Type = Type;
            ID = M.ID;
            T = split(ID, ' ');
            GD.MolID = MolID;
            GD.MeasID = [char(T(2,1)), ' ', char(T(3,1))];
            GD.Value = M.RelConc;
            UGDA(1,N) = GD;
            N = N + 1;
        end
    end

    Type = 'MS Isotopologue';
    if any(strcmp(Type, Types))
        IA = Isotopomers2Isotopologues(Isotopomers);
        nIA = size(IA, 2);
        for i = 1:nIA
            GD.Type = Type;
            GD.MolID = MolID;
            GD.MeasID = ['m+', num2str(i-1)];
            GD.Value = IA(1,i);
            UGDA(1,N) = GD;
            N = N + 1;
        end
    end
    
    Type = 'Fractional Enrichment';
    if any(strcmp(Type, Types))
        FEs = Isotopomers2FEA(Isotopomers);
        nFEs = size(FEs,2);
        for i = 1:nFEs
            GD.Type = Type;
            GD.MolID = MolID;
            GD.MeasID = ['C', num2str(i)];
            GD.Value = FEs(1,i);
            UGDA(1,N) = GD;
            N = N + 1;
        end
    end
end

% The above does not pick up the instances of type == Fractional Enrichment
% Ratio, because of the way the Mols are defined
% Therefore build these individually
for i = 1:nGDA
    GD = GDA(1,i);
    if strcmp(GD.Type, 'Fractional Enrichment Ratio')
        MolIDs = split(GD.MolID, ':');
        NMolID = char(MolIDs(1,1));
        DMolID = char(MolIDs(2,1));
        NIsotopomers = GetIsotopomerArray(Isotops, NMolID);
        NIsotopomers = NIsotopomers(MM.nTurns, :);
        NFEs = Isotopomers2FEA(NIsotopomers);
        DIsotopomers = GetIsotopomerArray(Isotops, DMolID);
        DIsotopomers = DIsotopomers(MM.nTurns, :);
        DFEs = Isotopomers2FEA(DIsotopomers);
        MeasIDs = split(GD.MeasID, ':');
        NC = char(MeasIDs(1,1));
        NC = NC(2);
        NC = str2double(NC);
        DC = char(MeasIDs(2,1));
        DC = DC(2);
        DC = str2double(DC);
        Num = NFEs(1,NC);
        Den = DFEs(1,DC);
        V = 0.0;
        if Den > 0
            V = Num/Den;
        end
        GD.Value = V;
        UGDA(1,N) = GD;
        N = N + 1;
    end
end


% at this point UGDA includes all parameters that are needed

%use to print UGDA for debugging
% N = N -1;
% for i = 1:N
%     UGD = UGDA(1,i);
%     txt = [num2str(i), ': ', UGD.Type, ' ', UGD.MolID, ' ', UGD.MeasID, '  ', num2str(UGD.Value)];
%     disp(txt);
% end

% this subsequent code isolates only the parameters that are needed from
% the larger set of UGDA parameters
GDA = MM.GDA;
nGDA = size(GDA, 2);
nUGDA = size(UGDA, 2);

N = 1;
clear RGDA;
for j = 1:nGDA
    GD = GDA(1,j);
    GDType = GD.Type;
    GDMolID = GD.MolID;
    GDMeasID = GD.MeasID;
%     F = 0;
    for i = 1:nUGDA
        UGD = UGDA(1,i);
        if strcmp(GDType, UGD.Type)
            if strcmp(GDMolID, UGD.MolID)
                if strcmp(GDMeasID, UGD.MeasID)
                    RGDA(1, N) = UGD;
                    N = N + 1;
%                     F = 1;
                end 
            end
        end
    end
end

% nRGDA = size(RGDA, 2);
% for i = 1:nRGDA
%     UGD = RGDA(1,i);
%     txt = [num2str(i), ': ', UGD.Type, ' ', UGD.MolID, ' ', UGD.MeasID, '  ', num2str(UGD.Value)];
%     disp(txt);
% end
    
    
%     if F == 0
%         txt = ['Can not find ', GDType, '  ', GDMolID, '  ', GDMeasID];
%         disp(txt);
%     end


end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% GetIsotopomerArray:  builds isotopomer arrays for specific
%%%%%%%%% molecules
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Isotopomers = GetIsotopomerArray(Isotops, MolID)
AMolID = MolID;
if strcmp(AMolID, 'Asp')
    AMolID = 'OAA';
end
if strcmp(AMolID, 'MAG')
    AMolID = 'Glc';
end
if strcmp(AMolID, 'Glu')
    AMolID = 'aKG';
end
Isotopomers = Isotops.(AMolID);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% End GetIsotopomerArray
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% GetMAfromMM:  gets all multiplets from MM based on Molecule name
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function MA = GetMAfromMM(MM, MolID)
if strcmp(MolID, 'Ala')
    MA = MM.AlaMultiplets;
end
if strcmp(MolID, 'Asp')
    MA = MM.AspMultiplets;
end
if strcmp(MolID, 'Glc')
    MA = MM.GlcMultiplets;
end
if strcmp(MolID, 'Glu')
    MA = MM.GluMultiplets;
end
if strcmp(MolID, 'MAG')
    MA = MM.MAGMultiplets;
end
if strcmp(MolID, 'bHB')
    MA = MM.MAGMultiplets;
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% End GetMAfromMM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% GetGDAError:  creates error vector (EV = GDA - UGDA)
%%%%%%%%% molecules
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function EV = GetGDAError(GDA, UGDA)
% assumes matches are already made
nGDA = size(GDA,2);
EV = zeros(1,nGDA);
for i = 1:nGDA
    GD = GDA(1,i);
    UGD = UGDA(1,i);
    EV(1,i) = GD.Value - UGD.Value;
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% End GetGDAError
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% GetLnLikelihoodGDA:  builds log liklihood
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function MM = GetLnLikelihoodGDA(MM)
GDA = MM.GDA;
BestGDA = MM.BestGDA;
nGDA = size(GDA,2);
% STDA = zeros(1, nGDA);
% for i = 1:nGDA
%     GD = GDA(1,i);
%     if strcmp(GD.Type,'Isotopomer')
%         STDA(1, i) = MM.IsotopomerStdEst;
%     end
%     if strcmp(GD.Type,'13C NMR Multiplet')
%         STDA(1, i) = MM.MultipletStdEst;
%     end
%     if strcmp(GD.Type,'MS Isotopologue')
%         STDA(1, i) = MM.IsotopologueStdEst;
%     end
%     if strcmp(GD.Type,'Fractional Enrichment')
%         STDA(1, i) = MM.FEStdEst;
%     end
% end
EV = GetGDAError(GDA, BestGDA);
STD = std(EV);
S1 = 0;
S2 = 0;
for i = 1:nGDA
%     STD  = STDA(1, i);
    A = EV(1, i)/STD;
    A = A^2;
    S1 = S1 + A;
    B = STD*sqrt(2.0*pi);
    S2 = S2 + B;
end
LnL = -(S1/2.0) - S2;
MM.LnL = LnL;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% End GetLnLikelihoodGDA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% GetAICGDA:  builds Akaike information content
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function MM = GetAICGDA(MM)
% https://en.wikipedia.org/wiki/Akaike_information_criterion

X = MM.BestX;
nX = size(X, 2);
LnL = MM.LnL;
AIC = 2.0*(nX - LnL);
MM.AIC = AIC;

GDA = MM.GDA;
nGDA = size(GDA,2);

Num = nX^2;
Num = Num + nX;
Num = 2.0*Num;

Den = nGDA - nX - 1;

AICc = -1.0;
if Den > 0
   C = Num/Den;
   AICc = AIC + C;
end
MM.AICc = AICc;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% End GetAICGDA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%