function WritePreambleTCAC(fileID, tcaSIMID, tcaCALCID, ExptID)
txt = 'Copyright: 2019 UTSouthwestern Advanced Imaging Research Center\n';
fprintf(fileID, txt);

txt = 'All rights reserved\n';
fprintf(fileID, txt);

txt = 'Design by NeuroSpectroScopics LLC\n';
fprintf(fileID, txt);

txt = 'www.neurospectroscopics.com\n';
fprintf(fileID, txt);

txt = 'Send questions/comments to jeff@neurospectroscopics.com\n';
fprintf(fileID, txt);

txt1 = 'Acknowledgement for publications: ';
txt2 = 'Development of tcaCALC ';
txt3 = 'was supported by funding from NIH/NIBIB P41 EB015908\n ';
txt = [txt1, txt2, txt3];
fprintf(fileID, txt);

txt = 'NOT FOR CLINICAL USE\n';
fprintf(fileID, txt);

txt = '\n';
fprintf(fileID, txt);

txt = '\n';
fprintf(fileID, txt);

txt = '\n';
fprintf(fileID, txt);


txt = ['tcaSIM Metabolic Simulator Version: ', tcaSIMID, '\n'];
fprintf(fileID, txt);

txt = ['Acetyl-CoA synthetase (ACS): ', ...
       'This version of the tcaSIM Metabolic Simulator defines ', ...
       'ACS relative to Pyruvate dehydrogenase (PDH) such that \n', ...
       'ACS + PDH = 1\n'];
fprintf(fileID, txt);

txt = ['Lactate dehydrogenase (LDH): ', ...
       'This version of the tcaSIM Metabolic Simulator defines ', ...
       'LDH relative to Pyruvate dehydrogenase (PDH) and Pyruvate ' ...
       'carboxylse (Ypc) and Pyruvate Kinase (PK) such that \n', ...
       'LDH = Ypc + PDH - PK\n'];
fprintf(fileID, txt);

txt = '\n\n\n';
fprintf(fileID, txt);

txt = ['tcaCALC Version: ', tcaCALCID, '\n'];
fprintf(fileID, txt);
txt = ['This version of the tcaCALC uses fminsearchbnd.m written by ', ...
       'John ', 'dErrico\n'];
fprintf(fileID, txt);

txt = '\n\n\n';
fprintf(fileID, txt);

txt = ['Experiment ID: ', ExptID, '\n'];
fprintf(fileID, txt);

txt = char(datetime('now'));
txt = ['tcaCALC Run Date/Time: ', txt, '\n'];
fprintf(fileID, txt);

txt = '\n\n\n';
fprintf(fileID, txt);
end

