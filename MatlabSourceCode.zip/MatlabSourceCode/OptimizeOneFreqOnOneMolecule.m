function RMolecule = OptimizeOneFreqOnOneMolecule(Molecule, Spectrum, ...
                       TestFreqsPPMRange, TestFreqsPPMInc, ...
                       PPMLow, PPMHigh)
nTests = round(TestFreqsPPMRange/TestFreqsPPMInc);
StartValue = -TestFreqsPPMRange/2.0;
ValueInc = TestFreqsPPMInc;
TestValues = zeros(nTests, 1);
for i = 1:nTests
    TestValues(i) = StartValue + ((i-1)*ValueInc);
end
TestFreqIncs = TestValues;

JAPPM = Molecule.JAPPM;
LabelPattern = Molecule.LabelPattern;
Signals = Molecule.Signals;
Signal = Signals(1);
ShapeParams = Signal.ShapeParams;
GlobalR2 = ShapeParams(1);
sf = Spectrum.ScannerFreqMHz;
CenterPPM = Spectrum.CenterPPM;
SampleTimesSec = Spectrum.SampleTimesSec;
MolConc = Molecule.Conc;
ID = Molecule.ID;


FreqsPPM = Molecule.FreqsPPM;
PlotCenter = Molecule.PlotCenters;
nFreqs = size(FreqsPPM,2);
LIdx = 0;
for i = 1:nFreqs
    if FreqsPPM(1,i) == PlotCenter
        LIdx = i;
    end
end

TestFreqsPPM = FreqsPPM;
for j = 1:nTests
    TestFreqsPPM = FreqsPPM;
    TestFreqsPPM(1, LIdx) = FreqsPPM(1, LIdx) + TestFreqIncs(j, 1);
    TestMolecule = BuildIsotopMolecule(LabelPattern, TestFreqsPPM, ...
                      JAPPM, MolConc, GlobalR2, sf, SampleTimesSec, CenterPPM);
    TestMolecule = FitMoleculeConcOverPPMRange(Spectrum, ...
                      TestMolecule, PPMLow, PPMHigh);   
    R = GetResidualOverPPMRange(TestMolecule, Spectrum, PPMLow, PPMHigh);
    if j == 1
        BestTestMolecule = TestMolecule;
        BestR = R;
    end
    if R < BestR
       BestTestMolecule = TestMolecule;
       BestR = R;
    end
end
FreqsPPM = BestTestMolecule.FreqsPPM;
BestTestMolecule.PlotCenters = FreqsPPM(LIdx);
BestTestMolecule.ID = ID;
RMolecule = BestTestMolecule;
end

