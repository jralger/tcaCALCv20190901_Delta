function BestMolecule = OptimizeJAPPMOnOneMolecule(Molecule, Spectrum, ...
                       TestJPPMRange, TestJPPMInc, ...
                       PPMLow, PPMHigh)
nTests = round(TestJPPMRange/TestJPPMInc);
StartValue = -TestJPPMRange/2.0;
ValueInc = TestJPPMInc;
TestValues = zeros(nTests, 1);
for i = 1:nTests
    TestValues(i) = StartValue + ((i-1)*ValueInc);
end

ID = Molecule.ID;
JAPPM = Molecule.JAPPM;
FreqsPPM = Molecule.FreqsPPM;
LabelPattern = Molecule.LabelPattern;
PlotCenters = Molecule.PlotCenters;
Signals = Molecule.Signals;
Signal = Signals(1);
ShapeParams = Signal.ShapeParams;
GlobalR2 = ShapeParams(1);
sf = Spectrum.ScannerFreqMHz;
CenterPPM = Spectrum.CenterPPM;
SampleTimesSec = Spectrum.SampleTimesSec;
MolConc = Molecule.Conc;

BestMolecule = Molecule;
BestMolecule = FitMoleculeConcOverPPMRange(Spectrum, ...
                        BestMolecule, PPMLow, PPMHigh);
BestR = GetResidualOverPPMRange(BestMolecule, Spectrum, PPMLow, PPMHigh);
nJ = size(JAPPM, 1);
for i=1:nJ
    for j=1:nJ
        if i < j
            if JAPPM(i,j) ~= 0.0
                for k = 1:nTests
                    TestJAPPM = JAPPM;
                    TestJAPPM(i,j) = TestJAPPM(i,j) + TestValues(k);
                    TestJAPPM(j,i) = TestJAPPM(i,j);
                    TestMolecule = BuildIsotopMolecule(LabelPattern, FreqsPPM, ...
                        TestJAPPM, MolConc, GlobalR2, sf, SampleTimesSec, CenterPPM);
                    TestMolecule.ID = ID;
                    TestMolecule.PlotCenters = PlotCenters;
                    TestMolecule = FitMoleculeConcOverPPMRange(Spectrum, ...
                        TestMolecule, PPMLow, PPMHigh);
                    R = GetResidualOverPPMRange(TestMolecule, Spectrum, PPMLow, PPMHigh);
                    if R < BestR
                        BestR = R;
                        BestMolecule = TestMolecule;
%                         BestJAPPM = TestJAPPM;
                    end
                end
            end
        end
    end
end

% dummy = 1; 
end

