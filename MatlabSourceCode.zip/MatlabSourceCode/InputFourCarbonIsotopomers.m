function varargout = InputFourCarbonIsotopomers(varargin)
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @InputFourCarbonIsotopomers_OpeningFcn, ...
                   'gui_OutputFcn',  @InputFourCarbonIsotopomers_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

function hObject = CheckFixNegatives(hObject)
 V = str2double(get(hObject,'String'));
 if V < 0
     hObject.String = ['0'];
 end
         
function hObject = CheckFixGTOne(hObject)
 V = str2double(get(hObject,'String'));
 if V > 1.0
     hObject.String = ['1'];
 end

 function [handles, A] = DoCallBack(hObject, handles)
hObject = CheckFixGTOne(hObject);
hObject = CheckFixNegatives(hObject);
[handles, A] = ReadUpdateAllFourCarbonIsotopomers(handles);
guidata(hObject, handles);

function InputFourCarbonIsotopomers_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
MolID = char(varargin(2));
A = cell2mat(varargin(3));
handles.MoleculeID.String = MolID;

[oooo, xooo, oxoo, xxoo, ooxo, xoxo, oxxo, xxxo, ...
 ooox, xoox, oxox, xxox, ooxx, xoxx, oxxx, xxxx] = ... 
                                           DefineFourCarbonLabelIndices();

handles.OOOO.String = sprintf('%4.2f',A(1, oooo));
handles.XOOO.String = sprintf('%4.2f',A(1, xooo));
handles.OXOO.String = sprintf('%4.2f',A(1, oxoo));
handles.XXOO.String = sprintf('%4.2f',A(1, xxoo));

handles.OOXO.String = sprintf('%4.2f',A(1, ooxo));
handles.XOXO.String = sprintf('%4.2f',A(1, xoxo));
handles.OXXO.String = sprintf('%4.2f',A(1, oxxo));
handles.XXXO.String = sprintf('%4.2f',A(1, xxxo));

handles.OOOX.String = sprintf('%4.2f',A(1, ooox));
handles.XOOX.String = sprintf('%4.2f',A(1, xoox));
handles.OXOX.String = sprintf('%4.2f',A(1, oxox));
handles.XXOX.String = sprintf('%4.2f',A(1, xxox));

handles.OOXX.String = sprintf('%4.2f',A(1, ooxx));
handles.XOXX.String = sprintf('%4.2f',A(1, xoxx));
handles.OXXX.String = sprintf('%4.2f',A(1, oxxx));
handles.XXXX.String = sprintf('%4.2f',A(1, xxxx));

[handles, A] = ReadUpdateAllFourCarbonIsotopomers(handles);
guidata(hObject, handles);
uiwait(handles.figure1);

function varargout = InputFourCarbonIsotopomers_OutputFcn(hObject, eventdata, handles)
[handles, A] = ReadUpdateAllFourCarbonIsotopomers(handles);
varargout{1} = A;
close();

%%%%%%%%%%%%%%%%%%%%%%%%%%% All CreateFcns %%%%%%%%%%%%%%%%%%%%%%%%%%% 

function OOOO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function XOOO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function OXOO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function XXOO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function OOXO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function XOXO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function OXXO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function XXXO_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function OOOX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function XOOX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function OXOX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function XXOX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function OOXX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function XOXX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function OXXX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function XXXX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%% END All CreateFcns %%%%%%%%%%%%%%%%%%%%%%%%%%% 

%%%%%%%%%%%%%%%%%%%%%%%%%%% All Callbacks
function OOOO_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function XOOO_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function OXOO_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function XXOO_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function OOXO_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function XOXO_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function OXXO_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function XXXO_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function OOOX_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function XOOX_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function OXOX_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function XXOX_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function OOXX_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function XOXX_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function OXXX_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function XXXX_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);

function pushbutton1_Callback(hObject, eventdata, handles)
[handles, A] = ReadUpdateAllFourCarbonIsotopomers(handles);
uiresume;
%%%%%%%%%%%%%%%%%%%%%%%%%%%% End all callbacks






























