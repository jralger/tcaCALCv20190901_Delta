function Spectrum = FixSpectrumBaseline(Spectrum, PPMLow, PPMHigh, PPMEdgeRange)
FD = Spectrum.FreqDomainData;
PPMTable = Spectrum.PPMTable;
BLPPMHigh = FD(PPMTable <= PPMHigh & PPMTable >= PPMHigh - PPMEdgeRange);
BLPPMLow = FD(PPMTable >= PPMLow & PPMTable <= PPMLow + PPMEdgeRange);
meanBLPPMHigh = mean(BLPPMHigh);
meanBLPPMLow = mean(BLPPMLow);
meanBL = mean([meanBLPPMLow, meanBLPPMHigh]);
FD(PPMTable >= PPMLow & PPMTable <= PPMHigh) =  FD(PPMTable >= PPMLow & PPMTable <= PPMHigh) - meanBL;
Spectrum.FreqDomainData = FD;
end

