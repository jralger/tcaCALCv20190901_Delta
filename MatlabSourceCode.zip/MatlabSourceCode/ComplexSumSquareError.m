function SSE = ComplexSumSquareError(CD, CM)
D = CM - CD;
reD = real(D);
imD = imag(D);
reDsq = reD.^2;
imDsq = imD.^2;
SSE = sum(reDsq) + sum(imDsq);
end

