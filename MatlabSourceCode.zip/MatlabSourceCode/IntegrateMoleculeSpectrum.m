function RMolecule = IntegrateMoleculeSpectrum(Molecule, IntWidthPPM)
RMolecule = Molecule;
Spectrum = Molecule.ConcWtdSpectrum;
PPMTable = Spectrum.PPMTable;
CS = Spectrum.FreqDomainData;
ReCS = real(CS);
FreqsPPM = Molecule.FreqsPPM;
nFreqs = size(FreqsPPM, 2);
Integrals = FreqsPPM*0.0;
for i = 1:nFreqs
    PPMLow = FreqsPPM(i) - (IntWidthPPM/2.0);
    PPMHigh = FreqsPPM(i) + (IntWidthPPM/2.0);
    T = ReCS(PPMTable >= PPMLow & PPMTable <= PPMHigh);
    Integrals(i) = sum(T);
end
Rmolecule.Integrals = Integrals;
end

