function Spectrum = ReadCSVSpectrum(FN)
h = waitbar(0, 'Please wait: Reading 13C NMR spectrum from CSV');
ScannerFreqMHz = 150.90;
ImagSign = '+1.0';
f = fopen(FN, 'r');
A = 'A';
nPPM = 0;
while ischar(A)
      A = fgetl(f);
      if ischar(A)
          B = strsplit(A, ',');
          if strcmp(B(1), 'SF')
              ScannerFreqMHz = str2double(B(2));
          end
          if strcmp(B(1), 'ImagSign')
              ImagSign = str2double(B(2));
          end
          if ~strcmp(B(1), 'SF')
               if ~strcmp(B(1), 'ImagSign')
                   if ~strcmp(B(1), 'PPM')
                       nPPM = nPPM + 1;
                   end
               end
          end
      end 
end
fclose(f);
PPMV = zeros(nPPM, 1);
ReS = zeros(nPPM, 1);
ImS = zeros(nPPM, 1);
SampleTimesSec = zeros(nPPM, 1);
waitbar((1.0/3.0), h, 'Please wait: Reading 13C NMR spectrum from CSV');

f = fopen(FN, 'r');
A = 'A';
n = 1;
for i = 1:nPPM+2
      A = fgetl(f);
      B = strsplit(A, ',');
      if ~strcmp(B(1), 'SF')
         if ~strcmp(B(1), 'ImagSign')
             if ~strcmp(B(1), 'PPM')
                 PPMV(n, 1) = str2double(B(1));
                 ReS(n, 1) = str2double(B(2));
                 ImS(n, 1) = ImagSign*str2double(B(3));
                 Q = rem(n, 512);
                 if Q == 0
                     Z = (1.0/3.0) + ((1.0/3.0)*(n/nPPM));
                     waitbar(Z, h, 'Please wait: Reading 13C NMR spectrum from CSV');
                 end
                 n = n + 1;
             end
         end
      end
end

fclose(f);



S = complex(ReS, ImS);
CenterPPM = mean(PPMV);

BWPPM = max(PPMV) - min(PPMV);
BWHz = BWPPM * ScannerFreqMHz;
maxF = BWHz/2.0;
minP = 1.0/maxF;
SampleTimeSec = minP/2.0;

for i = 0:nPPM-1
    SampleTimesSec(i+1, 1) = SampleTimeSec*i;
    Z = (2.0/3.0) + ((1.0/3.0)*(i/nPPM));
    Q = rem(i, 512);
    if Q == 0
        waitbar(Z, h, 'Please wait: Reading 13C NMR spectrum from CSV');
    end
end


Spectrum.FreqDomainData = S;
Spectrum.PPMTable = PPMV;
Spectrum.CenterPPM = CenterPPM;
Spectrum.ScannerFreqMHz = ScannerFreqMHz;
Spectrum.SampleTimesSec = SampleTimesSec;

close(h);
end




