function Spectrum = ReadTopSpinSpectrumFullSW(rfile, ifile, procfile)

f = fopen(procfile, 'r');
A = fscanf(f, '%s');
fclose(f);
A = strsplit(A, '##');
nA = size(A, 2);
for i = 1:nA
    B = char(A(1,i));
    C = strsplit(B, '=');
    nC = size(C, 2);
    if nC == 2
        D = char(C(1));
        if strmatch(D,'$F1P')
           F1P = char(C(2));
        end
        if strmatch(D,'$F2P')
           F2P = char(C(2));
        end
        if strmatch(D,'$BYTORDP')
           BYTORDP = char(C(2));
        end
        if strmatch(D,'$LB')
           LB = char(C(2));
        end
        if strmatch(D,'$$LPBIN')
           LPBIN = char(C(2));
        end
        if strmatch(D,'$OFFSET')
           OFFSET = char(C(2));
        end
        if strmatch(D,'$PHC0')
           PHC0 = char(C(2));
        end
        if strmatch(D,'$PHC1')
           PHC1 = char(C(2));
        end
        if strmatch(D,'$PPMPNUM')
           PPMPNUM = char(C(2));
        end
        if strmatch(D,'$SF')
           SF = char(C(2));
        end
        if strmatch(D,'$SI')
           SI = char(C(2));
        end
        if strmatch(D,'$SW_p')
           SW_p = char(C(2));
        end
        if strmatch(D,'$TDeff')
           TDeff = char(C(2));
        end
        if strmatch(D,'$xxxx')
           xxxxxx = char(C(2));
        end
        if strmatch(D,'$xxxx')
           xxxxxx = char(C(2));
        end
        if strmatch(D,'$xxxx')
           xxxxxx = char(C(2));
        end
        if strmatch(D,'$xxxx')
           xxxxxx = char(C(2));
        end
    end
end

fileID = fopen(rfile,'r', 'b');
reS = fread(fileID, 'int32', 'l');
fclose(fileID);

fileID = fopen(ifile,'r', 'b');
imS = fread(fileID, 'int32', 'l');
fclose(fileID);

CS = complex(reS, imS);
nCS = size(CS,1);

SF = str2double(SF);
SW = str2double(SW_p);

SWPPM = SW/SF;
% RefShift = 57.63;
RefShift = 0.57*SWPPM;
PPMLow = (-SWPPM/2.0) + RefShift;
PPMHigh = PPMLow + SWPPM;

dPPM = (PPMHigh - PPMLow)/(nCS - 1);
CenterPPM = (PPMHigh - PPMLow)/2.0;
PPMTable = zeros(nCS, 1);
% n = 1;
for n = 1:nCS
    PPMTable(n) = PPMHigh - ((n-1)*dPPM);
end

MaxF = SW/2.0;
MinP = 1.0/MaxF;
NyqvistP = MinP/2.0;
SampleTimesSec = zeros(nCS, 1);
for n = 1:nCS
    SampleTimesSec(n) = (n-1)*NyqvistP;
end


Spectrum.FreqDomainData = CS;
Spectrum.PPMTable = PPMTable;
Spectrum.CenterPPM = CenterPPM;
Spectrum.ScannerFreqMHz = SF;
Spectrum.SampleTimesSec = SampleTimesSec;

end

