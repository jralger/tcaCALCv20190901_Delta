function V = EstimateThreeCarbonNaturalAbundance()
[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                                          DefineThreeCarbonLabelIndices();
V = zeros(1,8);
V(1, ooo) = 1.0;
end

