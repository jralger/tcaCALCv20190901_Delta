function V = BuildSixCarbonNaturalAbundance(A)

[oooooo, xooooo, oxoooo, xxoooo, ...
 ooxooo, xoxooo, oxxooo, xxxooo, ...
 oooxoo, xooxoo, oxoxoo, xxoxoo, ...
 ooxxoo, xoxxoo, oxxxoo, xxxxoo, ...
 ooooxo, xoooxo, oxooxo, xxooxo, ...
 ooxoxo, xoxoxo, oxxoxo, xxxoxo, ...
 oooxxo, xooxxo, oxoxxo, xxoxxo, ...
 ooxxxo, xoxxxo, oxxxxo, xxxxxo, ...
 ooooox, xoooox, oxooox, xxooox, ...
 ooxoox, xoxoox, oxxoox, xxxoox, ...
 oooxox, xooxox, oxoxox, xxoxox, ...
 ooxxox, xoxxox, oxxxox, xxxxox, ...
 ooooxx, xoooxx, oxooxx, xxooxx, ...
 ooxoxx, xoxoxx, oxxoxx, xxxoxx, ...
 oooxxx, xooxxx, oxoxxx, xxoxxx, ...
 ooxxxx, xoxxxx, oxxxxx, xxxxxx] ...
                           = DefineSixCarbonLabelIndices();

A1 = A;
A2 = A*A;
A3 = A*A*A;
A4 = A*A*A*A;
A5 = A*A*A*A*A;
A6 = A*A*A*A*A*A;

V = zeros(1,64);

V(1, xooooo) = A1;
V(1, oxoooo) = A1;
V(1, xxoooo) = A2;

V(1, ooxooo) = A1;
V(1, xoxooo) = A2;
V(1, oxxooo) = A2;
V(1, xxxooo) = A3;

V(1, oooxoo) = A1;
V(1, xooxoo) = A2;
V(1, oxoxoo) = A2;
V(1, xxoxoo) = A3;

V(1, ooxxoo) = A2;
V(1, xoxxoo) = A3;
V(1, oxxxoo) = A3;
V(1, xxxxoo) = A4;

V(1, ooooxo) = A1;
V(1, xoooxo) = A2;
V(1, oxooxo) = A2;
V(1, xxooxo) = A3;

V(1, ooxoxo) = A2;
V(1, xoxoxo) = A3;
V(1, oxxoxo) = A3;
V(1, xxxoxo) = A4;

V(1, oooxxo) = A2;
V(1, xooxxo) = A3;
V(1, oxoxxo) = A3;
V(1, xxoxxo) = A4;

V(1, ooxxxo) = A3;
V(1, xoxxxo) = A4;
V(1, oxxxxo) = A4;
V(1, xxxxxo) = A5;

V(1, ooooox) = A1;
V(1, xoooox) = A2;
V(1, oxooox) = A2;
V(1, xxooox) = A3;

V(1, ooxoox) = A2;
V(1, xoxoox) = A3;
V(1, oxxoox) = A3;
V(1, xxxoox) = A4;

V(1, oooxox) = A2;
V(1, xooxox) = A3;
V(1, oxoxox) = A3;
V(1, xxoxox) = A4;

V(1, ooxxox) = A3;
V(1, xoxxox) = A4;
V(1, oxxxox) = A4;
V(1, xxxxox) = A5;

V(1, ooooxx) = A2;
V(1, xoooxx) = A3;
V(1, oxooxx) = A3;
V(1, xxooxx) = A4;

V(1, ooxoxx) = A3;
V(1, xoxoxx) = A4;
V(1, oxxoxx) = A4;
V(1, xxxoxx) = A5;

V(1, oooxxx) = A3;
V(1, xooxxx) = A4;
V(1, oxoxxx) = A4;
V(1, xxoxxx) = A5;

V(1, ooxxxx) = A4;
V(1, xoxxxx) = A5;
V(1, oxxxxx) = A5;
V(1, xxxxxx) = A6;

T = sum(V(1,:));
V(1, oooooo) = 1.0 - T;
                    
end

