function RMolecule = EstimateConcByRatio(Molecule, Spectrum, ...
                            RatioThreshold)
%assumes spectrum pas been phased
RMolecule = Molecule;
NormSpectrum = RMolecule.NormSpectrum;
NCS = NormSpectrum.FreqDomainData;
PPMT = NormSpectrum.PPMTable;
ReNCS = real(NCS);
MaxReNCS = max(ReNCS); 
LBReNCS = MaxReNCS*RatioThreshold;
                   
CS = Spectrum.FreqDomainData;
ReCS = real(CS);

A = ReNCS(ReNCS > LBReNCS);
B = ReCS(ReNCS > LBReNCS);
Q =PPMT(ReNCS > LBReNCS);
R = B./A;
R = mean(R);
RMolecule.Conc = R;
ConcWtdSpectrum = RMolecule.NormSpectrum;
ConcWtdSpectrum.FreqDomainData = R*NCS;
RMolecule.ConcWtdSpectrum = ConcWtdSpectrum;
end                
                   
       

