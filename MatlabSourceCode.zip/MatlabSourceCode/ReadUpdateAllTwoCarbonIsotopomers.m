function [handles, A] = ReadUpdateAllTwoCarbonIsotopomers(handles)

[oo, xo, ox, xx] = DefineTwoCarbonLabelIndices();
A = zeros(1,4);

A(1, xo) = str2double(handles.XO.String);
A(1, ox) = str2double(handles.OX.String);
A(1, xx) = str2double(handles.XX.String);

A = UpdateUnLabelledIsotopomer(A);

if A(1, oo) < 0
    A = zeros(1, 4);
    A = UpdateUnLabelledIsotopomer(A);
end

handles.OO.String = sprintf('%4.2f', A(1, oo));
handles.XO.String = sprintf('%4.2f', A(1, xo));
handles.OX.String = sprintf('%4.2f', A(1, ox));
handles.XX.String = sprintf('%4.2f', A(1, xx));

end