function RA = ReadOneMAcsv(FN)

% FN = 'C:\Users\Jeffry R Alger\Desktop\IsotopomerAnalysisGuide\AgilentFIDs\A\IMA0Results\MultipletResults.csv'
fileID = fopen(FN,'r');
A = 'A';
n = 1;
m = 1;
while ischar(A)
      A = fgetl(fileID);
      nA = size(A);
      if n >= 10
          if ischar(A)
%              B = [num2str(n), ': ', A];
%              disp(B);
             C = strsplit(A, ',');
             D = char(C(1));
             R.SpectrumID = D;
             D = char(C(2));
             R.MultipletID = D;
%              R.ID = D;
             D = str2num(char(C(3)));
             R.FractionalIntensityBestFit = D;
             D = str2num(char(C(4)));
             R.FractionalIntegralBestFit = D;
             D = str2num(char(C(5)));
             R.RawIntensityBestFit = D;
             D = str2num(char(C(6)));
             R.MultipletCenterPPM = D;
             D = str2num(char(C(7)));
             R.IsotopeShift = D;
             D = char(C(8));
             R.LorentzR2 = D;
             D = str2num(char(C(9)));
             R.R1SatFactor = D;
             JAHz = zeros(6);
             D = char(C(10));
             if ~strmatch(D, 'N/A')
                D = str2num(D);
                JAHz(1,2) = D;
                JAHz(2,1) = D;
             end
             D = char(C(11));
             if ~strmatch(D, 'N/A')
                D = str2num(D);
                JAHz(1,3) = D;
                JAHz(3,1) = D;
             end
             D = char(C(12));
             if ~strmatch(D, 'N/A')
                D = str2num(D);
                JAHz(1,4) = D;
                JAHz(4,1) = D;
             end
             D = char(C(13));
             if ~strmatch(D, 'N/A')
                D = str2num(D);
                JAHz(1,5) = D;
                JAHz(5,1) = D;
             end
             D = char(C(14));
             if ~strmatch(D, 'N/A')
                D = str2num(D);
                JAHz(1,6) = D;
                JAHz(6,1) = D;
             end
             D = char(C(15));
             if ~strmatch(D, 'N/A')
                D = str2num(D);
                JAHz(2,3) = D;
                JAHz(3,2) = D;
             end
             D = char(C(16));
             if ~strmatch(D, 'N/A')
                D = str2num(D);
                JAHz(2,4) = D;
                JAHz(4,2) = D;
             end
             D = char(C(17));
             if ~strmatch(D, 'N/A')
                D = str2num(D);
                JAHz(2,5) = D;
                JAHz(5,2) = D;
             end
             D = char(C(18));
             if ~strmatch(D, 'N/A')
                D = str2num(D);
                JAHz(2,6) = D;
                JAHz(6,2) = D;
             end
             D = char(C(19));
             if ~strmatch(D, 'N/A')
                D = str2num(D);
                JAHz(3,4) = D;
                JAHz(4,3) = D;
             end
             D = char(C(20));
             if ~strmatch(D, 'N/A')
                D = str2num(D);
                JAHz(3,5) = D;
                JAHz(5,3) = D;
             end
             D = char(C(21));
             if ~strmatch(D, 'N/A')
                D = str2num(D);
                JAHz(3,6) = D;
                JAHz(6,3) = D;
             end
             D = char(C(22));
             if ~strmatch(D, 'N/A')
                D = str2num(D);
                JAHz(4,5) = D;
                JAHz(5,4) = D;
             end
             D = char(C(23));
             if ~strmatch(D, 'N/A')
                D = str2num(D);
                JAHz(4,6) = D;
                JAHz(6,4) = D;
             end
             D = char(C(24));
             if ~strmatch(D, 'N/A')
                D = str2num(D);
                JAHz(5,6) = D;
                JAHz(6,5) = D;
             end
             R.JAHz = JAHz;
             R.OrganID = 'Unk';
             R.ExptID = 'Unk';
             R.FN = FN;
             RA(m) = R;
             m = m + 1;
          end
      end
      n = n + 1;
end
fclose(fileID);
nRA = size(RA, 2);
end

