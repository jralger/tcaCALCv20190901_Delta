function Spectrum = BuildDefaultSpectrum()

nCS = 131072;
reS = zeros(nCS, 1);
imS = zeros(nCS, 1);
CS = complex(reS, imS);
SF = 150.84246;
PPMHigh = 219.9074;
PPMLow = -19.1348;
dPPM = (PPMHigh - PPMLow)/(nCS - 1);
CenterPPM = (PPMHigh - PPMLow)/2.0;
PPMTable = zeros(nCS, 1);
for n = 1:nCS
    PPMTable(n) = PPMHigh - ((n-1)*dPPM);
end
SW = PPMHigh - PPMLow;
SW = SW*SF;
MaxF = SW/2.0;
MinP = 1.0/MaxF;
NyqvistP = MinP/2.0;
SampleTimesSec = zeros(nCS, 1);
for n = 1:nCS
    SampleTimesSec(n) = (n-1)*NyqvistP;
end

Spectrum.FreqDomainData = CS;
Spectrum.PPMTable = PPMTable;
Spectrum.CenterPPM = CenterPPM;
Spectrum.ScannerFreqMHz = SF;
Spectrum.SampleTimesSec = SampleTimesSec;

end

