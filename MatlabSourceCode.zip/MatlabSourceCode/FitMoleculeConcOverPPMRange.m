function BestFitMolecule = FitMoleculeConcOverPPMRange(Spectrum, Molecule, ...
                                 PPMLow, PPMHigh)
ppmtable = Spectrum.PPMTable;
NormSpectrum = Molecule.NormSpectrum;
NormFD = NormSpectrum.FreqDomainData;
NormFD = NormFD(ppmtable >= PPMLow & ppmtable <= PPMHigh);
Conc = Molecule.Conc;
MeasuredFD = Spectrum.FreqDomainData;
MeasuredFD = MeasuredFD(ppmtable >= PPMLow & ppmtable <= PPMHigh);
ppmtable = ppmtable(ppmtable >= PPMLow & ppmtable <= PPMHigh);

model = @FitConcFunc;
BestFitConc = fminsearch(model, Conc);
if BestFitConc < 0.0
    BestFitConc = 0.0;
end

BestFitFD = NormFD*BestFitConc; 
ConcWtdSpectrum = Molecule.ConcWtdSpectrum;
ConcWtdSpectrum.FreqDomainData = BestFitFD;
ConcWtdSpectrum.PPMTable = ppmtable;
BestFitMolecule = Molecule;
BestFitMolecule.Conc = BestFitConc;
BestFitMolecule.ConcWtdSpectrum = ConcWtdSpectrum;

     function [SSE, ModelFD] = FitConcFunc(Conc)
         ModelFD = NormFD*Conc;        
         SSE = ComplexSumSquareError(MeasuredFD, ModelFD);
     end
end


