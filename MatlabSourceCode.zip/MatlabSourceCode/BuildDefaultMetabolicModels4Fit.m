function MMs = BuildDefaultMetabolicModels4Fit()
R0 = 0.5;
XTol = 1e-40;
FTol = 1e-40;
nIter = 4000;
nFEvs = 4000;
UseXform = 0;

MM = DefineDefaultMetabolicModel();

MM.XTol = XTol;
MM.FTol = FTol;
MM.nIter = nIter;
MM.nFEvs = nFEvs;
MM.UseXform = UseXform;

C13NA = MM.ExactNaturalAbundance*Define13CNaturalAbundance();

MM.SuccYs = BuildFourCarbonNaturalAbundance(C13NA);
MM.Lac = BuildThreeCarbonNaturalAbundance(C13NA);
MM.Glyc = BuildThreeCarbonNaturalAbundance(C13NA);
MM.FA = BuildTwoCarbonNaturalAbundance(C13NA);
MM.CO2 = BuildOneCarbonNaturalAbundance(C13NA);
MM.Gln = BuildFiveCarbonNaturalAbundance(C13NA);

MM.Ys = R0;
MM.YPC = R0;
MM.PDH = R0;
MM.PK = R0;
MM.XIDs = {'Ys',  'YPC',  'PDH',  'PK'};
MM.ExptID = 'Model01';
N = 1;
MMs(1, N) = MM;
N = N + 1;

MM.XIDs = {'Ys',  'YPC',  'PDH'};
MM.ExptID = 'Model02';
MM.Ys = R0;
MM.YPC = R0;
MM.PDH = R0;
MM.PK = 0.0;
MMs(1, N) = MM;
N = N + 1;

MM.XIDs = {'Ys',  'PDH',  'PK'};
MM.ExptID = 'Model03';
MM.Ys = R0;
MM.YPC = 0.0;
MM.PDH = R0;
MM.PK = R0;
MMs(1, N) = MM;
N = N + 1;

MM.XIDs = {'Ys',  'YPC',  'PK'};
MM.ExptID = 'Model04';
MM.Ys = R0;
MM.YPC = R0;
MM.PDH = 0.0;
MM.PK = R0;
MMs(1, N) = MM;
N = N + 1;

MM.XIDs = {'YPC',  'PDH',  'PK'};
MM.ExptID = 'Model05';
MM.Ys = 0.0;
MM.YPC = R0;
MM.PDH = R0;
MM.PK = R0;
MMs(1, N) = MM;
N = N + 1;

MM.XIDs = {'YPC',  'PDH'};
MM.ExptID = 'Model07';
MM.Ys = 0.0;
MM.YPC = R0;
MM.PDH = R0;
MM.PK = 0.0;
MMs(1, N) = MM;
N = N + 1;

MM.XIDs = {'Ys',  'PDH'};
MM.ExptID = 'Model08';
MM.Ys = R0;
MM.YPC = 0.0;
MM.PDH = R0;
MM.PK = 0.0;
MMs(1, N) = MM;
N = N + 1;

MM.XIDs = {'YPC',  'PK'};
MM.ExptID = 'Model09';
MM.Ys = 0.0;
MM.YPC = R0;
MM.PDH = 0.0;
MM.PK = R0;
MMs(1, N) = MM;
N = N + 1;

MM.XIDs = {'Ys', 'YPC'};
MM.ExptID = 'Model11';
MM.Ys = R0;
MM.YPC = R0;
MM.PDH = 0.0;
MM.PK = 0.0;
MMs(1, N) = MM;
N = N + 1;

MM.XIDs = {'PDH'};
MM.ExptID = 'Model12';
MM.Ys = 0.0;
MM.YPC = 0.0;
MM.PDH = R0;
MM.PK = 0.0;
MMs(1, N) = MM;
N = N + 1;

MM.XIDs = {'Ys'};
MM.ExptID = 'Model13';
MM.Ys = R0;
MM.YPC = 0.0;
MM.PDH = 0.0;
MM.PK = 0.0;
MMs(1, N) = MM;
N = N + 1;

MM.XIDs = {'YPC'};
MM.ExptID = 'Model14';
MM.Ys = 0.0;
MM.YPC = R0;
MM.PDH = 0.0;
MM.PK = 0.0;
MMs(1, N) = MM;
N = N + 1;

MM.XIDs = {};
MM.ExptID = 'Model16';
MM.Ys = 0.0;
MM.YPC = 0.0;
MM.PDH = 0.0;
MM.PK = 0.0;
MMs(1, N) = MM;

end

