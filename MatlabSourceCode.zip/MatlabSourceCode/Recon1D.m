function Spectrum = Recon1D(FID, ZF, DoConj)
S = FID.TimeDomainDataRaw;
STS = FID.SampleTimesSec;
szS = size(S, 1);

% ZF not right case crash in CalcPPMTable
if ZF
    TS = S;
    TS(:) = 0.0 + 0.0j;
    dt = STS(2) - STS(1);
    LSTS = STS(szS);
    TSTS = STS + LSTS + dt;
    S = cat(1, S, TS);
    STS = cat(1, STS, TSTS);
    szS = size(S, 1);
    TS = 0;
    FID.TimeDomainDataRaw = S;
    FID.SampleTimesSec = STS;
end

T = mod(szS, 2);
if T ~= 0.0
    S = S(1:szS-1);
    FID.TimeDomainDataRaw = S;
    STS = STS(1:szS-1);
    FID.SampleTimesSec = STS;
    szS = size(S, 1);
end

if DoConj 
   S = conj(S);
end

npts = size(S, 1);
S = fft(S);
S = circshift(S, npts/2);
S = S/npts;

Spectrum = FID;
Spectrum.FreqDomainData = S;
SampleTimesSec = FID.SampleTimesSec;
ScannerFreqMHz = FID.ScannerFreqMHz;
CenterPPM = FID.CenterPPM;
Spectrum.PPMTable = CalculatePPMTableFromSampleTimes(SampleTimesSec, ...
           ScannerFreqMHz, CenterPPM);
% Spectrum4RowPlot(Spectrum.PPMTable, Spectrum.FreqDomainData, 4, 200, 'Auto')
% dummy = 1;
end

   

