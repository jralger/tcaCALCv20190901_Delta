function Multiplets = BuildGlcDefaultMultiplets()

GlobalR2 = SetDefaultR2();

R = SetDefaultChemicalShifts();
FreqsPPM = R.GlcEstFreqsPPM;

R = SetDefaultJs();
JAHz = R.GlcEstJAHz;

% R = SetDefaultIsotopeShifts();

Spectrum = BuildDefaultSpectrum();

ID = 'Glc C1 S';
FreqPPM = FreqsPPM(1);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);

Multiplets = [Multiplet, ...  %1: Glc C1 S
              Multiplet, ...  %2: Glc C1 D
              Multiplet, ...  %3: Glc C2 S
              Multiplet, ...  %4: Glc C2 D12
              Multiplet, ...  %5: Glc C2 D23
              Multiplet, ...  %6: Glc C2 Q
              Multiplet, ...  %7: Glc C3 S
              Multiplet, ...  %8: Glc C3 D
              Multiplet, ...  %9: Glc C3 T
              Multiplet, ...  %10: Glc C4 S
              Multiplet, ...  %11: Glc C4 D
              Multiplet, ...  %12: Glc C4 T
              Multiplet, ...  %13: Glc C5 S
              Multiplet, ...  %14: Glc C5 D45
              Multiplet, ...  %15: Glc C5 D56
              Multiplet, ...  %16: Glc C5 Q
              Multiplet, ...  %17: Glc C6 S
              Multiplet];      %18: Glc C6 D
              
n = 2;

ID = 'Glc C1 D';
FreqPPM = FreqsPPM(1);
JHz = JAHz(1,2);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glc C2 S';
FreqPPM = FreqsPPM(2);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glc C2 D12';
FreqPPM = FreqsPPM(2);
JHz = JAHz(1,2);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glc C2 D23';
FreqPPM = FreqsPPM(2);
JHz = JAHz(2,3);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glc C2 Q';
FreqPPM = FreqsPPM(2);
JHz = [JAHz(1,2), JAHz(2,3)];
Multiplet = BuildQuartet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glc C3 S';
FreqPPM = FreqsPPM(3);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glc C3 D';
FreqPPM = FreqsPPM(3);
JHz = JAHz(2,3);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glc C3 T';
FreqPPM = FreqsPPM(3);
JHz = [JAHz(2,3), JAHz(3,4)];
Multiplet = BuildQuartet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glc C4 S';
FreqPPM = FreqsPPM(4);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glc C4 D';
FreqPPM = FreqsPPM(4);
JHz = JAHz(3,4);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glc C4 T';
FreqPPM = FreqsPPM(4);
JHz = [JAHz(3,4), JAHz(4,5)];
Multiplet = BuildQuartet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glc C5 S';
FreqPPM = FreqsPPM(5);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glc C5 D45';
FreqPPM = FreqsPPM(5);
JHz = JAHz(4,5);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glc C5 D56';
FreqPPM = FreqsPPM(5);
JHz = JAHz(5,6);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glc C5 Q';
FreqPPM = FreqsPPM(5);
JHz = [JAHz(5,6), JAHz(4,5)];
Multiplet = BuildQuartet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glc C6 S';
FreqPPM = FreqsPPM(6);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glc C6 D';
FreqPPM = FreqsPPM(6);
JHz = JAHz(5,6);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;




