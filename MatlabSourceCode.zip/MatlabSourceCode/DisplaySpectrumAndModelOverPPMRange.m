function R = DisplaySpectrumAndModelOverPPMRange(Spectrum, ModelSpectrum, ...
                     PPMLow, PPMHigh, TitleTxt, AnnTxt, Diff)

                 
Sppmtable =   Spectrum.PPMTable;               
CS =   Spectrum.FreqDomainData; 
CS = CS(Sppmtable >= PPMLow & Sppmtable <= PPMHigh);
if size(CS, 1) == 0
    return;
end
Sppmtable = Sppmtable(Sppmtable >= PPMLow & Sppmtable <= PPMHigh);
if size(Sppmtable, 1) == 0
    return;
end

Mppmtable =   ModelSpectrum.PPMTable;
MCS =   ModelSpectrum.FreqDomainData;
MCS = MCS(Mppmtable >= PPMLow & Mppmtable <= PPMHigh);
if size(MCS, 1) == 0
    return;
end
    
% R = CS - MCS;
Mppmtable = Mppmtable(Mppmtable >= PPMLow & Mppmtable <= PPMHigh);

CS = real(CS);
MCS = real(MCS);
% R = real(R);

minCS = min(CS);
maxCS = max(CS);

minMCS = min(MCS);
maxMCS = max(MCS);

maxY = max([maxCS, maxMCS]);
maxY = 1.5*maxY;
minY = min([minCS, minMCS]);
                 
Z = CS * 0.0;

% MCS = MCS*1000.0;

scrsz = get(groot,'ScreenSize');
figure('Name', TitleTxt, 'Position',[1 7*scrsz(2)/8 7*scrsz(3)/8 7*scrsz(4)/8]);
% subplot(2,1,1);
plot(Sppmtable, CS, 'r-', Sppmtable, CS, 'ro', Mppmtable, MCS, 'g-', ...
     Sppmtable, Z, 'k:', 'linewidth', 2.0, 'markerSize', 10.0);
%     formatSpec = '%s: C%s PPMRa'nge';
%     txt = sprintf(formatSpec, MoleculeID, SpectralRegions(j));
%     title(txt);
axis([PPMLow, PPMHigh, minY, maxY]);
ax = gca;
ax.XDir = 'reverse';
xlabel('PPM', 'FontSize', 9);
box off;
ax = gca;
ax.YAxis.Visible = 'off';
Txt = [TitleTxt, ' ModelSpectrum'];
if Diff == 0
   legend('MeasuredSpectrum', 'MeasuredSpectrum (data points)', Txt, 'Location', 'northeast');
end
if Diff == 1
   legend('DifferenceMeasuredSpectrum', 'DifferenceMeasuredSpectrum (data points)', Txt, 'Location', 'northeast');
end
dim = [0.05, 0.65, 0.3, 0.3];
ta = annotation('textbox',dim,'String',AnnTxt,'FitBoxToText','on');
    
% subplot(2,1,2);
% plot(ppmtable, R, 'b-', ppmtable, Z, 'k:');
% %     formatSpec = '%s: C%s PPMRange';
% %     txt = sprintf(formatSpec, MoleculeID, SpectralRegions(j));
% %     title(txt);
% axis([PPMLow, PPMHigh, minY, maxY]);
% ax = gca;
% ax.XDir = 'reverse';
% xlabel('PPM', 'FontSize', 9);
% box off;
% ax = gca;
% ax.YAxis.Visible = 'off';
% legend('Residual','Location', 'northeast')

end
