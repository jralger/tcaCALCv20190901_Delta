function MetabolicModel = DefineDefaultMetabolicModel()
MetabolicModel.ExptID = 'Model01';
MetabolicModel.nTurns = 35.0;
MetabolicModel.EOAA = 0.0;
MetabolicModel.ECit = 0.0;
MetabolicModel.EaKG = 0.0;
MetabolicModel.TPI = 1.0;
MetabolicModel.RSM = 0.5;
MetabolicModel.ROF = 1.0;
MetabolicModel.PK = 0.5;
MetabolicModel.PDH = 0.5;
MetabolicModel.YPC = 0.5;
MetabolicModel.GK = 0.0;
MetabolicModel.Ys = 0.5;
MetabolicModel.YGln = 0.0;
MetabolicModel.ExactNaturalAbundance = 1;

MetabolicModel.nTurnsLB = 2;
MetabolicModel.EOAALB = 0.0;
MetabolicModel.ECitLB = 0.0;
MetabolicModel.EaKGLB = 0.0;
MetabolicModel.TPILB = 0.0;
MetabolicModel.RSMLB = 0.0;
MetabolicModel.ROFLB = 0.0;
MetabolicModel.PKLB = 0.0;
MetabolicModel.PDHLB = 0.0;
MetabolicModel.YPCLB = 0.0;
MetabolicModel.GKLB = 0.0;
MetabolicModel.YsLB = 0.0;
MetabolicModel.YGlnLB = 0.0;

MetabolicModel.nTurnsUB = 100.0;
MetabolicModel.EOAAUB = 20.0;
MetabolicModel.ECitUB = 20.0;
MetabolicModel.EaKGUB = 20.0;
MetabolicModel.TPIUB = 1.0;
MetabolicModel.RSMUB = 1.0;
MetabolicModel.ROFUB = 1.0;
MetabolicModel.PKUB = 10.0;
MetabolicModel.PDHUB = 1.0;
MetabolicModel.YPCUB = 10.0;
MetabolicModel.GKUB = 10.0;
MetabolicModel.YsUB = 10.0;
MetabolicModel.YGlnUB = 10.0;




end

