function Spectrum = LoadProcessFID(SpectrumFN)

[pathstr,name,ext] = fileparts(SpectrumFN);
procparFN = [pathstr, filesep, 'procpar'];
RA = ReadAgilentprocpar(procparFN);

% SpectrumFN = 'C:\Users\Jeffry R Alger\Desktop\IsotopomerAnalysisGuide\fid';
% DeltaJFN = 'C:\Users\Jeffry R Alger\Desktop\Dallas_UTSW\C13ExampleData\C13ChemShiftsNov2016\AlgerShiftsAndJs20161125LacOnly.csv';
% SpectrumFN = 'C:\Users\Jeffry R Alger\Desktop\IsotopomerAnalysisGuide\wm2fid';
% SpectrumFN = 'C:\Users\Jeffry R Alger\Desktop\IsotopomerAnalysisGuide\thalamusfid';
% SpectrumFN = 'C:\Users\Jeffry R Alger\Desktop\IsotopomerAnalysisGuide\WMfid';
% SpectrumFN = 'C:\Users\Jeffry R Alger\Desktop\IsotopomerAnalysisGuide\cblctxfid';

% MoleculeID = 'Lac';
% CalcPPMRangeLow = -0.5;
% CalcPPMRangeHigh = 0.5;
% SignalShape = 'Lorentz';
% SignalShapeParmSearchLow = 0.0;
% SignalShapeParmSearchHigh = 20.0;
% SignalShapeParmSearchInc = 0.01;
ZOPDS = 0.0;
ZOPDE = 359.0;
ZOPDI = 1.0;
FOPDS = 90.0;
FOPDE = 270.0;
FOPDI = 1.0;
% FirstOrderPhaseDegStart = 0.0;
% FirstOrderPhaseDegEnd = 359.0;
% FirstOrderPhaseDegInc = 2.0;
% RatioThreshold = 0.1;
% TitleTxt = 'Null';

% R = strfind(SpectrumFN, 'bestfid');
% if R ~= 0
% %     at = 1.4999768; 
%     BestZOPhaseDeg = 161.0; 
%     BestFOPhaseDegDist = 125.0; 
% end
% 
% R = strfind(SpectrumFN, 'cblctxfid');
% if R ~= 0
% %     at = 2.0000128; 
%     BestZOPhaseDeg = 180.0;
%     BestFOPhaseDegDist = 180.0;
% end
% 
% R = strfind(SpectrumFN, 'onefid');
% if R ~= 0
% %     at = 1.4999768; 
%     BestZOPhaseDeg = 20.0;
%     BestFOPhaseDegDist = 197.0;
% end
% 
% R = strfind(SpectrumFN, 'occctxfid');
% if R ~= 0
% %     at = 1.4999768; 
%     BestZOPhaseDeg = 161.0;
%     BestFOPhaseDegDist = 125.0;
% end
% 
% R = strfind(SpectrumFN, 'parctxfid');
% if R ~= 0
% %     at = 1.4999768; 
%     BestZOPhaseDeg = 161.0;
%     BestFOPhaseDegDist = 125.0;
% end
% 
% R = strfind(SpectrumFN, 'thalamusfid');
% if R ~= 0
% %     at = 2.0000128; 
%     BestZOPhaseDeg = 20.0;
%     BestFOPhaseDegDist = 197.0;
% end
% 
% R = strfind(SpectrumFN, 'wm2fid');
% if R ~= 0
% %     at = 2.0000128; 
%     BestZOPhaseDeg = 20.0;
%     BestFOPhaseDegDist = 197.0;
% end
% 
% R = strfind(SpectrumFN, 'WMfid');
% if R ~= 0
% %     at = 2.0000128; 
%     BestZOPhaseDeg = 90.0;
%     BestFOPhaseDegDist = 180.0;
% end

% at = 1.4999768;  %fid
% at = 2.0000128;  %wm2fid
at = str2num(RA.AT);


% sf = 150.849746347;
sf = str2num(RA.SF);
CenterPPM = 100.0;
% GlobalR2 = 3.0;
% DefaultMolConc = 1.0;
ZF = 1;
% PPMOffset = 0.830 + 0.0018;
PPMOffset = 0.0;

RFID = ReadAgilentFID(SpectrumFN, at, sf, CenterPPM, PPMOffset);

Spectrum = Recon1D(RFID, ZF, 0);
CS = Spectrum.FreqDomainData;
ppmtable = Spectrum.PPMTable;
SampleTimesSec = Spectrum.SampleTimesSec;
CenterPPM = Spectrum.CenterPPM;

PhaseSpreadDirection = 0;
[BestZOPhaseDeg, BestFOPhaseDegDist] = EstimateZeroAndFirstOrderPhaseDeg(CS, ...
             ZOPDS, ZOPDE, ZOPDI, FOPDS, FOPDE, FOPDI, PhaseSpreadDirection);
         
% BestZOPhaseDeg = 161.0; %occ par
% BestFOPhaseDegDist = 125.0; %occ par
% BestZOPhaseDeg = 20.0;  wm2 thal
% BestFOPhaseDegDist = 197.0; wm2 thal
% BestZOPhaseDeg = 90.0; %WM
% BestFOPhaseDegDist = 180.0; %WM
% BestZOPhaseDeg = 180.0; 
% BestFOPhaseDegDist = 180.0;
CS = FirstOrderPhaseCorrect(CS, BestFOPhaseDegDist, PhaseSpreadDirection);
CS = ZeroOrderPhaseCorrect(CS, BestZOPhaseDeg);
ReCS = real(CS);
Spectrum.FreqDomainData = CS;

end

