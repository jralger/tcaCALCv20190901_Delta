function V = EstimateOneCarbonNaturalAbundance()
[o, x] = DefineOneCarbonLabelIndices();
V = zeros(1,2);
V(1, o) = 1.0;
end

