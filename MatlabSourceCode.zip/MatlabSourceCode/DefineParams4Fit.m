function [X0, XS, XLB, XSLB, XUB, XSUB, XIDs] = DefineParams4Fit(MetabolicModel)

% FluxLB = 0.00;
% FluxUB = 10.0;
% ConcLB = 0.00;
% ConcUB = 1.00;
% Zero = 0.0;
% One = 1.00;
% BigUB = 6.023e23;
XIDs = MetabolicModel.XIDs;

nX = size(XIDs, 2);
X0 = zeros(1, nX);
XLB = zeros(1, nX);
XUB = zeros(1, nX);

PDH = MetabolicModel.PDH;
PK = MetabolicModel.PK;
YPC = MetabolicModel.YPC;
Ys = MetabolicModel.Ys;

for i = 1:nX
    ID = XIDs(i);
    ID = char(ID);
    if strcmp(ID, 'GK')
        X0(1,i) = MetabolicModel.GK;
        XLB(1,i) = MetabolicModel.GKLB;
        XUB(1,i) = MetabolicModel.GKUB;
    end
    if strcmp(ID, 'PDH')
        X0(1,i) = MetabolicModel.PDH;
%         XLB(1,i) = FluxLB;
%         XUB(1,i) = One;
         XLB(1,i) = MetabolicModel.PDHLB;
         XUB(1,i) = MetabolicModel.PDHUB;
    end
    if strcmp(ID, 'PK')
        X0(1,i) = MetabolicModel.PK;
        XLB(1,i) = MetabolicModel.PKLB;
        XUB(1,i) = MetabolicModel.PKUB;
    end
    if strcmp(ID, 'YPC')
        X0(1,i) = MetabolicModel.YPC;
        XLB(1,i) = MetabolicModel.YPCLB;
        XUB(1,i) = MetabolicModel.YPCUB;
    end
    if strcmp(ID, 'Ys')
        X0(1,i) = MetabolicModel.Ys;
        XLB(1,i) = MetabolicModel.YsLB;
        XUB(1,i) = MetabolicModel.YsUB;
    end
    if strcmp(ID, 'RSM')
        X0(1,i) = MetabolicModel.RSM;
        XLB(1,i) = MetabolicModel.RSMLB;
        XUB(1,i) = MetabolicModel.RSMUB;
    end
    if strcmp(ID, 'ROF')
        X0(1,i) = MetabolicModel.ROF;
        XLB(1,i) = MetabolicModel.ROFLB;
        XUB(1,i) = MetabolicModel.ROFUB;
    end
    if strcmp(ID, 'TPI')
        X0(1,i) = MetabolicModel.TPI;
        XLB(1,i) = MetabolicModel.TPILB;
        XUB(1,i) = MetabolicModel.TPIUB;
    end
    if strcmp(ID, 'EaKG')
        X0(1,i) = MetabolicModel.EaKG;
        XLB(1,i) = MetabolicModel.EaKGLB;
        XUB(1,i) = MetabolicModel.EaKGUB;
    end
    if strcmp(ID, 'ECit')
        X0(1,i) = MetabolicModel.ECit;
        XLB(1,i) = MetabolicModel.ECitLB;
        XUB(1,i) = BMetabolicModel.ECitUB;
    end
    if strcmp(ID, 'EOAA')
        X0(1,i) = MetabolicModel.EOAA;
        XLB(1,i) = MetabolicModel.EOAALB;
        XUB(1,i) = MetabolicModel.EOAAUB;
    end
    A = strfind(ID, 'Lac');
    nA = size(A);
    if nA ~= 0
        B = MetabolicModel.Lac;
        LB = MetabolicModel.LacLB;
        UB = MetabolicModel.LacUB;
        nB = size(B, 1);
        T = strsplit(ID, ' ');
        IDs = BuildIsotopomerIDs(nB);
        X0(1,i) = B(strcmp(IDs, T(2)));
        XLB(1,i) = LB(strcmp(IDs, T(2)));
        XUB(1,i) = UB(strcmp(IDs, T(2)));
    end
    A = strfind(ID, 'FA');
    nA = size(A);
    if nA ~= 0
        B = MetabolicModel.FA;
        LB = MetabolicModel.FALB;
        UB = MetabolicModel.FAUB;
        nB = size(B, 1);
        T = strsplit(ID, ' ');
        IDs = BuildIsotopomerIDs(nB);
        X0(1,i) = B(strcmp(IDs, T(2)));
        XLB(1,i) = LB(strcmp(IDs, T(2)));
        XUB(1,i) = UB(strcmp(IDs, T(2)));
    end
    A = strfind(ID, 'SuccYs');
    nA = size(A);
    if nA ~= 0
        B = MetabolicModel.SuccYs;
        LB = MetabolicModel.SuccYsLB;
        UB = MetabolicModel.SuccYsUB;
        nB = size(B, 1);
        T = strsplit(ID, ' ');
        IDs = BuildIsotopomerIDs(nB);
        X0(1,i) = B(strcmp(IDs, T(2)));
        XLB(1,i) = LB(strcmp(IDs, T(2)));
        XUB(1,i) = UB(strcmp(IDs, T(2)));
    end
    A = strfind(ID, 'Glyc');
    nA = size(A);
    if nA ~= 0
        B = MetabolicModel.Glyc;
        LB = MetabolicModel.GlycLB;
        UB = MetabolicModel.GlycUB;
        nB = size(B, 1);
        T = strsplit(ID, ' ');
        IDs = BuildIsotopomerIDs(nB);
        X0(1,i) = B(strcmp(IDs, T(2)));
        XLB(1,i) = LB(strcmp(IDs, T(2)));
        XUB(1,i) = UB(strcmp(IDs, T(2)));
    end
    A = strfind(ID, 'CO2');
    nA = size(A);
    if nA ~= 0
        B = MetabolicModel.CO2;
        LB = MetabolicModel.CO2LB;
        UB = MetabolicModel.CO2UB;
        nB = size(B, 1);
        T = strsplit(ID, ' ');
        IDs = BuildIsotopomerIDs(nB);
        X0(1,i) = B(strcmp(IDs, T(2)));
        XLB(1,i) = LB(strcmp(IDs, T(2)));
        XUB(1,i) = UB(strcmp(IDs, T(2)));
    end
end

XS = X0;
XSLB = XLB;
XSUB = XUB;

if MetabolicModel.UseXform
    Q = sum(X0(strcmp(XIDs, 'PDH')));
    if Q
        PDH = X0(strcmp(XIDs, 'PDH'));
        x = PDH;
        X0(strcmp(XIDs, 'PDH')) = x;
        XLB(strcmp(XIDs, 'PDH')) = 0.0;
        XUB(strcmp(XIDs, 'PDH')) = 1.0 - 1e-6;
        XIDs(strcmp(XIDs, 'PDH')) = {'x'};
    end

    Q = sum(X0(strcmp(XIDs, 'YPC')));
    if Q
        YPC = X0(strcmp(XIDs, 'YPC'));
        y = YPC/(1.0 + YPC);
        X0(strcmp(XIDs, 'YPC')) = y;
        XLB(strcmp(XIDs, 'YPC')) = 0.0;
        XUB(strcmp(XIDs, 'YPC')) = 1.0 - 1e-6;
        XIDs(strcmp(XIDs, 'YPC')) = {'y'};
    end


    Q = sum(X0(strcmp(XIDs, 'Ys')));
    if Q
        Ys = X0(strcmp(XIDs, 'Ys'));
        w = Ys/(1.0+Ys);
        X0(strcmp(XIDs, 'Ys')) = w;
        XLB(strcmp(XIDs, 'Ys')) = 0.0;
        XUB(strcmp(XIDs, 'Ys')) = 1.0 - 1e-6;
        XIDs(strcmp(XIDs, 'Ys')) = {'w'};
    end

    Q = sum(X0(strcmp(XIDs, 'PK')));
    if Q
        PK = X0(strcmp(XIDs, 'PK'));
        z = PK/(PDH + YPC);
        if PDH + YPC == 0.0
           z = 0.0;
        end
        X0(strcmp(XIDs, 'PK')) = z;
        XLB(strcmp(XIDs, 'PK')) = 0.0;
        XUB(strcmp(XIDs, 'PK')) = 1.0;
        XIDs(strcmp(XIDs, 'PK')) = {'z'};
    end
end   






