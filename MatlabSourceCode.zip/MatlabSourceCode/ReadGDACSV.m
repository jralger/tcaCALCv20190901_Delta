function GDA = ReadGDACSV(FN)

LegalMols = {'Glu', 'Ala', 'bHB', 'MAG', 'Asp', 'Glc'};
nLegalMols = size(LegalMols, 2);
N = nLegalMols + 1;
for i = 1:nLegalMols
    iMol = char(LegalMols(i));
    for j = 1:nLegalMols
        jMol = char(LegalMols(j));
        Mol = [iMol, ':', jMol];
        LegalMols{N} = Mol;
        N = N + 1;
    end
end

fileID = fopen(FN, 'r');
L = 'A';
N = 1;
while ischar(L)
      L = fgetl(fileID);
%       disp(L);
      if ischar(L)
          LA(N) = {L};
          N = N + 1;
      end
end
N = N - 1;
fclose(fileID);

M = 1;
clear GD
clear GDA
for i = 1:N
    L = char(LA(i));
    A = split(L, ',');
    Q = strcmp(A(3), LegalMols);
    if any(Q)
%         disp(A);
        GD.FN = FN;
        GD.StudyID = char(A(1));
        GD.Type = char(A(2));
        GD.MolID = char(A(3));
        GD.MeasID = char(A(4));
        GD.Value = str2double(char(A(5)));
        GDA(1, M) = GD;
        M = M + 1;
    end
end
nGDA = size(GDA, 2);
clear GD
clear TGDA

%dump illegal types
LegalTypes = {'Isotopomer', ...
              '13C NMR Multiplet', ...
              'MS Isotopologue', ... 
              'Fractional Enrichment', ...
              'Fractional Enrichment Ratio'};

N = 1;
for i = 1:nGDA
    GD = GDA(1, i);
    Q = strcmp(LegalTypes, GD.Type);
    if any(Q)
        TGDA(1, N) = GD;
        N = N + 1;
    end
end
GDA = TGDA;
nGDA = size(GDA,2);
clear GD
clear TGDA

%dump illegal values
N = 1;
for i = 1:nGDA
    GD = GDA(1, i);
    V = GD.Value;
    if V >= 0.0
        if strcmp(GD.Type, 'Fractional Enrichment Ratio')
            TGDA(1, N) = GD;
            N = N + 1;
        else
            if V <= 1.0
                TGDA(1, N) = GD;
                N = N + 1;
            end
        end
    end
end
GDA = TGDA;
nGDA = size(GDA,2);
clear GD
clear TGDA

%dump illegal isotopomers
N = 1;
for i = 1:nGDA
    GD = GDA(1, i);
    if strcmp(GD.Type, 'Isotopomer')
        nIsotopomers = GetIsotopomerNumbers(GD.MolID);
        XOs = BuildIsotopomerIDs(nIsotopomers);
        if any(strcmp(GD.MeasID, XOs))
            TGDA(1, N) = GD;
            N = N + 1;
        end
    else
        TGDA(1, N) = GD;
        N = N + 1;
    end
end
GDA = TGDA;
nGDA = size(GDA,2);
clear GD;
clear TGDA;

%dump illegal multiplets
LegalMultipletIDs = DefineAlaMultipletIDs();
TIDs = DefineAspMultipletIDs();
LegalMultipletIDs = AppendCellArrays(LegalMultipletIDs, TIDs);
TIDs = DefineGluMultipletIDs();
LegalMultipletIDs = AppendCellArrays(LegalMultipletIDs, TIDs);
TIDs = DefineGlcMultipletIDs();
LegalMultipletIDs = AppendCellArrays(LegalMultipletIDs, TIDs);
TIDs = DefineMAGMultipletIDs();
LegalMultipletIDs = AppendCellArrays(LegalMultipletIDs, TIDs);
TIDs = DefinebHBMultipletIDs();
LegalMultipletIDs = AppendCellArrays(LegalMultipletIDs, TIDs);

N = 1;
for i = 1:nGDA
    GD = GDA(1, i);
    if strcmp(GD.Type, '13C NMR Multiplet')
        V = [GD.MolID, ' ', GD.MeasID];
        if any(strcmp(LegalMultipletIDs, V))
            TGDA(1, N) = GD;
            N = N + 1;
        end
    else
        TGDA(1, N) = GD;
        N = N + 1;
    end
end
GDA = TGDA;
nGDA = size(GDA,2);
clear GD;
clear TGDA;

%dump illegal isotopologues
LegalIsotopologues = DefineLegalIsotologues();
N = 1;
for i = 1:nGDA
    GD = GDA(1, i);
    if strcmp(GD.Type, 'MS Isotopologue')
        V = [GD.MolID, ' ', GD.MeasID];
        if any(strcmp(LegalIsotopologues, V))
            TGDA(1, N) = GD;
            N = N + 1;
        end
    else
        TGDA(1, N) = GD;
        N = N + 1;
    end
end
GDA = TGDA;
nGDA = size(GDA,2);
clear GD
clear TGDA

%dump illegal FEs
LegalFEs = DefineLegalFractionalEnrichments();
N = 1;
for i = 1:nGDA
    GD = GDA(1, i);
    if strcmp(GD.Type, 'Fractional Enrichment')
        V = [GD.MolID, ' ', GD.MeasID];
        if any(strcmp(LegalFEs, V))
            TGDA(1, N) = GD;
            N = N + 1;
        end
    else
        TGDA(1, N) = GD;
        N = N + 1;
    end
end
GDA = TGDA;
nGDA = size(GDA,2);
clear GD;
clear TGDA;

%dump illegal Fractional Enrichment Ratos (FERs)
LegalFERs = DefineLegalFractionalEnrichmentRatios();
N = 1;
for i = 1:nGDA
    GD = GDA(1, i);
    if strcmp(GD.Type, 'Fractional Enrichment Ratio')
        V = [GD.MolID, ' ', GD.MeasID];
        if any(strcmp(LegalFERs, V))
            TGDA(1, N) = GD;
            N = N + 1;
        end
    else
        TGDA(1, N) = GD;
        N = N + 1;
    end
end
GDA = TGDA;
% nGDA = size(GDA,2);
clear GD
clear TGDA

end

function C = AppendCellArrays(A,B)
nA = size(A,2);
nB = size(B,2);
N = 1;
for i = 1:nA
    C(1,N) = A(1,i);
    N = N + 1;
end
for i = 1:nB
    C(1,N) = B(1,i);
    N = N + 1;
end
end

function nIsotopomers = GetIsotopomerNumbers(MolID)
LegalMols = {'Glu', 'Ala', 'bHB', 'MAG', 'Asp', 'Glc'};
if strcmp(MolID, 'Glu')
    nIsotopomers = 32;
end
if strcmp(MolID, 'Ala')
    nIsotopomers = 8;
end
if strcmp(MolID, 'bHB')
    nIsotopomers = 16;
end
if strcmp(MolID, 'MAG')
    nIsotopomers = 64;
end
if strcmp(MolID, 'Asp')
    nIsotopomers = 16;
end
if strcmp(MolID, 'Glc')
    nIsotopomers = 64;
end
end

function LegalIsotopologues = DefineLegalIsotologues()
LegalMols = {'Glu', 'Ala', 'bHB', 'MAG', 'Asp', 'Glc'};
nCA =        [5,3,4,6,4,6];
nMols = size(LegalMols, 2);
N = 1;
for j = 1:nMols
    Mol = char(LegalMols(1,j));
    nC = nCA(1,j);
    for i = 0:nC
        LegalIsotopologues(1, N) = {[Mol, ' m+', num2str(i)]};
        N = N + 1;
    end
end
end

function LegalFEs = DefineLegalFractionalEnrichments()
LegalMols = {'Glu', 'Ala', 'bHB', 'MAG', 'Asp', 'Glc'};
nCA =        [5,3,4,6,4,6];
nMols = size(LegalMols, 2);
N = 1;
for j = 1:nMols
    Mol = char(LegalMols(1,j));
    nC = nCA(1,j);
    for i = 1:nC
        LegalFEs(1, N) = {[Mol, ' C', num2str(i)]};
        N = N + 1;
    end
end
end


function LegalFERs = DefineLegalFractionalEnrichmentRatios()
LegalMols = {'Glu', 'Ala', 'bHB', 'MAG', 'Asp', 'Glc'};
nCA =        [5,3,4,6,4,6];
nMols = size(LegalMols, 2);
N = 1;

for i = 1:nMols
    iMol = char(LegalMols(1,i));
    niC = nCA(1, i);
    for j = 1:nMols
        jMol = char(LegalMols(1,j));
        njC = nCA(1, j);
        ijMol = [iMol, ':', jMol];
        for m = 1:niC
            for n = 1:njC
                Mol = [ijMol, ' ', 'C', num2str(m), ':C', num2str(n)];
                LegalFERs(1, N) = {Mol};
                N = N + 1;
            end
        end
    end
end
nFERs = size(LegalFERs,2);

N = 1;
for i = 1:nFERs
    LFER = char(LegalFERs(1, i));
    T = split(LFER, ' ');
    Mols = T(1,1);
    Cs = T(2,1);
    Mols = split(Mols, ':');
    Cs = split(Cs, ':');
    if ~strcmp(Mols(1,1), Mols(2,1))
        TLFERs(1, N) = {LFER};
        N = N + 1;
    end
    if strcmp(Mols(1,1), Mols(2,1))
        if ~strcmp(Cs(1,1), Cs(2,1))
            TLFERs(1, N) = {LFER};
            N = N + 1;
        end
    end
end

LegalFERS = TLFERs;
clear TLFERs;

end
