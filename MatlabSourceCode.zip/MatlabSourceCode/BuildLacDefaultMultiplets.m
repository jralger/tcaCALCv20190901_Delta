function Multiplets = BuildLacDefaultMultiplets()

GlobalR2 = SetDefaultR2();

R = SetDefaultChemicalShifts();
FreqsPPM = R.LacEstFreqsPPM;

R = SetDefaultJs();
JAHz = R.LacEstJAHz;

% R = SetDefaultIsotopeShifts();

Spectrum = BuildDefaultSpectrum();

ID = 'Lac C1 S';
FreqPPM = FreqsPPM(1);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);

Multiplets = [Multiplet, ...  %1: Lac C1 S
              Multiplet, ...  %2: Lac C1 D
              Multiplet, ...  %3: Lac C2 S
              Multiplet, ...  %4: Lac C2 D12
              Multiplet, ...  %5: Lac C2 D23
              Multiplet, ...  %6: Lac C2 Q
              Multiplet, ...  %7: Lac C3 S
              Multiplet];     %8: Lac C3 D
n = 2;

ID = 'Lac C1 D';
FreqPPM = FreqsPPM(1);
JHz = JAHz(1,2);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Lac C2 S';
FreqPPM = FreqsPPM(2);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Lac C2 D12';
FreqPPM = FreqsPPM(2);
JHz = JAHz(1,2);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Lac C2 D23';
FreqPPM = FreqsPPM(2);
JHz = JAHz(2,3);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Lac C2 Q';
FreqPPM = FreqsPPM(2);
JHz = [JAHz(1,2), JAHz(2,3)];
Multiplet = BuildQuartet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Lac C3 S';
FreqPPM = FreqsPPM(3);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Lac C3 D';
FreqPPM = FreqsPPM(3);
JHz = JAHz(2,3);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;


end

