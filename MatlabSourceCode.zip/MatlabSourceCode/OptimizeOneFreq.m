function BestMolecule = OptimizeOneFreq(Molecule, Spectrum, CarbonNumber, ...
                             DeltaSearchPPMLow, DeltaSearchPPMHigh, ...
                             DeltaSearchPPMInc, CalcPPMLow, CalcPPMHigh)

TitleTxt = 'Null';
k = strfind(CarbonNumber, 'C');
i = CarbonNumber(k+1);
i = str2num(i);
FreqsPPM = Molecule.FreqsPPM;
TestFreqPPM = FreqsPPM(i);
TestFreqPPMLow = TestFreqPPM + DeltaSearchPPMLow;
TestFreqPPMHigh = TestFreqPPM + DeltaSearchPPMHigh;

JAPPM = Molecule.JAPPM;
LabelPattern = Molecule.LabelPattern;
Signals = Molecule.Signals;
Signal = Signals(1);
ShapeParams = Signal.ShapeParams;
GlobalR2 = ShapeParams(1);
sf = str2num(Molecule.ScannerFreqMHz);
CenterPPM = str2num(Molecule.CenterPPM);
SampleTimesSec = Molecule.SampleTimesSec;
CenterPPM = str2num(Molecule.CenterPPM);
MolConc = Molecule.Conc;

BestTestFreqsPPM = FreqsPPM;
BestTestFreqsPPM(1, i) = TestFreqPPMLow;
% MolConc = 2.0e5;
BestMolecule = BuildIsotopMolecule(LabelPattern, BestTestFreqsPPM, ...
                      JAPPM, MolConc, GlobalR2, sf, SampleTimesSec, CenterPPM);
BestR = GetResidualOverPPMRange(BestMolecule, Spectrum, CalcPPMLow, CalcPPMHigh);
% ModelSpectrum = BestMolecule.ConcWtdSpectrum;
% DisplaySpectrumAndModelOverPPMRange(Spectrum, ModelSpectrum, ...
%                      CalcPPMLow, CalcPPMHigh, TitleTxt);
TestFreqsPPM = FreqsPPM;
for TestFreqPPM = TestFreqPPMLow:DeltaSearchPPMInc:TestFreqPPMHigh
    TestFreqsPPM(1, i) =  TestFreqPPM;
    TestMolecule = BuildIsotopMolecule(LabelPattern, TestFreqsPPM, ...
                      JAPPM, MolConc, GlobalR2, sf, SampleTimesSec, CenterPPM);
    R = GetResidualOverPPMRange(TestMolecule, Spectrum, CalcPPMLow, CalcPPMHigh);
    if R < BestR
        BestR = R;
        BestFreqsPPM = TestFreqsPPM;
        BestMolecule = TestMolecule;
%         ModelSpectrum = BestMolecule.ConcWtdSpectrum;
%         DisplaySpectrumAndModelOverPPMRange(Spectrum, ModelSpectrum, ...
%                          CalcPPMLow, CalcPPMHigh, TitleTxt);
    end
end
% BestMolecule = BuildIsotopMolecule(LabelPattern, BestFreqsPPM, ...
%                       JAPPM, MolConc, GlobalR2, sf, SampleTimesSec, CenterPPM);
% ModelSpectrum = BestMolecule.ConcWtdSpectrum;
% DisplaySpectrumAndModelOverPPMRange(Spectrum, ModelSpectrum, CalcPPMLow, ...
%        CalcPPMHigh, TitleTxt);
end

