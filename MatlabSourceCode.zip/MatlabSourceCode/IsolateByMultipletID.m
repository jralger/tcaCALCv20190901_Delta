function RRA = IsolateByMultipletID(RA, MultipletID )
RRA = RA(1);
RRA.MultipletID = 'NotFound';
nRA = size(RA, 2);
n = 1;
for i = 1:nRA
    R = RA(i);
%     T = R.MultipletID;
    if strcmp(MultipletID, R.MultipletID)
        RRA(n) = R;
        n = n + 1;
    end
end

end

