function V = BuildFourCarbonNaturalAbundance(A)
[oooo, xooo, oxoo, xxoo, ooxo, xoxo, oxxo, xxxo, ...
 ooox, xoox, oxox, xxox, ooxx, xoxx, oxxx, xxxx] = ... 
                                         DefineFourCarbonLabelIndices();

A1 = A;
A2 = A*A;
A3 = A*A*A;
A4 = A*A*A*A;

V = zeros(1,16);

V(1, xooo) = A1;
V(1, oxoo) = A1;
V(1, ooxo) = A1;
V(1, ooox) = A1;

V(1, xxoo) = A2;
V(1, xoxo) = A2;
V(1, oxxo) = A2;
V(1, xoox) = A2;
V(1, oxox) = A2;
V(1, ooxx) = A2;

V(1, xxxo) = A3;
V(1, xxox) = A3;
V(1, xoxx) = A3;
V(1, oxxx) = A3;

V(1, xxxx) = A4;

T = sum(V(1, :));
V(1, oooo) = 1.0 - T;


end

