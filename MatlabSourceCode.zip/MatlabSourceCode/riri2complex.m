function R = riri2complex(A)
S = size(A, 1);
RS = S/2;
C = 0.0 + 0.0j;
R = repmat(C, RS, 1);
n = 1;
for i = 1:2:S-1
    R(n) = complex(A(i),A(i+1));
    n = n + 1;
end 
end
    
    
