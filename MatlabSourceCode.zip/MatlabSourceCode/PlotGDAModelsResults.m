function PlotGDAModelsResults(MMs, WDN)

% save copy of MMs for faster debugging
% removing multiplets reduces the size of the MM array, reduces size of
% stored file, makes write time pratical
% FN = 'C:\Users\Jeffry R Alger\Desktop\GetPlotWorking\MMs.mat';
% nMMs = size(MMs, 2);
% for i = 1:nMMs
%     MM = MMs(1,i);
%     MM = rmfield(MM, 'AlaMultiplets');
%     MM = rmfield(MM, 'AspMultiplets');
%     MM = rmfield(MM, 'GlcMultiplets');
%     MM = rmfield(MM, 'GluMultiplets');
%     MM = rmfield(MM, 'MAGMultiplets');
%     MM = rmfield(MM, 'bHBMultiplets');
%     NMMs(1,i) = MM;
% end
% MMs = NMMs;
% FN = 'C:\Users\Jeffry R Alger\Desktop\GetPlotWorking\MMs.mat';
% save(FN, 'MMs');

% load MMs from saved file in debugging mode
% load(FN, 'MMs');

FS = 12;
AFS = 10;

MMs = AddLnResid(MMs);

LnResids = GetValuesFromMetabolicModels(MMs, 'LnResid');
nMMs = size(MMs, 2);
[LnResids, idx] = sort(LnResids);
MMs(1, :) = MMs(1, idx);

% AICs = GetValuesFromMetabolicModels(MMs, 'AICc');
% nMMs = size(MMs, 2);
% [AICs, idx] = sort(AICs);
% MMs(1, :) = MMs(1, idx);

PT = GetStudyID(MMs);
SID = GetSID(MMs);

RPA = {'AICc', 'LnResid', 'ADp', 'PDH', 'YPC', ...
       'PK', 'Ys'};
nRPA = size(RPA, 2);

for i = nMMs:-1:1
    MM = MMs(1,i);
    ExptID = MM.ExptID;
    xl = 100 + (i*20);
    yl = 100 + (i*20);
    figure('Position', [xl, yl, 768, 768], 'Color', 'w');
   
    PNGFN = [ExptID, '.png'];
    subplot(2,1,1);
    imshow(PNGFN);
    T = [PT, ': ', ExptID];
    title(T, 'fontsize', FS);
    
    GDA = MM.GDA;
    BGDA = MM.BestGDA;
    nGDA = size(GDA, 2);
    for j = 1:nGDA
        GD = GDA(1,j);
        BGD = BGDA(1,j);
        MV(1,j) = GD.Value;
        BMV(1,j) = BGD.Value;
        IDA(1, j) = {[GD.MolID, ' ', GD.MeasID]};
    end
    E = MV - BMV;
    
    Y = zeros(nGDA, 3);
    Y(:, 1) = MV(1, :);
    Y(:, 2) = BMV(1, :);
    Y(:, 3) = 10.0*E(1, :);
    X = categorical(IDA);
    axb = subplot(2,1,2);
    b = bar(axb, X, Y);
    b(1).FaceColor = 'red';
    b(2).FaceColor = 'green';
    b(3).FaceColor = 'blue';
    b(1).EdgeColor = 'red';
    b(2).EdgeColor = 'green';
    b(3).EdgeColor = 'blue';
    axb.XAxisLocation = 'bottom';
    axb.XTickLabelRotation = -45;
    axb.XLabel.String = 'Measurement ID';
    axb.YLabel.String = 'Value';
    axb.XLabel.FontSize = FS;
    axb.XTickLabelMode =  'manual';
    legend('Measured','BestFit','Error x 10', ...
           'Location', 'south', 'Orientation','horizontal')
    
    TB2 = annotation('textbox');
    TB2.FontSize = AFS;
    TB2.Position = [0.05, 0.02, 1.0, 0.5];
    TB2.LineStyle = 'none';
    V = sprintf('%0.3f',mean(E));
    T = ['MeanResid: ', V];
    S(1) = {T};
    V = sprintf('%0.3f',std(E));
    T = ['StdResid: ', V];
    S(2) = {T};
    TB2.String = S;
    clear S;

    TB = annotation('textbox');
    TB.FontSize = AFS;
    TB.Position = [0.05, 0.4, 1.0, 0.5];
    TB.LineStyle = 'none';
    
    XIDs = MM.XIDs;
    STD = MM.XSTDCovar;
    N = 1;
    for j = 1:nRPA
        RP = char(RPA(1,j));
        V = MM.(RP);
        V = sprintf('%0.3f',V);
        U = '';
        if any(strcmp(XIDs, RP))
            U = STD(strcmp(XIDs, RP));
            U = sprintf('%0.3f',U);
            U = [' +/- ', U];
        end
        if strcmp(RP, 'LnResid')
            RP = 'LnSumSqResid';
        end
        if strcmp(RP, 'YPC')
            RP = 'Ypc';
        end
        T = [RP, ': ', V, U];
        S{N} = T;
        N = N + 1;
    end
   
    FSubs = GetFittedSubstrates(MM);
    nFSubs = size(FSubs, 2);
    nFSubs1 = size(FSubs, 1);   
    if nFSubs1 > 0
        for j = 1:nFSubs
            ID = FSubs(1, j);
            if any(strcmp(XIDs, ID))
                XID = char(XIDs(strcmp(XIDs, ID)));
                V = GetIsotopomerFromStruct(MM, XID);
                V = sprintf('%0.3f',V);
                U = STD(strcmp(XIDs, ID));
                U = sprintf('%0.3f',U);
                T = [XID, ': ', V, ' +/- ', U];
                S{N} = T;
                N = N + 1;
            end
        end
    end
   TB.String = S;
   clear S;
   A = num2str(i);
   if i <= 9
      A = ['0', A];
   end
   A = ['_AICc_', A];
   FN = [WDN, SID, '_', A, '_', ExptID, '_Results.png'];
%    FNA{i} = FN;
   saveas(gcf, FN);
end
    
% figure('Position', [0, 0, 8192, 8192], 'Color', 'w');
% SubplotCols = 4;
% SubplotRows = 4;
% for i = 1:nMMs
%     FN = char(FNA(i));
%     subplot(SubplotRows, SubplotCols, i);
%     imshow(FN);
% end
% FN = [WDN, SID, '_AllModels_Results.png'];
% saveas(gcf, FN);


figure('Position', [200, 0, 1024, 1024], 'Color', 'w');
MS = 8;

SubplotCols = 1;
FittedSubstrates = GetFittedSubstrates(MMs);
nFS = size(FittedSubstrates, 2);
nFS1 = size(FittedSubstrates, 1);
SubplotRows = 3 + 4 + nFS;
if nFS1 == 0
    SubplotRows = 3 + 4;
end


for i = 1:nMMs
    MM = MMs(1, i);
    XIDs = MM.XIDs;
    T = '';
    Models(1, i) = {[T , MM.ExptID,]};
end

% Defines X numerical coordinates for plotting
clear X;
for i =1:nMMs
    X(i) = i;
end

PIDs = {'AICc', 'BestEV', 'ADp'};
YLA =  {'AICc', 'Ln(Resid)', 'ADp'};
CA =   {'g',    'b',         'm'};
nPIDs = size(PIDs, 2);

PN = 1;

for i = 1:nPIDs
    PID = char(PIDs(1,i));
    YL = char(YLA(1,i));
    C = char(CA(1,i));
    ax = subplot(SubplotRows,SubplotCols,PN);
    Y = GetValuesFromMetabolicModels(MMs, PID);
    if strcmp(PID, 'BestEV')
        Y = log(Y);
    end
    S = [C, 'o'];
    plot(ax, X, Y, S,  'MarkerFaceColor', C, 'MarkerSize', MS);
    ax = SetAxProps(ax, X, FS);
    ax.YLabel.String = YL;
    if i == 1
        title(PT);
    end
    axs(1,1) = ax;
    PN = PN + SubplotCols;
end

M = 4;
IDs = {'PDH', 'YPC', 'PK', 'Ys'};
CA =  {'g',   'b',   'r',  'm'};
nIDs = size(IDs, 2);
for i = 1:nIDs
    ID = char(IDs(1,i));
    C = char(CA(1,i));
    [XP, YP, EP, N, XPZ, YPZ, Z] = BuildPlotParams(MMs, ID);
    if N > 1
        subplot(SubplotRows,SubplotCols,PN);
        ax = RatePlot(X, Models, XP, YP, EP, C, MS, FS, ID);
        if Z > 1
            MZ = [C,'o'];
            hold on;
            plot(XPZ, YPZ, MZ, 'MarkerSize', MS, 'linewidth', 2);
        end
    end
    if N == 1
        if Z > 1
            subplot(SubplotRows,SubplotCols,PN);
            MZ = [C, 'o'];
            YL = [ID, ' +/- STD'];
            yr = [0, 1];
            plot(XPZ, YPZ, MZ, 'MarkerSize', MS, 'linewidth', 2);
            ax = gca;
            ax = SetAxProps(ax, X, FS);
            ax.YLabel.String = YL;
            ax.YLim = yr;
        end
    end
    axs(1,M) = ax;
    M = M + 1;
    PN = PN + SubplotCols;
end

FittedSubstrates = GetFittedSubstrates(MMs);
nFS = size(FittedSubstrates, 2);
nFS1 = size(FittedSubstrates, 1);
if nFS1 > 0
    for i = 1:nFS
        Sub = FittedSubstrates(1,i);
        Sub = char(Sub);
        [XP, YP, EP, N] = BuildPlotParamsSubstrates(MMs, Sub);
        if N > 1
            ax = subplot(SubplotRows,SubplotCols,PN);
            C = char(CA(1,i));
            RatePlot(X, Models, XP, YP, EP, C, MS, FS, Sub);
            PN = PN + SubplotCols;
        end
    end
end
ax = gca;
ax.XTickLabel = Models;
ax.XAxisLocation = 'bottom';
ax.XTickLabelRotation = -45;
ax.XLabel.String = 'ModelID';
ax.XLabel.FontSize = FS;
ax.XTickLabelMode =  'manual';
FN = [WDN, SID, '_ModelsResultPlots', '.png'];
saveas(gcf, FN);
% close();

end
    

function ax = RatePlot(X, Models, XP, YP, EP, C, MS, FS, ID)
M = [C, 'o'];
YL = [ID, newline, '+/- STD'];
errorbar(XP, YP, EP, M,  'MarkerFaceColor', C, 'MarkerSize', MS, 'linewidth', 2);
YT = YP + EP;
yr = [0, 1.1*max(YT)];
% if yr(2) > 10.0
%     yr(2) = 10.0;
% end
ax = gca;
ax = SetAxProps(ax, X, FS);
ax.YLabel.String = YL;
ax.YLim = yr;
end
    

function [XP, YP, EP, N, XPZ, YPZ, M] = BuildPlotParams(MMs, ID)
XP = [];
YP = [];
EP = [];
XPZ = [];
YPZ = [];
nMMs = size(MMs,2);
N = 1;
M = 1;
for i = 1:nMMs
    MM = MMs(1,i);
    XIDs = MM.XIDs;
    STD = MM.XSTDCovar;
    if any(strcmp(XIDs, ID))
        XP(N) = i;
        YP(N) = MM.(ID);
        EP(N) = STD(strcmp(XIDs, ID));
        N = N + 1;
    else
        XPZ(M) = i;
        YPZ(M) = MM.(ID);
        M = M + 1;
    end
end
end


function [XP, YP, EP, N] = BuildPlotParamsSubstrates(MMs, ID)
XP = [];
YP = [];
EP = [];
nMMs = size(MMs,2);
N = 1;
for i = 1:nMMs
    MM = MMs(1,i);
    XIDs = MM.XIDs;
    STD = MM.XSTDCovar;
    if any(strcmp(XIDs, ID))
        XID = char(XIDs(strcmp(XIDs, ID)));
        XP(N) = i;
        YP(N) = GetIsotopomerFromStruct(MM, XID);
        EP(N) = STD(strcmp(XIDs, ID));
        N = N + 1;
    end
end
end


function VA = GetValuesFromMetabolicModels(MMs, VID)
nMMs = size(MMs, 2);
VA = zeros(1, nMMs);
for i = 1:nMMs
    MM = MMs(1, i);
    VA(1, i) = MM.(VID);
end
end


function ax = SetAxProps(ax, X, FS)
ax.FontName = 'Helvetica';
ax.FontSize =  FS;
ax.FontWeight = 'normal';
ax.XTick = X;
ax.XLim = [min(X)-1, max(X)+1];
ax.XTickLabelMode =  'manual';
ax.YLabel.FontSize = FS;
end


function FittedSubstrates = GetFittedSubstrates(MMs)
nMMs = size(MMs, 2);
FittedSubstrates = {};
N = 1;
for i = 1:nMMs
    MM = MMs(1,i);
    XIDs = MM.XIDs;
    nXIDs = size(XIDs,2);
    for j = 1:nXIDs
        XID = char(XIDs(1, j));
        if contains(XID, ' ')
            if contains(XID, 'x')
                FittedSubstrates(1, N) = {XID};
                N = N + 1;
            end
        end
    end
end
FittedSubstrates = unique(FittedSubstrates);
end


function PT = GetStudyID(MMs)
MM = MMs(1, 1);
GDA = MM.GDA;
M = GDA(1);
PT =  M.StudyID;
SID =  M.StudyID;
T = strsplit(PT, '_');
nT = size(T,2);
if nT > 1
    PT = char(T(1));
    for i = 2:nT
        PT = [PT, ' ', char(T(i))];
    end
end
end


function SID = GetSID(MMs)
MM = MMs(1, 1);
GDA = MM.GDA;
M = GDA(1);
SID =  M.StudyID;
end


function NMMs = AddLnResid(MMs)
nMMs = size(MMs, 2);
for i = 1:nMMs
    MM = MMs(1,i);
    BEV = MM.BestEV;
    LnResid = log(BEV);
    MM.LnResid = LnResid;
    NMMs(1, i) = MM;
end
end
    



