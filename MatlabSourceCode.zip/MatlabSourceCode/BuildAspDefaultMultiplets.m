function Multiplets = BuildAspDefaultMultiplets()

GlobalR2 = SetDefaultR2();

R = SetDefaultChemicalShifts();
AspFreqsPPM = R.AspEstFreqsPPM;

R = SetDefaultJs();
AspJAHz = R.AspEstJAHz;

% R = SetDefaultIsotopeShifts();

Spectrum = BuildDefaultSpectrum();

ID = 'Asp C1 S';
FreqPPM = AspFreqsPPM(1);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);

Multiplets = [Multiplet, ...  %1: Asp C1 S
              Multiplet, ...  %2: Asp C1 D
              Multiplet, ...  %3: Asp C2 S
              Multiplet, ...  %4: Asp C2 D12
              Multiplet, ...  %5: Asp C2 D23
              Multiplet, ...  %6: Asp C2 Q
              Multiplet, ...  %7: Asp C3 S
              Multiplet, ...  %8: Asp C3 D23
              Multiplet, ...  %9: Asp C3 D34
              Multiplet, ...  %10: Asp C3 Q
              Multiplet, ...  %11: Asp C4 S
              Multiplet]; ...  %12: Asp C4 D
n = 2;

ID = 'Asp C1 D';
FreqPPM = AspFreqsPPM(1);
JHz = AspJAHz(1,2);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Asp C2 S';
FreqPPM = AspFreqsPPM(2);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Asp C2 D12';
FreqPPM = AspFreqsPPM(2);
JHz = AspJAHz(1,2);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Asp C2 D23';
FreqPPM = AspFreqsPPM(2);
JHz = AspJAHz(2,3);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Asp C2 Q';
FreqPPM = AspFreqsPPM(2);
JHz = [AspJAHz(1,2), AspJAHz(2,3)];
Multiplet = BuildQuartet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Asp C3 S';
FreqPPM = AspFreqsPPM(3);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Asp C3 D23';
FreqPPM = AspFreqsPPM(3);
JHz = AspJAHz(2,3);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Asp C3 D34';
FreqPPM = AspFreqsPPM(3);
JHz = AspJAHz(3,4);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Asp C3 Q';
FreqPPM = AspFreqsPPM(3);
JHz = [AspJAHz(3,4), AspJAHz(2,3)];
Multiplet = BuildQuartet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Asp C4 S';
FreqPPM = AspFreqsPPM(4);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Asp C4 D';
FreqPPM = AspFreqsPPM(4);
JHz = AspJAHz(3,4);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;

end

