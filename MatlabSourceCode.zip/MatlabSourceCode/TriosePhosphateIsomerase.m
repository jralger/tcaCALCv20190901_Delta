function [DHAP_TPI, GA3P_TPI] = TriosePhosphateIsomerase(DHAP, GA3P, m, R)
% R = 0: no scrambling
% R = 1: complete scrambling

[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                     DefineThreeCarbonLabelIndices();

DHAP_TPI = DHAP;
GA3P_TPI = GA3P;

if R > 1.0
    R = 1.0;
end

if R < 0.0
    R = 0.0;
end

A = 1.0 - (0.5*R);               
B = 1.0 - A;

DHAP_TPI(m, ooo) = (A*DHAP(m, ooo)) + (B*GA3P(m, ooo));
DHAP_TPI(m, xoo) = (A*DHAP(m, xoo)) + (B*GA3P(m, xoo));
DHAP_TPI(m, oxo) = (A*DHAP(m, oxo)) + (B*GA3P(m, oxo));
DHAP_TPI(m, xxo) = (A*DHAP(m, xxo)) + (B*GA3P(m, xxo));

DHAP_TPI(m, oox) = (A*DHAP(m, oox)) + (B*GA3P(m, oox));
DHAP_TPI(m, xox) = (A*DHAP(m, xox)) + (B*GA3P(m, xox));
DHAP_TPI(m, oxx) = (A*DHAP(m, oxx)) + (B*GA3P(m, oxx));
DHAP_TPI(m, xxx) = (A*DHAP(m, xxx)) + (B*GA3P(m, xxx));

GA3P_TPI(m, ooo) = (A*GA3P(m, ooo)) + (B*DHAP(m, ooo));
GA3P_TPI(m, xoo) = (A*GA3P(m, xoo)) + (B*DHAP(m, xoo));
GA3P_TPI(m, oxo) = (A*GA3P(m, oxo)) + (B*DHAP(m, oxo));
GA3P_TPI(m, xxo) = (A*GA3P(m, xxo)) + (B*DHAP(m, xxo));

GA3P_TPI(m, oox) = (A*GA3P(m, oox)) + (B*DHAP(m, oox));
GA3P_TPI(m, xox) = (A*GA3P(m, xox)) + (B*DHAP(m, xox));
GA3P_TPI(m, oxx) = (A*GA3P(m, oxx)) + (B*DHAP(m, oxx));
GA3P_TPI(m, xxx) = (A*GA3P(m, xxx)) + (B*DHAP(m, xxx));


end

