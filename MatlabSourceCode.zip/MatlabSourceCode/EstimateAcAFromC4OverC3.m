function AcA = EstimateAcAFromC4OverC3(GDA, ExactNA)
% Estimates AcA isotopomers from Glu C4 and C3 multiplets
% Described in Malloy C.R. et al Biochemistry 1990
% C R Malloy 1, J R Thompson, F M Jeffrey, A D Sherry. Contribution of 
% exogenous substrates to acetyl coenzyme A: measurement by 13C NMR under 
% non-steady-state conditions. Biochemistry. 1990 Jul 24;29(29):6756-61. 
% doi: 10.1021/bi00481a002. PMID: 1975750
% GDA (input): General data array
% ExactNA (input): 0 or 1: whether to use exact natural abundance
% AcA (output): Acetyl CoA isotopomers


[oo, xo, ox, xx] = DefineTwoCarbonLabelIndices();
AcA = BuildTwoCarbonNaturalAbundance(Define13CNaturalAbundance());

if ExactNA == 0
    AcA(:) = 0.0;
    AcA(oo) = 1;
end

AcA(oo) = -1;
AcA(ox) = -1;
AcA(xx) = -1;

C4D34 = GetMultipletValue(GDA, 'Glu', 'C4 D34');
C4Q = GetMultipletValue(GDA, 'Glu', 'C4 Q');
C4ToC3 = GetMultipletValue(GDA, 'Glu:Glu', 'C4:C3');

if C4ToC3 == -1
    C4 = GetMultipletValue(GDA, 'Glu', 'C4');
    if C4 ~= -1
        C3 = GetMultipletValue(GDA, 'Glu', 'C3');
        if C3 ~= -1
            C4ToC3 = C4/C3;
        end
    end
end

% Fc2 calculation
if C4D34 ~= -1
    if C4ToC3 ~= -1
         AcA(ox) = C4D34 * C4ToC3; 
    end
end

% Fc3 calculation
if C4Q ~= -1
    if C4ToC3 ~= -1
        AcA(xx) = C4Q * C4ToC3;
    end
end

% Fc0 calculation
if C4D34 ~= -1
    if C4ToC3 ~= -1
        if C4Q ~= -1
            AcA = UpdateUnLabelledIsotopomer(AcA);
        end
    end
end

end

function R = GetMultipletValue(GDA, MolID, MeasID)
nGDA = size(GDA, 2);
R = -1;
for i = 1:nGDA
    GD = GDA(i);
    if strcmp(GD.MolID, MolID)
        if strcmp(GD.MeasID, MeasID)
            R = GD.Value;
%             dummy =1;  
        end
    end
end
end











