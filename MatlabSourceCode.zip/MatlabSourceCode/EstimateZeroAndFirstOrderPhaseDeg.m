function [BestZOPhaseDeg, BestFOPhaseDegDist] = EstimateZeroAndFirstOrderPhaseDeg(CS, ...
             ZOPhaseDegStart, ZOPhaseDegEnd, ZOPhaseDegInc, ...
             FOPhaseDegDistStart, FOPhaseDegDistEnd, FOPhaseDegDistInc, ...
             PhaseSpreadDirection)
         
         
%this algorithm provides an estimate - still seems a bit buggy 11/2/2016
TCS = FirstOrderPhaseCorrect(CS, FOPhaseDegDistStart, PhaseSpreadDirection);
BestFOPhaseDegDist = FOPhaseDegDistStart;
TCS = ZeroOrderPhaseCorrect(TCS, ZOPhaseDegStart);
BestZOPhaseDeg = ZOPhaseDegStart;
ReS = real(TCS);
BestSumReS = sum(ReS);
ImS = imag(TCS);
BestSumImS = abs(sum(ImS));
for FOPhaseDegDist = FOPhaseDegDistStart: FOPhaseDegDistInc: FOPhaseDegDistEnd
    TCS = FirstOrderPhaseCorrect(CS, FOPhaseDegDist, PhaseSpreadDirection);
    for ZOPhaseDeg = ZOPhaseDegStart: ZOPhaseDegInc: ZOPhaseDegEnd
        RCS =ZeroOrderPhaseCorrect(TCS, ZOPhaseDeg);
        ReS = real(RCS);
        SumReS = sum(ReS);
        ImS = imag(RCS);
        SumImS = abs(sum(ImS));
        if SumImS < BestSumImS && SumReS > 0.0
           BestSumImS = SumImS;
           BestSumReS = SumReS;
           BestZOPhaseDeg = ZOPhaseDeg;
           BestFOPhaseDegDist = FOPhaseDegDist;
        end
    end
end
end